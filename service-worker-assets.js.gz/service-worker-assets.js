self.assetsManifest = {
  "version": "GkVomHNj",
  "assets": [
    {
      "hash": "sha256-9auIP+I2ZMvbvNHn8fxQt3gjIz9wUKOCO29fEUZcpjI=",
      "url": "TLSWeb.styles.css"
    },
    {
      "hash": "sha256-zyLDdtfqDu5i6H8WX59l49N2qLO6l9qf1lIcEXVd/qw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-mS9pp0LDTwIs9r+/tHPP3Yg0hais4uWBFGWENusMSKM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-NbwZyah+68eeq78xXShv86RPmfuycnx2BXeuGC26sWo=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-TTMbfIRYCWh/6ZtcC/6m23rRKoIiOx5Vw948CeeE9cA=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.1jy2czmvcw.wasm"
    },
    {
      "hash": "sha256-u9iMOIltdEH1f+auTSi7mcb4SBt2memdjfBRiDl2cNE=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.Abstractions.teru10q8m9.wasm"
    },
    {
      "hash": "sha256-l9JFTlQeou24it5z/wN5pLncCEvGXIhHTExQWTO548U=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.Cookies.5hwk0bo7dn.wasm"
    },
    {
      "hash": "sha256-RvrgkuvCzUhIR14zDxsUqVpYzujZOdJHMJ36UJgBMIg=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.Core.m4evlbueww.wasm"
    },
    {
      "hash": "sha256-cL4Y+4vde9FQW+ihh87/7rkXi9KV60lrMZQO2e7Jd94=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.8acxmbelqs.wasm"
    },
    {
      "hash": "sha256-qHOKX2WMUk0RiReR1Nttl051EGNtPuNJIPH/4ur0aBU=",
      "url": "_framework/Microsoft.AspNetCore.Components.0e7td35pdj.wasm"
    },
    {
      "hash": "sha256-m1FCF3uP2gKUZPiidn1jz6MgomFWCVx2/ttvbQIt1F0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.h17fhz4ubu.wasm"
    },
    {
      "hash": "sha256-88QJwfCtHfQjnIqJaqRECyUJalQRgwCRcQhfx+mACg0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ft1jd63w6t.wasm"
    },
    {
      "hash": "sha256-VM+AClnLmvKeVkZGoDomucLWLvpKiTdH+fxCRdSxfRM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.soz86ldbvs.wasm"
    },
    {
      "hash": "sha256-0MhJ9V058ppbeDEiGUfJ87M/IjJT8o8v4qVAL6Ez80A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.gc9mwwte58.wasm"
    },
    {
      "hash": "sha256-MXB/SPTQEG0iSm/FyKD2MuAf0K7KzuYf0Tp6KAtcf78=",
      "url": "_framework/Microsoft.AspNetCore.Cryptography.Internal.h8kn22exxr.wasm"
    },
    {
      "hash": "sha256-WFB8bB2zhNqBMitORJm5elDKBL42z+IWetyJ4IOrGC0=",
      "url": "_framework/Microsoft.AspNetCore.Cryptography.KeyDerivation.cjvk7v1i4t.wasm"
    },
    {
      "hash": "sha256-xEV/oEttD6lDH8uTc63YXb0hm7DbEhJM3TuHMuUdGJE=",
      "url": "_framework/Microsoft.AspNetCore.DataProtection.0x2ox0eei1.wasm"
    },
    {
      "hash": "sha256-LlR1Jkynaw8NHvrFDkb/TJlslaeyQ0smb/SvorJXgCM=",
      "url": "_framework/Microsoft.AspNetCore.DataProtection.Abstractions.i763uxpqcz.wasm"
    },
    {
      "hash": "sha256-EBu0K8SFe/KbDl6H4PhdQZcfOWBAQS9MiNm+0jjq0xo=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Abstractions.kb9z3q8jmd.wasm"
    },
    {
      "hash": "sha256-KOdV8nnepJvdzz9YZQF2IiESUrXNx6nNMN2Uvhssmi4=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Server.Abstractions.wyr9zkt2c4.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-sbIJEHnGL6std1HkIJ83mfNTk5yznrGRZbaacPDI5w4=",
      "url": "_framework/Microsoft.AspNetCore.Http.Extensions.57zig84vjd.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-P7u++4zIBAR6s/X8yOsyscat1H9SsWsnAnBNrm4OxlA=",
      "url": "_framework/Microsoft.AspNetCore.Http.f0vd9tuzrq.wasm"
    },
    {
      "hash": "sha256-m8uwdGLh0yoQJgrJecy7yfRXOD4chtRWcdsrmp9w7bI=",
      "url": "_framework/Microsoft.AspNetCore.Identity.3qvc864q0b.wasm"
    },
    {
      "hash": "sha256-BCB3DlLFocowiTdicYNuqtjVw2/oFfEO5a5sRF7/zH8=",
      "url": "_framework/Microsoft.AspNetCore.Identity.EntityFrameworkCore.48u4e49nba.wasm"
    },
    {
      "hash": "sha256-hyVhdjUpyHZZbSg8L54mTM1ZMzP8qbsRT1GFPfuKAW4=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.3tj1rw598p.wasm"
    },
    {
      "hash": "sha256-VQM0rTyQ42zNsi2Mfz/XlOZsi4F4HQ5RrZnGIJaRhjI=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.3iepfijnwt.wasm"
    },
    {
      "hash": "sha256-bsW0Dyz3MEMOsF9hGPzAUvNz3yXOL1xemo/IA9Di5qg=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Abstractions.at5ws5d15p.wasm"
    },
    {
      "hash": "sha256-QgTD9p8f7aqSec22y+GLt5lgVxeOOt35KMlYPqEqm80=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Relational.yz3eomkul5.wasm"
    },
    {
      "hash": "sha256-hTt0yQ/Go6SNNik73nVgI+lBBLmPYq74zo7mPau/Uzk=",
      "url": "_framework/Microsoft.EntityFrameworkCore.bwrd2pn530.wasm"
    },
    {
      "hash": "sha256-Vo0zFoymG+e4bWMY1QNq14VMyBd4Rw8Y/Dyb02u4FXs=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.61k1rbde39.wasm"
    },
    {
      "hash": "sha256-xDwh00zgQRhnGcVhcf12/i85N0Lq4JAC0AZ0M8ow0R0=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.wxwsns8np7.wasm"
    },
    {
      "hash": "sha256-AZQREBBusBO8koW8+iyg59Uq8CH6V2+BU4FY5JoMyWU=",
      "url": "_framework/Microsoft.Extensions.Configuration.3jp3o85dbg.wasm"
    },
    {
      "hash": "sha256-yvrdyley5+h85MPAqp0VjlQSMeryNaiXXJQZT3tlVak=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.2u1ih0j9jj.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-6lrdazmqfQjuq8wb4Av88tIM2Jy7tloERCCGE+fv590=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.2d0hd7236o.wasm"
    },
    {
      "hash": "sha256-iAhhdymtCvyZRD1hx/cXmme0r6QJneAj3IWayyAcT7Y=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.8k2iyeswcr.wasm"
    },
    {
      "hash": "sha256-oIu8yLUtJP4EGU5Om1fDSAzpY3ffMjl9rKZnwII0XTs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.47qgfhx9eb.wasm"
    },
    {
      "hash": "sha256-npldTut68mqzQngvA3K/GSRCbYWhEVEjs1SJ18ArUuo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.isypqwhob8.wasm"
    },
    {
      "hash": "sha256-cUScdixD5RatCXwYyj1Kl14g175SHw7nj9R2K8p7tIM=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.vwbhpv5ms3.wasm"
    },
    {
      "hash": "sha256-7uKYygN3aomxLQzHqnIsyyswMQemSlufwGpDw9vms6c=",
      "url": "_framework/Microsoft.Extensions.Http.udm31q8rli.wasm"
    },
    {
      "hash": "sha256-oY72o+LsFCexk7canRc9KVRYfFgiFVfQsxLpypQHkF4=",
      "url": "_framework/Microsoft.Extensions.Identity.Core.vk3pvhvdgj.wasm"
    },
    {
      "hash": "sha256-wT6+hVR0vzV2kMOQME2h4L6YJiuqFihMjMzR7VCMiGw=",
      "url": "_framework/Microsoft.Extensions.Identity.Stores.x0u3onfvw9.wasm"
    },
    {
      "hash": "sha256-ZbTnZVFsW5YBhb5oMBSOB+sbuloQvsjuUYZ8boT2RuA=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.xt73qsqilp.wasm"
    },
    {
      "hash": "sha256-L2P/tLhZ6FSR1KG27vIE/jer8JBjOAPRMf7D9eFEUNs=",
      "url": "_framework/Microsoft.Extensions.Localization.xcslyy3nju.wasm"
    },
    {
      "hash": "sha256-3G1cRl1RNnLG3tvgozuGy0B02fyHuQUK/xgm58vYIiI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8vgzioen7n.wasm"
    },
    {
      "hash": "sha256-ZhjIxp5uv1hNrTKHPL9WKgkyRPJstT9L1yuJ0Ng4lkc=",
      "url": "_framework/Microsoft.Extensions.Logging.e25zofafg3.wasm"
    },
    {
      "hash": "sha256-JT/c72wU6RhbwA4gfnbJbOs+CGhbNuc/N02z4r+qQxA=",
      "url": "_framework/Microsoft.Extensions.ObjectPool.xhqcekhyre.wasm"
    },
    {
      "hash": "sha256-pyWsUcPd3YLorRQE70Uke2ADx3z5FztEUqfU+lnWTo4=",
      "url": "_framework/Microsoft.Extensions.Options.9w9x65j0r5.wasm"
    },
    {
      "hash": "sha256-PM7FdyyeTNpnDSPGFtg1Y6pPcSc0qM66o1/jijDluSg=",
      "url": "_framework/Microsoft.Extensions.Primitives.wrdycuhq0i.wasm"
    },
    {
      "hash": "sha256-cwIV6cgn06BArLFl2PfLREMxRWH2iEw1GkvZ/MsWeWI=",
      "url": "_framework/Microsoft.Extensions.Validation.vpl6b9qgbk.wasm"
    },
    {
      "hash": "sha256-Bdf9d9pn2Uq2eIqSFAduDgy/genNDe0U87Tc6tyw3fY=",
      "url": "_framework/Microsoft.Extensions.WebEncoders.vzzjoxjizn.wasm"
    },
    {
      "hash": "sha256-Kdv1SUn86+kpDwWNrpHZ78zEccwJmv3UINKgC4xMXrE=",
      "url": "_framework/Microsoft.JSInterop.5x8cbat0k8.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-jfXK+cfJd/PteHB+5Bay/NDY9b9VLvVw6G/Bm262Lpo=",
      "url": "_framework/Microsoft.Net.Http.Headers.vhfw8f9f40.wasm"
    },
    {
      "hash": "sha256-wrGzRefo/0R1T8ErckHMg4NWY1Kk3jpBMnA0x1+CrOM=",
      "url": "_framework/Microsoft.Win32.Registry.ykd4sql45h.wasm"
    },
    {
      "hash": "sha256-JbsI7eJC/uM+7SbNKaDc/NHXpRYuxCPk81Sqb91EsjA=",
      "url": "_framework/MudBlazor.hhn123ydrk.wasm"
    },
    {
      "hash": "sha256-ibNgEbTv84Jn4qiRhvYJ2wGkJjQe1Kqu5o74c6p01C8=",
      "url": "_framework/Refit.1mn8mdar11.wasm"
    },
    {
      "hash": "sha256-QnepPYFVMfU2AgxnjqUPUuo/QFxGkNWHZ0JQsEMJkpg=",
      "url": "_framework/Refit.HttpClientFactory.24zu6xcrpf.wasm"
    },
    {
      "hash": "sha256-9TSNYolMpvLzFQ5BzzwBORl9nUGCN7kifZvzQZqGQbI=",
      "url": "_framework/Riok.Mapperly.Abstractions.bgo5wowxjs.wasm"
    },
    {
      "hash": "sha256-BlHNz9CTb/aVN8JyS1a5i5KKJcAtYn6pm5UlKXYhruM=",
      "url": "_framework/SharedLib.650ln90evs.wasm"
    },
    {
      "hash": "sha256-QtNQDl1G146IubTNbgjYbQoRbKzZLw21++nXIVBupWI=",
      "url": "_framework/System.6ata22n2ok.wasm"
    },
    {
      "hash": "sha256-MX/zXMQqRVEWxPsVmqx7VOSsjoCVXyihRhlUh8btbGQ=",
      "url": "_framework/System.Buffers.xgx3zw7vga.wasm"
    },
    {
      "hash": "sha256-rF9mS2W9g3p8YM6dRaLi6Y2kcoi1cQc6iZR57Uf+9TY=",
      "url": "_framework/System.Collections.Concurrent.skkeknjqmw.wasm"
    },
    {
      "hash": "sha256-eQZrCQf0d0SaaBHch9xKiztX7cYcYz8gUjf8lj3NHg0=",
      "url": "_framework/System.Collections.Immutable.fyzus3qbxb.wasm"
    },
    {
      "hash": "sha256-35nT+8Jy2XPNCZEOOKtpYB8xfmlshmBV6EB9jmJBjFE=",
      "url": "_framework/System.Collections.NonGeneric.paiafz1wdn.wasm"
    },
    {
      "hash": "sha256-am7w1QrVQmFXUyEHgDPw/MRZlY1IlgpRFTOm9mIBKMQ=",
      "url": "_framework/System.Collections.Specialized.2ejltfwdzr.wasm"
    },
    {
      "hash": "sha256-1Z7NY4mY1NpRsqpYmdmL0u6ENg3BE1eHQzb3d2CzNVY=",
      "url": "_framework/System.Collections.h1uz07a89e.wasm"
    },
    {
      "hash": "sha256-7CcopD3uYQrrMKxrILmrDmDT448VAzJOJ3tuq/G5R9s=",
      "url": "_framework/System.ComponentModel.0dwhii4s3k.wasm"
    },
    {
      "hash": "sha256-XkyCupUx6NVxbSHumCJfmODfV5FOcbyC8Sjv8YsfA3o=",
      "url": "_framework/System.ComponentModel.Annotations.6ajvhm14yt.wasm"
    },
    {
      "hash": "sha256-iop7BhyWE2hBXiz9dgoQ3Y24V43ZfTVs+9YL5RGyTg4=",
      "url": "_framework/System.ComponentModel.Primitives.i2vto8xsyi.wasm"
    },
    {
      "hash": "sha256-cm3CVasQtSugg6TojUYER6P5USE/K2z4QvuLxB39/Qs=",
      "url": "_framework/System.ComponentModel.TypeConverter.esd3qobv20.wasm"
    },
    {
      "hash": "sha256-pEOqJt77VQj+aITO8vOYvP9DD7RqIgMTaoDavOmAt+0=",
      "url": "_framework/System.Console.ku1g3fxroh.wasm"
    },
    {
      "hash": "sha256-nQcfsjAA/fUDcTTxK6Mm6IkHKCax8Gg2BHyyfM5lY8s=",
      "url": "_framework/System.Data.Common.17ies6k0q8.wasm"
    },
    {
      "hash": "sha256-S+9y1gbuKgxf1h8SpG5eoPlEAVXxxlNk/97GtZnHecY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.f7cafhsist.wasm"
    },
    {
      "hash": "sha256-9Yl5EeQ/mltq9wcWVH2uYSAJMHlf0Ddg0laU4QI4/H4=",
      "url": "_framework/System.Diagnostics.Tracing.dacn8th9rn.wasm"
    },
    {
      "hash": "sha256-Roe4dhvwQFzGj7Jb3dkOr/SrzJVBlLEgfStjgN3CPCw=",
      "url": "_framework/System.Formats.Asn1.mxg8tp7bye.wasm"
    },
    {
      "hash": "sha256-eVLbu06kofcify8lvF4bw7sFwtBVb+BrIDzRjM8DxNQ=",
      "url": "_framework/System.IO.Pipelines.lpqp7mc7fp.wasm"
    },
    {
      "hash": "sha256-dHegg74uSgnx/6gcTp9iGaBcO2VzThqVlWZ3sklfJLU=",
      "url": "_framework/System.Linq.Expressions.4qqxrm7c9r.wasm"
    },
    {
      "hash": "sha256-B1YLNzt0+dXP498z8+xADs03TuYxfr2k8liwMcoLKhY=",
      "url": "_framework/System.Linq.Queryable.xqravcliuy.wasm"
    },
    {
      "hash": "sha256-zlY9J/xSL0f9pQfkXXOhIM3vuJ9uk3kTtiYcf/aa9ks=",
      "url": "_framework/System.Linq.quah0253v7.wasm"
    },
    {
      "hash": "sha256-ePsbPypufwwJutqNT2PcEZuz0jYIlS3NBydafrOSLaE=",
      "url": "_framework/System.Memory.wy9c2fqzit.wasm"
    },
    {
      "hash": "sha256-f2nJAzTJuJzt4JS+UROfh68/GSn0JB0OmsdQSUYDMlY=",
      "url": "_framework/System.Net.Http.10g6w0e46n.wasm"
    },
    {
      "hash": "sha256-zFNZ+w8qtv/jfDEHxCsIQmwwEAlNMZ5Z6JPvSFJdr8c=",
      "url": "_framework/System.Net.Http.Json.019yiaxqfl.wasm"
    },
    {
      "hash": "sha256-yhJqZeZ5djPF1JvYmuwE4mDPL3k+eoG8faq/UsE3Kdo=",
      "url": "_framework/System.Net.NetworkInformation.6ke6uc5afq.wasm"
    },
    {
      "hash": "sha256-7EItNcFMaEsxK0M32n4FrkdbRrug+W4F2xjWoD0YpYU=",
      "url": "_framework/System.Net.Primitives.c4x1xd1bk9.wasm"
    },
    {
      "hash": "sha256-ZAK4KTzn6YvsQcBX968LE2cB+Ou8chRy6Q58t0MonTc=",
      "url": "_framework/System.Net.WebSockets.8d8lctccpa.wasm"
    },
    {
      "hash": "sha256-/GdPUwqfAj2eaxAHg9O3+RhZcwDuUjd77dSzmOsCHoY=",
      "url": "_framework/System.ObjectModel.cyjoxz7yjr.wasm"
    },
    {
      "hash": "sha256-dgyn6+7r+adBepZ9Uw+r0BCFONYZlTIlQA9M1ivzd30=",
      "url": "_framework/System.Private.CoreLib.m06g2uddcw.wasm"
    },
    {
      "hash": "sha256-YArawk7lqBZsGjT362KwK6PT2Hy7pbozfJOjLxRhfX4=",
      "url": "_framework/System.Private.Uri.4jrkqyayco.wasm"
    },
    {
      "hash": "sha256-t7dSdLXGbhSglFz7S2t6CVQqNDOU3ae66KbtZh6SJGg=",
      "url": "_framework/System.Private.Xml.Linq.pk6gzg4hkp.wasm"
    },
    {
      "hash": "sha256-akYHTIv7Z4dO2GtnPpItYMz74sFxTiPTuoQRlJJscgA=",
      "url": "_framework/System.Private.Xml.qgxsmuimz1.wasm"
    },
    {
      "hash": "sha256-nSh4CR1uqxjlNxu6RoLA0ACVW3QocE373F0pMDvRw04=",
      "url": "_framework/System.Runtime.38w9071lgb.wasm"
    },
    {
      "hash": "sha256-Atkv6JEKDMOhZXO6GRTKu2vOTN6vIKT0UYGqzGapS8E=",
      "url": "_framework/System.Runtime.InteropServices.6qlw9m7rax.wasm"
    },
    {
      "hash": "sha256-Jr2L5GjxUYLiIlOE41CoRQKYHc4xB13loY9XH9Dmr7I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.26w8i3zyp9.wasm"
    },
    {
      "hash": "sha256-faA0pvLgSQhabbnkYq0IUcXCrNjMTfNXD0U8ijfKZXM=",
      "url": "_framework/System.Runtime.Numerics.le70nxa5ef.wasm"
    },
    {
      "hash": "sha256-BGxV7d/muk63j1qpH6g0SWMV7d06eOXSKby5EvsSfLU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.w3rrqqlugs.wasm"
    },
    {
      "hash": "sha256-vwIu6HCxniTz8HbWUtfEX8rDPAQbUwEQ+ykRUQgDKaU=",
      "url": "_framework/System.Security.AccessControl.dl05n5sk9c.wasm"
    },
    {
      "hash": "sha256-h0BPOTV9K7JNYdHLhTysb9qLDJDgsKboOSqGesCmzAo=",
      "url": "_framework/System.Security.Claims.7gwhulf55h.wasm"
    },
    {
      "hash": "sha256-puhlQDEwEp2TTBA+TQ1cXMwjq3yUxSWpzhUhtLu53eA=",
      "url": "_framework/System.Security.Cryptography.Pkcs.6to3jp4pyt.wasm"
    },
    {
      "hash": "sha256-o0DvFZia4qxfCvLaPDk/UDbb/ro9VvABo8M22xsB3Is=",
      "url": "_framework/System.Security.Cryptography.Xml.nv301jy54c.wasm"
    },
    {
      "hash": "sha256-caGV43UAMJ2Sn7A/7Vjtjnp5h6/IZTVlLuINW6f/Pus=",
      "url": "_framework/System.Security.Cryptography.bhmbc3e3dx.wasm"
    },
    {
      "hash": "sha256-LJMD9aDMNrkiIxPh+jLZRs2/rbX8hNC/2T7epwUPsTE=",
      "url": "_framework/System.Security.Principal.Windows.kyxdafsctj.wasm"
    },
    {
      "hash": "sha256-5UA7n04elZxYYri4WbpbyigaPR8lrRHySsrxFDVGRJ4=",
      "url": "_framework/System.Text.Encodings.Web.pvz15gbb1b.wasm"
    },
    {
      "hash": "sha256-2MiurbIdbmfxfeahS2rGjB8jdDBGzYq5gElGfufvnhY=",
      "url": "_framework/System.Text.Json.waq49g7axd.wasm"
    },
    {
      "hash": "sha256-KAAkPaVgOOuqJmUMBCm/FW8QwHBzhv6esn04L5sbfaM=",
      "url": "_framework/System.Text.RegularExpressions.0q7j63agun.wasm"
    },
    {
      "hash": "sha256-4DzqXdx+e8dnxC/+v3JLY0LEzTunnWjtlF8vSfMiYao=",
      "url": "_framework/System.Threading.8m0jrekian.wasm"
    },
    {
      "hash": "sha256-yKyPOC00jBJGwJyjZ7k5K63VAqAaYP67EN40ogTr/xU=",
      "url": "_framework/System.Threading.Thread.wm16nawypt.wasm"
    },
    {
      "hash": "sha256-yOTyk6fHs9dyaz8f9JxJ9ONGJXwALa+InnVK3V4jlaI=",
      "url": "_framework/System.Transactions.Local.kx9yibe5ql.wasm"
    },
    {
      "hash": "sha256-UeODSosUYVpwo1L+UQmPXtSdmt/tRPd7UCwL4dgiKwg=",
      "url": "_framework/System.Web.HttpUtility.t9j3bl04zv.wasm"
    },
    {
      "hash": "sha256-zHSjsZ+N3XJB4tEgn77t39yrqKsvyqjd+MYIZvpYDmE=",
      "url": "_framework/System.Xml.Linq.g7kebn3ts5.wasm"
    },
    {
      "hash": "sha256-+xrjE8FpQvCdhfseZByZxFAwS1kvFdG9f7ErZX7j974=",
      "url": "_framework/TLSClientSharedLib.duodan24ve.wasm"
    },
    {
      "hash": "sha256-i9oQqaIdqVAEDnrToCJsjUYrNwyiLPihv7xWVQKf8nM=",
      "url": "_framework/TLSWeb.ntuq850eg9.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-9zoen8mO6Z8TMzAgwPWehX+jEJsUiA8XDI1Kq6gdWaA=",
      "url": "_framework/dotnet.3hl9yhe1m1.js"
    },
    {
      "hash": "sha256-5WJWKyRAy1ynOGugXKh/YchOnzSV97RMlyJnLcgr7m8=",
      "url": "_framework/dotnet.native.3qf6w265iu.js"
    },
    {
      "hash": "sha256-EG7563iSTaNeFBPXgBHokcbGGGNf06/UZpJv7TKR3c0=",
      "url": "_framework/dotnet.native.4zyobjtzg3.wasm"
    },
    {
      "hash": "sha256-j86bNQPKznxC4epcftZFbThfaMXvIRmSeHo8PdvTrdA=",
      "url": "_framework/dotnet.runtime.f4b1oiwlzh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-2gv1lS0CNU2cPP27nN34NRnMICDOQyTBYAzta0CivKQ=",
      "url": "_framework/netstandard.qfbxwnu2ub.wasm"
    },
    {
      "hash": "sha256-hLXWRj2SYTlcx7lV0WyfuiecuXwKoGxYxhgBCGP6FyA=",
      "url": "assets/img/favicon.png"
    },
    {
      "hash": "sha256-gMFHEVxmc+OOHtPB3+n5bj5EDigm6ZlxADJnQtvRfuY=",
      "url": "assets_old/css/material-dashboard.css"
    },
    {
      "hash": "sha256-fF03dTlPNMAa5EhVl/+a3SRhm5GdFNjfzpV3HAIwGYE=",
      "url": "assets_old/css/material-dashboard.css.map"
    },
    {
      "hash": "sha256-HOelEQLOit1S0UWj0S6MNpQ1ME9wA3cGngWIyUmrmuI=",
      "url": "assets_old/css/material-dashboard.min.css"
    },
    {
      "hash": "sha256-sBwqd0TOT7ph4P5OE6+b5q2HCKuy3VrQTSuENCMauRQ=",
      "url": "assets_old/css/nucleo-icons.css"
    },
    {
      "hash": "sha256-E8NYtl7LPC3pMBVl/VEF0XurQalAQV6yRYUVKxIto9s=",
      "url": "assets_old/css/nucleo-svg.css"
    },
    {
      "hash": "sha256-+Jn4dS5tZcmsZoNF0RJZs4q11eRkLGzTQi8m6/JGXcY=",
      "url": "assets_old/fonts/nucleo-icons.eot"
    },
    {
      "hash": "sha256-vpd1c/GF+rNwISMF799uN0gRvoDc3WK06DIoN6MI1ec=",
      "url": "assets_old/fonts/nucleo-icons.svg"
    },
    {
      "hash": "sha256-ZVlWzXOCj2QRi75Lt2gVrRUWFeAoGL3Rtn/SnGnllrQ=",
      "url": "assets_old/fonts/nucleo-icons.ttf"
    },
    {
      "hash": "sha256-2qgHsiS24zSYgl+ADp+rYpw/y/0OkhSwK4x0FKxa4sU=",
      "url": "assets_old/fonts/nucleo-icons.woff"
    },
    {
      "hash": "sha256-MYCJbNu25FA3AvI/gaRmOhK757nHe48goHQhHZl7w18=",
      "url": "assets_old/fonts/nucleo-icons.woff2"
    },
    {
      "hash": "sha256-5f3AEY1TYNKOcXDlAET2L3e1laMffnS8PM11j4QL5GQ=",
      "url": "assets_old/fonts/nucleo.eot"
    },
    {
      "hash": "sha256-pc9fuN4wG2A7+jBX0Lpmd/UpenhMaKc1eeBbG4Kxtxg=",
      "url": "assets_old/fonts/nucleo.ttf"
    },
    {
      "hash": "sha256-UruyFuBfJams7JLXF0OsMcBXTjtmzgC1n+wD7zOFlK4=",
      "url": "assets_old/fonts/nucleo.woff"
    },
    {
      "hash": "sha256-txfgOABwE7LiUAWC7pTYkq6AoX3qlcdgZzpciEQC2vY=",
      "url": "assets_old/fonts/nucleo.woff2"
    },
    {
      "hash": "sha256-jzxI3w03y2/rbD4IlK9mBTr8iipnEcR0LEasSoythP8=",
      "url": "assets_old/img/apple-icon.png"
    },
    {
      "hash": "sha256-NARhfJIhdcE35t+ncNf+eyHomIKtxZVbUm8bmuHVwQs=",
      "url": "assets_old/img/bg-pricing.jpg"
    },
    {
      "hash": "sha256-PQrzZYKcAqhXcVOiB5BSEWFdjonZWHeM7//s73Ie2iM=",
      "url": "assets_old/img/bg-smart-home-1.jpg"
    },
    {
      "hash": "sha256-bflJvP2tJ6jExQPuEFiNKGAMBVi5yDTCMO9tXsB0vYQ=",
      "url": "assets_old/img/bg-smart-home-2.jpg"
    },
    {
      "hash": "sha256-9OLVyuYoo3G1Jf4lpQm+xXH3CKrcD9leW/iZukm9S9I=",
      "url": "assets_old/img/bruce-mars.jpg"
    },
    {
      "hash": "sha256-E9THDvwVHQ+7VONSkMSAoYJAaZneMeySKylvIgK5EwQ=",
      "url": "assets_old/img/down-arrow-dark.svg"
    },
    {
      "hash": "sha256-5mhGvRnyfm8odSPhSnw9PkrMgqQjYB1kgqXzoW9DoAo=",
      "url": "assets_old/img/down-arrow-white.svg"
    },
    {
      "hash": "sha256-kBRdr5ZxoNPzDC1WqMR8Hipx/+YdPxHGKe+I33pSELI=",
      "url": "assets_old/img/down-arrow.svg"
    },
    {
      "hash": "sha256-MCCaYHwnxNbTuaXVEf5dSuDywdieOPOFFAtGuCMJIaY=",
      "url": "assets_old/img/drake.jpg"
    },
    {
      "hash": "sha256-t3lRlqdYsSFqKN4/OctPjVF+bvJui4hZi0M3ojeLBAk=",
      "url": "assets_old/img/favicon.png"
    },
    {
      "hash": "sha256-nnbojrV+vKwOghBnmmNvoTsAxirfe/wIz1wrnlvIFOw=",
      "url": "assets_old/img/home-decor-1.jpg"
    },
    {
      "hash": "sha256-RmESnL4DE3YfFX2BO68l79CvCGTWy6mIOExLdlY2Trg=",
      "url": "assets_old/img/home-decor-2.jpg"
    },
    {
      "hash": "sha256-6+1wjGiRo4U2CJDOTsVrk/UW23T9uWx1qtVPhT1BLCg=",
      "url": "assets_old/img/home-decor-3.jpg"
    },
    {
      "hash": "sha256-yfEPV2CDlA3V1mRo15R/uJIFy/lckfDxV1DqAc4wpls=",
      "url": "assets_old/img/icons/flags/AU.png"
    },
    {
      "hash": "sha256-Xx0PaN/sxktTlFM7F9jPlhXqMmBQ+qVRkLoJnDRtmgM=",
      "url": "assets_old/img/icons/flags/BR.png"
    },
    {
      "hash": "sha256-6vZOCsAl1tiNJ9BGxU7yZkjALnsKzKcXZ2jEmLwEgQU=",
      "url": "assets_old/img/icons/flags/DE.png"
    },
    {
      "hash": "sha256-DEqlktZd32gzJ5F+myw4Yylr724ob4cpYyNeKmXPHDs=",
      "url": "assets_old/img/icons/flags/GB.png"
    },
    {
      "hash": "sha256-5OAhQB15+F6z059nfK2cS8FFe26g0i9XolQf81ov5Xo=",
      "url": "assets_old/img/icons/flags/US.png"
    },
    {
      "hash": "sha256-1IN5VLwFnMjc32T2Le/GRDwfxp7TIXTv2K+Pcu85bMc=",
      "url": "assets_old/img/illustrations/chat.png"
    },
    {
      "hash": "sha256-OslfBBjjjNKPwpHU1eNRkdpg7scpKlCXibAtlKYytSw=",
      "url": "assets_old/img/illustrations/danger-chat-ill.png"
    },
    {
      "hash": "sha256-eLQ3GKzSMIP8EmhRwGRl8L+4OHcdtEvfRvYXMgTe7I4=",
      "url": "assets_old/img/illustrations/dark-lock-ill.png"
    },
    {
      "hash": "sha256-Ek+N8EqqZ9FqLXQmkFgN2FLvreYutGFHnWxYFg02/fI=",
      "url": "assets_old/img/illustrations/error-404.png"
    },
    {
      "hash": "sha256-2eC1LZLGk07iLIiRZpfbtNQNH8RT4gYXVYUMpEpxlNw=",
      "url": "assets_old/img/illustrations/error-500.png"
    },
    {
      "hash": "sha256-Wur1aApwkDZvarLC3vQLsWvMrQ71qhrLrRZuSyPUpzU=",
      "url": "assets_old/img/illustrations/illustration-lock.jpg"
    },
    {
      "hash": "sha256-hLustOBJO8IDXPE6nDXQqpWYfT9oePxo0T/U8ZaWc6w=",
      "url": "assets_old/img/illustrations/illustration-reset.jpg"
    },
    {
      "hash": "sha256-T7TDNRm23AOBLa0sCWLvrt4ZAoJHahOXAsOKv6MgvcE=",
      "url": "assets_old/img/illustrations/illustration-signin.jpg"
    },
    {
      "hash": "sha256-Fhkd8X5AIek9m2EI7oP60sXP9CsVmbkVCXNvkc5dggQ=",
      "url": "assets_old/img/illustrations/illustration-signup.jpg"
    },
    {
      "hash": "sha256-QOg8EDVeS0EMaDHP3BmMKuA1hLo9kjZOR1IA5+IX+nQ=",
      "url": "assets_old/img/illustrations/illustration-verification.jpg"
    },
    {
      "hash": "sha256-kB4+VD5Bs0aVMEcouPXXBWZgef5Dlg5g6wMnyESp+dQ=",
      "url": "assets_old/img/illustrations/lock.png"
    },
    {
      "hash": "sha256-Gb+Q4TAWDKtUnsFQmbepXXzhxN+BvDQZogrtOVwvT8U=",
      "url": "assets_old/img/illustrations/pattern-tree.svg"
    },
    {
      "hash": "sha256-oli6gzxqQvK6S47qE60/PL5BOc9PLRFisIyxE+F2wfo=",
      "url": "assets_old/img/illustrations/rocket-white.png"
    },
    {
      "hash": "sha256-1fPLE5stlrYttcsG3GroC4M1wpvo+3vG9ShUL3ukMpA=",
      "url": "assets_old/img/ivana-square.jpg"
    },
    {
      "hash": "sha256-eiFISuG3mWXtj6DwY5iEyF3xT6uHbZIs9yiDOfj09fc=",
      "url": "assets_old/img/ivana-squares.jpg"
    },
    {
      "hash": "sha256-jKWDDZXZ6bzUN0HuSkgoT5H71UzDAQg95meLOaeZios=",
      "url": "assets_old/img/ivancik.jpg"
    },
    {
      "hash": "sha256-6kCA+sEOT/MZMszhZ8TGxVFWNdmpQ1eJN4RCGqYyguA=",
      "url": "assets_old/img/kal-visuals-square.jpg"
    },
    {
      "hash": "sha256-ehLa4pwRkq7PI7o888831ZsgPQbQOXEGMXplD3IvBSA=",
      "url": "assets_old/img/logo-ct-dark.png"
    },
    {
      "hash": "sha256-8jj8NKP6xByL4UzV4LJs2qou3b74corusMtrNzXLcaQ=",
      "url": "assets_old/img/logo-ct.png"
    },
    {
      "hash": "sha256-KcJrfgokxExk2fbcRbTxFkoW28SXoBFeHGQaFGXJW1k=",
      "url": "assets_old/img/logos/gray-logos/logo-coinbase.svg"
    },
    {
      "hash": "sha256-QbtPQs4zEGXEm+whWfTv7jjVnaTUKj/CWs39BvhJ5no=",
      "url": "assets_old/img/logos/gray-logos/logo-nasa.svg"
    },
    {
      "hash": "sha256-5QXmvpLe2UxMuvjHV5dfpwqLyD2TAYKeP3+6rJo2Nsk=",
      "url": "assets_old/img/logos/gray-logos/logo-netflix.svg"
    },
    {
      "hash": "sha256-lS8Eu14mdX4gFZL3yj+0J02tKltebfics/vpRn4UZY0=",
      "url": "assets_old/img/logos/gray-logos/logo-pinterest.svg"
    },
    {
      "hash": "sha256-jqsmufTyfv8oM9EG3ZDBxkirLFNXCxkIPQ0GTdFA4Zw=",
      "url": "assets_old/img/logos/gray-logos/logo-spotify.svg"
    },
    {
      "hash": "sha256-3KbouMbRtoXnPUQRAHwQyspZhlc7/NpvKd6HlCj4f/k=",
      "url": "assets_old/img/logos/gray-logos/logo-vodafone.svg"
    },
    {
      "hash": "sha256-qvldacD26pljXrnWic5r8NfRO8KUyR0yNLrXrdXz4Is=",
      "url": "assets_old/img/logos/mastercard.png"
    },
    {
      "hash": "sha256-CTsb4w8OCWGEb+13Gol72Quyt3oIUpOJE710rhSpWEI=",
      "url": "assets_old/img/logos/visa.png"
    },
    {
      "hash": "sha256-pSw5JB6y+G/pUeQrngBIzDWd8VurkdCMIrnZ8TAdD2Y=",
      "url": "assets_old/img/marie.jpg"
    },
    {
      "hash": "sha256-TzkvPHjN+CeNbKp/540Dd6VTs5GlXjpYJpdt6nbftGQ=",
      "url": "assets_old/img/meeting.jpg"
    },
    {
      "hash": "sha256-6YT7Vmo8bGf8xdz/8O1yTCP/hkju1mrhsQXJ2SqWoXY=",
      "url": "assets_old/img/office-dark.jpg"
    },
    {
      "hash": "sha256-ZrKvr6hgueGKbXJSZcme+rFQ4vLi6Dg8nntezpCE4rM=",
      "url": "assets_old/img/product-12.jpg"
    },
    {
      "hash": "sha256-IiINvvlZpszq/m7xVQKvrSsblQjigwvBGXJznYUyAtg=",
      "url": "assets_old/img/products/product-1-min.jpg"
    },
    {
      "hash": "sha256-zK8Q+m2APaxajqa3GIAaDK9inNWg0wYFpaQuFW8YGMs=",
      "url": "assets_old/img/products/product-11.jpg"
    },
    {
      "hash": "sha256-aCFkj6ehPQ+ky7f60s/ojnP50VJjprIrtxZGNsaDkBI=",
      "url": "assets_old/img/products/product-2-min.jpg"
    },
    {
      "hash": "sha256-3CnFVBvSmCFuRGDoX8ZmLps39fZhxD1jHSi0A2ble7g=",
      "url": "assets_old/img/products/product-3-min.jpg"
    },
    {
      "hash": "sha256-hOg9is/OBp70bbLL9+/itMtrQnKDfnauTzhvs0MfKQk=",
      "url": "assets_old/img/products/product-4-min.jpg"
    },
    {
      "hash": "sha256-eg10O2o+Oo9phixfPZA7q0yZC0SIG3G3mKqZMOogAJk=",
      "url": "assets_old/img/products/product-5-min.jpg"
    },
    {
      "hash": "sha256-hNFcTu91vwGAf3Hidlp5Ec8SQ6XkZV6ISFpubgOAwm4=",
      "url": "assets_old/img/products/product-6-min.jpg"
    },
    {
      "hash": "sha256-aZlfkXyGyv1oADZsYY7xU3GrOlZMswrBG9RYjDs8ens=",
      "url": "assets_old/img/products/product-7-min.jpg"
    },
    {
      "hash": "sha256-8pFUWUOp/4eu7UHxamLbHbD2G1JRXOZdYtbSrCulvPg=",
      "url": "assets_old/img/products/product-details-1.jpg"
    },
    {
      "hash": "sha256-Si2Ck7Pm+cw4fpc3z3yKFyikc1RoMMYzY1qb65XDwmw=",
      "url": "assets_old/img/products/product-details-2.jpg"
    },
    {
      "hash": "sha256-R+c1OwRQY7PUWJdrrQQyJV9C1BKpAnq4IVRZchYP7Pg=",
      "url": "assets_old/img/products/product-details-3.jpg"
    },
    {
      "hash": "sha256-+eP98skAwqb+aQBkJEIMyLMUIXNG3VfmHcl0xfrs7PA=",
      "url": "assets_old/img/products/product-details-4.jpg"
    },
    {
      "hash": "sha256-/aUQ1fBMkU9XsDCVqMlmCp2NZaza1BhuIQDbGUUca2A=",
      "url": "assets_old/img/products/product-details-5.jpg"
    },
    {
      "hash": "sha256-KG6V81apUMSr4M4A4v+wOApsOW16SNkGgqfI2EUyDTA=",
      "url": "assets_old/img/shapes/pattern-lines.svg"
    },
    {
      "hash": "sha256-Q2n24mRLJyLl/LQ/T9S2svVz9IxV7QZziWKs7KMqiQE=",
      "url": "assets_old/img/shapes/waves-white.svg"
    },
    {
      "hash": "sha256-Xsj2BOqozJ0kSw6T/Z0Ssy5c4Ozb75ZWrv0OZcEHBJs=",
      "url": "assets_old/img/small-logos/bootstrap.svg"
    },
    {
      "hash": "sha256-wHXX154iqw8ehtSi3Gm1/Voh4iYKUnXrsAn1BepapmQ=",
      "url": "assets_old/img/small-logos/creative-tim.svg"
    },
    {
      "hash": "sha256-Xzv4ds7RP8+17cnb2hK/jI0UF3xvyUBW0sOzx8ges3c=",
      "url": "assets_old/img/small-logos/devto.svg"
    },
    {
      "hash": "sha256-wFTCNbB+VRHYn2g3uNnW5zyc+JYApjniIQY0Lehdd6E=",
      "url": "assets_old/img/small-logos/github.svg"
    },
    {
      "hash": "sha256-Pcj13znMKVhq/FyhHDvWMeZb91RcP+yQbLYEwi/kjmM=",
      "url": "assets_old/img/small-logos/google-webdev.svg"
    },
    {
      "hash": "sha256-7KfoaBIe0jv8FreRDPinswNbLtEvH9XE7Y97IzYky4A=",
      "url": "assets_old/img/small-logos/icon-bulb.svg"
    },
    {
      "hash": "sha256-6tsCaGDALq7C8BDuPXLRnfk9pAds9QaaFfhXF43uIvY=",
      "url": "assets_old/img/small-logos/icon-sun-cloud.png"
    },
    {
      "hash": "sha256-2zdqX0bvkaaIEGIA4YHXTalcKnjhZc3ncHVZqu0QYgc=",
      "url": "assets_old/img/small-logos/logo-asana.svg"
    },
    {
      "hash": "sha256-4H4wySqdDDqt+y1QzmvaT5hH8eFkhBz5sph9NWdMgt8=",
      "url": "assets_old/img/small-logos/logo-atlassian.svg"
    },
    {
      "hash": "sha256-ky5b61TLvsq7KYNAVvACpKlSTBGFCh7uLOrV/o1Zw54=",
      "url": "assets_old/img/small-logos/logo-invision.svg"
    },
    {
      "hash": "sha256-8k/AwqkojXpy1h4Ed3q3RcPSPD2LvcgeiNetNMr2voo=",
      "url": "assets_old/img/small-logos/logo-jira.svg"
    },
    {
      "hash": "sha256-OnBKB4S2IQfVh9C85xYzLrMObDqu9RDD4M9JRTbXMsM=",
      "url": "assets_old/img/small-logos/logo-slack.svg"
    },
    {
      "hash": "sha256-N/Nlf8X6uBMNqJVNDfbOKAFmcDL2Cz5i+wzxd9gAKN0=",
      "url": "assets_old/img/small-logos/logo-spotify.svg"
    },
    {
      "hash": "sha256-9PSmBQKuRElme1f5LRYXK4UIXomwOjlAAQNdS7dCLMA=",
      "url": "assets_old/img/small-logos/logo-xd.svg"
    },
    {
      "hash": "sha256-xZAkoXgUuTX8mqGx0dMfTsjRgXLvQ8LsSMBj40LnQhk=",
      "url": "assets_old/img/team-1.jpg"
    },
    {
      "hash": "sha256-9W9NGKPyNiw81HpEhVXCfdE7Yq87i22Tn7GUS768ZpM=",
      "url": "assets_old/img/team-2.jpg"
    },
    {
      "hash": "sha256-p+zXyPjy952ZaoQSHoV3UInmbe4MmxUy2Zr1JdBCe6I=",
      "url": "assets_old/img/team-3.jpg"
    },
    {
      "hash": "sha256-W/+YMmGdcT9GCLPm5VNpGafQxmqo23V8DxBGqSXzsD4=",
      "url": "assets_old/img/team-4.jpg"
    },
    {
      "hash": "sha256-kTvyH2YYVX49fZHKQ0mmeD79RCmFNYv2ijRASXWfkV8=",
      "url": "assets_old/img/team-5.jpg"
    },
    {
      "hash": "sha256-HyC1kcJFs3QqaeJSnSzPL2Ji9I3cp7H8juvu2P2h+Fo=",
      "url": "assets_old/img/tesla-model-s.png"
    },
    {
      "hash": "sha256-k0PqEAHQ5r4GfKaw57pxaA4YsR19UBdGlYUNy6bb5IA=",
      "url": "assets_old/img/vr-bg.jpg"
    },
    {
      "hash": "sha256-9SEPo+fwJFpMUet/KACSwO+Z/dKMReF9q4zFhU/fT9M=",
      "url": "assets_old/js/core/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-cMPWkL3FzjuaFSfEYESYmjF25hCIL6mfRSPnW8OVvM4=",
      "url": "assets_old/js/core/bootstrap.min.js"
    },
    {
      "hash": "sha256-mPB4o5sBAIri7v0nnUrsxhSyslM6T4vvNo5p0Zd/XLI=",
      "url": "assets_old/js/core/popper.min.js"
    },
    {
      "hash": "sha256-xD2d1zjiWtoVRzhwiuqpErOQ6t2xlEv9Atn1023L6/4=",
      "url": "assets_old/js/material-dashboard.js"
    },
    {
      "hash": "sha256-Hve2E4iG4hqH4IaqjOiLB2iXTdli8SX/FaiQ6luTz9U=",
      "url": "assets_old/js/material-dashboard.js.map"
    },
    {
      "hash": "sha256-0dckCOyhlNKxtGCv0Ou3e2IDikUeCJBqjdOk88Lo+ZM=",
      "url": "assets_old/js/material-dashboard.min.js"
    },
    {
      "hash": "sha256-EZk4kRFUgKxKf8gImXr2xAAvYkK/scdTy+LvBO4MCDo=",
      "url": "assets_old/js/plugins/Chart.extension.js"
    },
    {
      "hash": "sha256-LNRoyW7yb7HG5imnN327CIOlOwgEugTx9RK4hIC78b0=",
      "url": "assets_old/js/plugins/bootstrap-notify.js"
    },
    {
      "hash": "sha256-9CKDuBNIQo/dQgrK9nyK+XcD2MBjb0JgnPMANrQw6Cs=",
      "url": "assets_old/js/plugins/chartjs.min.js"
    },
    {
      "hash": "sha256-gy/qm2c+fE93XEldMgcq/R9Nqitoqn5DhM15xe2DW9o=",
      "url": "assets_old/js/plugins/perfect-scrollbar.min.js"
    },
    {
      "hash": "sha256-nxR2O8Iw1/h4qM7mXIdKEFEP6yULZaYoY7adJt7iIbU=",
      "url": "assets_old/js/plugins/smooth-scrollbar.min.js"
    },
    {
      "hash": "sha256-5wRkH5Y8QRj7vWJc74koDCcuSBtNdtyRhwEhzDhw56g=",
      "url": "assets_old/js/plugins/world.js"
    },
    {
      "hash": "sha256-RA30WhY/z9d0GsjPCSvx1a+U+VJv87FzJLtO3wYWNAI=",
      "url": "assets_old/scss/material-dashboard.scss"
    },
    {
      "hash": "sha256-qkiYfOY3EtvL7jQbh+KD/c2vOVC44IbdFw8/xGXfv4Y=",
      "url": "assets_old/scss/material-dashboard/_accordion.scss"
    },
    {
      "hash": "sha256-As2Mx0cY+Y6the8DwDq93jjGRDHpc6mY4lU7FsrijTA=",
      "url": "assets_old/scss/material-dashboard/_alert.scss"
    },
    {
      "hash": "sha256-Cs72z4Hd8h+EOsIbVgEZA6GA+T9YMGpaq44axw+aA8c=",
      "url": "assets_old/scss/material-dashboard/_avatars.scss"
    },
    {
      "hash": "sha256-lmOpmG1/7pmx58CuJ3nmFRZ5IibmNiWy2K91y2mLX8k=",
      "url": "assets_old/scss/material-dashboard/_backgrounds.scss"
    },
    {
      "hash": "sha256-9qQc21zZLdZ+a/v2DHSmUNG/+ZoeVdKCkD/z7s7sNOg=",
      "url": "assets_old/scss/material-dashboard/_badge.scss"
    },
    {
      "hash": "sha256-Fe8T7Zz+cSWjxzLOogr1OKRVSi6KKADu5D64c0kNBbQ=",
      "url": "assets_old/scss/material-dashboard/_breadcrumbs.scss"
    },
    {
      "hash": "sha256-oIoUwUJMiCRSq0QLpArZs7rCBwZsRHehRo5NtjtspeU=",
      "url": "assets_old/scss/material-dashboard/_buttons.scss"
    },
    {
      "hash": "sha256-/7CN1p916WzEGf2bgz2dpLOOPbu1SpNQdnxtY3hwihM=",
      "url": "assets_old/scss/material-dashboard/_cards-extend.scss"
    },
    {
      "hash": "sha256-eW65Pt/UNk3FJUa5pMwb8DPAWH9a/OghG77FU8Dh13E=",
      "url": "assets_old/scss/material-dashboard/_cards.scss"
    },
    {
      "hash": "sha256-yVD7Lr8sYV/BVcVJWXDY0qtKNVW+p9sWB6qnt8EhKs4=",
      "url": "assets_old/scss/material-dashboard/_components.scss"
    },
    {
      "hash": "sha256-4S4quu+lr0TxptKG9lTjksH0PNawvst7Nw+OF97SCbw=",
      "url": "assets_old/scss/material-dashboard/_dark-version.scss"
    },
    {
      "hash": "sha256-ioc7icVvlSNKFgGnwyGP7FqM8KfucXrGHrgSprH8/f4=",
      "url": "assets_old/scss/material-dashboard/_dropdown-extend.scss"
    },
    {
      "hash": "sha256-0c/J/pt0sH5rLoiZ3qDWQPJVL2nPX0cjPCOziWQcoiE=",
      "url": "assets_old/scss/material-dashboard/_dropdown.scss"
    },
    {
      "hash": "sha256-Vnrh/3wqi5ZM8pOQ124u1cCSWc0EquvLaZfO7i+vMzI=",
      "url": "assets_old/scss/material-dashboard/_dropup.scss"
    },
    {
      "hash": "sha256-VNQ/HUOjNDHOKn2Jg0WvB2HQQyE6/su2bC2dwHTyRR0=",
      "url": "assets_old/scss/material-dashboard/_fixed-plugin.scss"
    },
    {
      "hash": "sha256-cw2j21oMAnA6bWbVb/R0EPb4dRqoFUYRETppblYw8VE=",
      "url": "assets_old/scss/material-dashboard/_floating-elements.scss"
    },
    {
      "hash": "sha256-ASEm3R6wYuiwpdMqJKVNJVfLzWlqVaA7nw+DBG97jQo=",
      "url": "assets_old/scss/material-dashboard/_footer.scss"
    },
    {
      "hash": "sha256-OTJJOfmO67ym38BwppYnDI58WZGUjHrU7eIW2y20Qx8=",
      "url": "assets_old/scss/material-dashboard/_forms.scss"
    },
    {
      "hash": "sha256-XOKA4qoVaC6OO0uSX1u+rxtfgJlqPDaO9RaM/vAwglE=",
      "url": "assets_old/scss/material-dashboard/_gradients.scss"
    },
    {
      "hash": "sha256-HpDvbUv/Ha4B5TgeUKRbLlIK6r4GIVhVRM20wb72ye0=",
      "url": "assets_old/scss/material-dashboard/_header.scss"
    },
    {
      "hash": "sha256-udO70EADyH07hHbRDHdUPf7Y2jm8h6Nmzy6iMmX0aSk=",
      "url": "assets_old/scss/material-dashboard/_icons.scss"
    },
    {
      "hash": "sha256-iznnqFQgajj+4V7cFDSJ6uFiEucMQNwOebupxw8NaSc=",
      "url": "assets_old/scss/material-dashboard/_info-areas.scss"
    },
    {
      "hash": "sha256-yzGcyTZbqRbyjNa1KYBJx7NSiMuX8Etg2b/tKZDuQjQ=",
      "url": "assets_old/scss/material-dashboard/_list-check.scss"
    },
    {
      "hash": "sha256-OYEIQsPg8nlkI/xWGZAXhgMK1nNLeHRN0nVcXN7uhBU=",
      "url": "assets_old/scss/material-dashboard/_misc-extend.scss"
    },
    {
      "hash": "sha256-dT+Wu/EI8kuUvlNDCp7P5Xn/DGLRlPfrYslVKzCzHso=",
      "url": "assets_old/scss/material-dashboard/_misc.scss"
    },
    {
      "hash": "sha256-KO78SYIdMkArEfWOn8xhsXu2pa8W72QamW2gylKDJDU=",
      "url": "assets_old/scss/material-dashboard/_nav.scss"
    },
    {
      "hash": "sha256-gPcHW8kt0bzTrBfO4EZWnEKROofCPyxmnhpqGwhL5+c=",
      "url": "assets_old/scss/material-dashboard/_navbar-vertical.scss"
    },
    {
      "hash": "sha256-hJl/p8Y7EfNCy3HkfC8nsdFrpd+iHWCi9VwfY9slwtY=",
      "url": "assets_old/scss/material-dashboard/_navbar.scss"
    },
    {
      "hash": "sha256-XswQfHq7A2SqvSSlFXLORQYJx5BNrXOKTBYhpkj/W4Y=",
      "url": "assets_old/scss/material-dashboard/_pagination.scss"
    },
    {
      "hash": "sha256-TaYjMW71Gwg342ncRhs3CCb5ztq2euFeEoQHxbIpg1s=",
      "url": "assets_old/scss/material-dashboard/_popovers.scss"
    },
    {
      "hash": "sha256-t4tV7tJ69G2sm0iqChD8N2F41mkOsbr5bjXn8riZpiQ=",
      "url": "assets_old/scss/material-dashboard/_progress.scss"
    },
    {
      "hash": "sha256-KGbmeSo8yBp0z1R2UkZa0nk4EiLpe1VOl5xLMRCi5KQ=",
      "url": "assets_old/scss/material-dashboard/_ripple.scss"
    },
    {
      "hash": "sha256-Bf1v2GpeAmfolSXBuedKJaNFxl4sqf3OynT4gUOIsiM=",
      "url": "assets_old/scss/material-dashboard/_rtl-extend.scss"
    },
    {
      "hash": "sha256-YUW+eeRxdihjZQZSrh5oGAIiQc5LHayGg9jm4yvdOMI=",
      "url": "assets_old/scss/material-dashboard/_rtl.scss"
    },
    {
      "hash": "sha256-jyc+Gdcji567srLxk96fq9MpaeepWVJ4MrJOFPQART8=",
      "url": "assets_old/scss/material-dashboard/_social-buttons.scss"
    },
    {
      "hash": "sha256-HH+hdwe2gzgw4NBSpqzKqTrpMBdc3ixN3r6i5VzS8MI=",
      "url": "assets_old/scss/material-dashboard/_tables.scss"
    },
    {
      "hash": "sha256-9mo5lfVDK/jhn1toxBAQbddPpjWR8wdxLopsu4keEOY=",
      "url": "assets_old/scss/material-dashboard/_tilt.scss"
    },
    {
      "hash": "sha256-I3mPBT0lMqxAcen0vg6Wh8H5vJnIlLEii5ap/Xs5Tr8=",
      "url": "assets_old/scss/material-dashboard/_timeline.scss"
    },
    {
      "hash": "sha256-vIIFQycijR2xztY4OAbLI0phxyMIcH43bgoA2j8uaPM=",
      "url": "assets_old/scss/material-dashboard/_tooltips.scss"
    },
    {
      "hash": "sha256-zOrzGBJ9X/ztxJvp7Jg3p8kei37yBz7X7STMNxCe/y4=",
      "url": "assets_old/scss/material-dashboard/_typography.scss"
    },
    {
      "hash": "sha256-D58eWuSzdrSHiBajfyYy+9GcXCWevWD0DMFOs4WsobU=",
      "url": "assets_old/scss/material-dashboard/_utilities-extend.scss"
    },
    {
      "hash": "sha256-byhGIrI5WLJ1RGism19fMuMstaMST1nLxaOaHjMoE2A=",
      "url": "assets_old/scss/material-dashboard/_utilities.scss"
    },
    {
      "hash": "sha256-DnSqCaHNPsCgONNedqKrNngQQC0KTMuMfyUq5SvGAuE=",
      "url": "assets_old/scss/material-dashboard/_variables.scss"
    },
    {
      "hash": "sha256-dMXvrlr7BxpdNPaMXrAzMEOWkUdINZYWTrzWynKbiVw=",
      "url": "assets_old/scss/material-dashboard/badges/_badge-circle.scss"
    },
    {
      "hash": "sha256-gy1TFTGeQpmM31fmJusDRz4x8jsAnCHkY4Nth2AaIkw=",
      "url": "assets_old/scss/material-dashboard/badges/_badge-dot.scss"
    },
    {
      "hash": "sha256-Ixpeeo7a5GQ3BbMhpFzmr3wqg0gITI5gScGkOWs92fY=",
      "url": "assets_old/scss/material-dashboard/badges/_badge-floating.scss"
    },
    {
      "hash": "sha256-+1KI4oJRjngdArnHf2p8aYIXrmA2th6L5jbhJxGK0OY=",
      "url": "assets_old/scss/material-dashboard/badges/_badge.scss"
    },
    {
      "hash": "sha256-bkMBtrjBipoGy9Lnz8UpBodpyNNdhPum9x/3LSSCvQc=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_accordion.scss"
    },
    {
      "hash": "sha256-aluLHtF6RezWlaIiUnpaTBa0+go338jY2+XOOg6AOqA=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_alert.scss"
    },
    {
      "hash": "sha256-JHT54tonH8PWXpXe/ZZikkWzJQfcdD3fERU6cmBp2cU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_badge.scss"
    },
    {
      "hash": "sha256-EAUYOgAB7ZQU6FipygJLfrk5cEQJ8gwIsNphAbxC5zI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_breadcrumb.scss"
    },
    {
      "hash": "sha256-tpWKK4CLhj+w2X1jWgkEq9u/SEM2QreBZuth/PbRK/g=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_button-group.scss"
    },
    {
      "hash": "sha256-1t+i4G3oh+zpu+ng/ERdwcMEDinlwvm2s7+Di5GmbYo=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_buttons.scss"
    },
    {
      "hash": "sha256-29M6+eOjaX4iABEVroj37BabpHm+Kz3Avwf7ieDwoAU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_card.scss"
    },
    {
      "hash": "sha256-0ZN2nazAY8C1FBGqV19aFWw0uMjyari7a+caAWvEDMQ=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_carousel.scss"
    },
    {
      "hash": "sha256-0BQXJgPmSzJ/LRvNWl9cgpRzcEgB628fcaKcvt7zMoo=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_close.scss"
    },
    {
      "hash": "sha256-/XD6ZQtzaxCnT1Wq3Vgj5EdeP79X7uvVbeb5KzBz2ns=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_containers.scss"
    },
    {
      "hash": "sha256-pQ1AOhlxYB+/4EADQeu2ouhj6CskicGhExyjP4J6LIY=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_dropdown.scss"
    },
    {
      "hash": "sha256-JRuJTT5voTi7uiha0l+fhV61TQBsUEPO5HYx+l18zKY=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_forms.scss"
    },
    {
      "hash": "sha256-bgLU77TeIAZBiEctu3JFxOc3xDiS1U9XwfDesujBHzs=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_functions.scss"
    },
    {
      "hash": "sha256-r/1/Kr+8sbHnhxQN5hAldyM0C+BZ26yhKFkoY3Jj5g8=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_grid.scss"
    },
    {
      "hash": "sha256-5VkjZDd5ZCA3s/Pm+Nch05te4/YLTVR73sUi180CmeE=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_helpers.scss"
    },
    {
      "hash": "sha256-lKPZa/cC+owcR0tmr9gddy1LAZiK1IQ5Z1CYqZnVdwA=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_images.scss"
    },
    {
      "hash": "sha256-RAzMw+t0b+nAeMnO1oWa0dgGMsm0oIqjd7X66j4GiYs=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_list-group.scss"
    },
    {
      "hash": "sha256-R75F8xtY7y6VKjoSdmXiAkxQc+8LlpvDVX7+FcIvyGk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_mixins.scss"
    },
    {
      "hash": "sha256-k7W1H7GmExXFrp10R2vfcn19Rwtx6LlhZ315meA7W/E=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_modal.scss"
    },
    {
      "hash": "sha256-OTUpI2xT/PcggojZDgjWmejfM94391Uu5LRy0dKowR8=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_nav.scss"
    },
    {
      "hash": "sha256-UL/Jyv08sDFw+03jyv3AEK5IWQX1LvZYvXRsx90UbNc=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_navbar.scss"
    },
    {
      "hash": "sha256-5gwSDJjRtNuxUXvT5vQ0k9R9I3yIiDGjoQS3Pm3pws4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_offcanvas.scss"
    },
    {
      "hash": "sha256-Y7gNSNmMAOtYQPAQmaT4iCrU2v0qt5qAJrnX1MbbFM8=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_pagination.scss"
    },
    {
      "hash": "sha256-yRCOfHGJAvBhBNq8ncHh4zBUn1q8eEMryCnzi7VuBNY=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_placeholders.scss"
    },
    {
      "hash": "sha256-VVtHdXXmFBFVmoLLop8+ld53p8nfF+VTA5F3ld1O/2w=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_popover.scss"
    },
    {
      "hash": "sha256-68g+breOpkG2iNvI6cNClfLy1GpD/9ko4HYbRl1S3Ts=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_progress.scss"
    },
    {
      "hash": "sha256-RLO7H5dM/1lV7dIA0EvXAARwaW5wLWhgZnn0yUozERU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_reboot.scss"
    },
    {
      "hash": "sha256-99NtZD7o17JBXZftZa0Ngw9SVdAu2S6fDbztKdfcuSU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_root.scss"
    },
    {
      "hash": "sha256-O7g6gdAAOoTNgjFwjsEYH0NILz7YNk+Ebop5xSaGttM=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_spinners.scss"
    },
    {
      "hash": "sha256-B4Y4I7+5XyGZL8qiDknaTBsf1xoR7WOLUnQbywnOEr8=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_tables.scss"
    },
    {
      "hash": "sha256-rIj2lx3ro1DqOuda/MdAiLGF4u5NsZmmG0QSFPJtaTg=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_toasts.scss"
    },
    {
      "hash": "sha256-DSoBeBlwDJolLqU/lwnjgY1BVU+xOHz6omeqr+uNVx0=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_tooltip.scss"
    },
    {
      "hash": "sha256-5WYb4Udq9gyeRTdQeA+GhBxonc8inegCIwB8PK2hSMk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_transitions.scss"
    },
    {
      "hash": "sha256-l4tgKhsywmCQ9JV67pjPVryG+GJxxJ3zZ4wxW4ry97U=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_type.scss"
    },
    {
      "hash": "sha256-TpihVmzvOyngBwKh5kxc4wv26xLaIgK3cXSWzdXk0UA=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_utilities.scss"
    },
    {
      "hash": "sha256-AhNb2OCQbDyg2YQLiYQYbbryobu7diG285rjxDIFenw=",
      "url": "assets_old/scss/material-dashboard/bootstrap/_variables.scss"
    },
    {
      "hash": "sha256-6Il+hcneZ3Hh7FMvJGCqvkcawuLfmhLZbeVlyr7L9ME=",
      "url": "assets_old/scss/material-dashboard/bootstrap/bootstrap-grid.scss"
    },
    {
      "hash": "sha256-gpxJvKDRzIZf2EgU78Mo7TrnrE603ULj3Gku5DvzP3I=",
      "url": "assets_old/scss/material-dashboard/bootstrap/bootstrap-reboot.scss"
    },
    {
      "hash": "sha256-cLKzuDwhBobnxq834lb3i6KLDEmUfxfY+DYGh719AoI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/bootstrap-utilities.scss"
    },
    {
      "hash": "sha256-MPah/JVQKMGN2qFTAFCECckl0Umif8gaVsTWEG4Y1VQ=",
      "url": "assets_old/scss/material-dashboard/bootstrap/bootstrap.scss"
    },
    {
      "hash": "sha256-48y/u7yfFtHhv9fUj0yUjwBfLGfaD/5U7O4RhIBxxLI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_floating-labels.scss"
    },
    {
      "hash": "sha256-vE1gK4Ugzl4z1+Doj2W+lychWVsZDQ8W1/JybkpvnAU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_form-check.scss"
    },
    {
      "hash": "sha256-ijcdLKRoNI9QeKaKMr2mZimUZ6MOfxgnbOL/g846OHo=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_form-control.scss"
    },
    {
      "hash": "sha256-b+3m+cbEI1EKLNygKO/cra67N6jx4VJWPyknUQ5fY30=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_form-range.scss"
    },
    {
      "hash": "sha256-fuNvmtIhUb0EJa1q3WXjSt/PQoucKYpykcbOARfmKVI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_form-select.scss"
    },
    {
      "hash": "sha256-grSlvamURdoncKgbvVOCeI+27my4sLfej3sTVe/wLUs=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_form-text.scss"
    },
    {
      "hash": "sha256-E3J9UOP4CxihCpa9LmgwP1/sM7lBFHOYl5W31u5/IEE=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_input-group.scss"
    },
    {
      "hash": "sha256-gkwf1yD1SHOY/gerBRhhPw5HyJdNoyD5wNhmx/KEBlU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_labels.scss"
    },
    {
      "hash": "sha256-VhAdCAL4nORgaJoeKDuAczcRXMClilvsDOuMBj0XoGI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/forms/_validation.scss"
    },
    {
      "hash": "sha256-f9rnpdiJnEdEGfcsb4RS/uSQ2AlTZ4t7NK240OTnkKk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_clearfix.scss"
    },
    {
      "hash": "sha256-9ov/Dqx5rqEnySBzBjulSRtTMYVHBsFo6ZbkJJrESTk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_colored-links.scss"
    },
    {
      "hash": "sha256-/2LIyQSZTkr5EwwdPRCD1+vvS/xVrokpFRHZMYabqPk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_position.scss"
    },
    {
      "hash": "sha256-Q2eZlvRzMTdB5XCSvTQaqYW0e9jyAtWidBemdj4l6jE=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_ratio.scss"
    },
    {
      "hash": "sha256-LqLdiqjbxWIkyOanP1yauyenILg054keckWIejPobUA=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_stacks.scss"
    },
    {
      "hash": "sha256-vjSz6SCVaLcbC4MEYZnvO1WoEnfDX5k1Uq0jwGG2zyI=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_stretched-link.scss"
    },
    {
      "hash": "sha256-RskEeZ2bOGH7q42kJ5/5chXn1tVIBymwqTw23Q47Vzg=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_text-truncation.scss"
    },
    {
      "hash": "sha256-sib1VerR40KbmgTXBBZeIN3R8sg8DJWN4DaHZOZ/2Pg=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_visually-hidden.scss"
    },
    {
      "hash": "sha256-AyNCgntk7xdI4FxQsXil9ib1cPJHJDVyXtsfV12GK2k=",
      "url": "assets_old/scss/material-dashboard/bootstrap/helpers/_vr.scss"
    },
    {
      "hash": "sha256-xU+p2iuZk4UcLBn50efYZYZ2f+yMqbH8K/PkMzbNNRM=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_alert.scss"
    },
    {
      "hash": "sha256-77SLrz+104PWUYDOLG/InVR8UJIomx75Emh1m1gs8/c=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_backdrop.scss"
    },
    {
      "hash": "sha256-XUHARliU19oMYbWdYoYl9U9Cjgih5cWIw+ry3wWporg=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_border-radius.scss"
    },
    {
      "hash": "sha256-lvaPre4KsM3hpZrviVsL+4y31sIPXwKM+fJzo9gpNyY=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_box-shadow.scss"
    },
    {
      "hash": "sha256-w3+r8KnSAvlobVY43TDRo/BcgLWoxcnK33K1yFGHwZs=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_breakpoints.scss"
    },
    {
      "hash": "sha256-Ag7z7jJ21eNFLok39p1VZuiH3x/Bs2WGGkK0/av1hN4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_buttons.scss"
    },
    {
      "hash": "sha256-wdog4ZwZKOimaanlZNIAwV5hsqk3WbxG6GhMN947fgQ=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_caret.scss"
    },
    {
      "hash": "sha256-G8IJ6Hf6AjicAyIXhNvJI7f4RHRDw4ao88I1w31NPtw=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_clearfix.scss"
    },
    {
      "hash": "sha256-PUQkIqq/GAkEs5pOBHwJmzks8Z5D8WY0g6wo6RUC1aU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_color-scheme.scss"
    },
    {
      "hash": "sha256-21h6PXawdAJ6CMJ9+WOFT0kR7wZUBGVbXXXcWgPFpR4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_container.scss"
    },
    {
      "hash": "sha256-aQeApfVoImu3VfXmAa3RIK9lR0yPLgd2TW8QvbWG6xE=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_deprecate.scss"
    },
    {
      "hash": "sha256-9jCIuFWfBFF0EZiqAoQdkMY3WwHiW/KdjWuYhUSeVEU=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_forms.scss"
    },
    {
      "hash": "sha256-B+3XaF1kjw4fLFMD0lYDta+DlH+AiNgrC1sJ5OX360s=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_gradients.scss"
    },
    {
      "hash": "sha256-ztxMKECkwLl9dTcoDhsrQPTD4dcrgAcKT6hFAVYwTJk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_grid.scss"
    },
    {
      "hash": "sha256-khNvFnacIswOP5nSbayUEDUkCaMdTkonQGKiV0UoDkk=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_image.scss"
    },
    {
      "hash": "sha256-0j2Qg/9hyaTQhchFsCpOR8Yls0nc83XLzVecipunve4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_list-group.scss"
    },
    {
      "hash": "sha256-hHF/vH/EHOK6Bst1Qu+/XOymICLzLN1Izqg5wVjjFiQ=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_lists.scss"
    },
    {
      "hash": "sha256-y66cIIqLygberGm7Xim5bfD9ZBemuioqOZq0knqJ4og=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_pagination.scss"
    },
    {
      "hash": "sha256-dM+tPrWqpwGohjqRW+jKYghY/2W7zUKDLoRaFnQfJFM=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_reset-text.scss"
    },
    {
      "hash": "sha256-p/Cn0vmQTkm3CWm2LYIAdC+FQlKZ77NOLnUdNaQTKs4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_resize.scss"
    },
    {
      "hash": "sha256-YWllqr5SQQULd7KAleoT3PiQ3gFoZ7fMdqcvuAA/dH4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_table-variants.scss"
    },
    {
      "hash": "sha256-6F6n5gJaigYf5lsncGvhsf12/DFkxMkdZyf5GgBVrhw=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_text-truncate.scss"
    },
    {
      "hash": "sha256-jUUxBldKvwI0TPCdrBzA8QIsfafCZ9Q+Sh2o19sYqkQ=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_transition.scss"
    },
    {
      "hash": "sha256-WI373A4SFwvdegoDEejxtkcXgUACjejfV0UxpOcVtwc=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_utilities.scss"
    },
    {
      "hash": "sha256-B3+m+JErTCE0OLrOJNfBe+RwcjzUjlqE3c76YAeXOs4=",
      "url": "assets_old/scss/material-dashboard/bootstrap/mixins/_visually-hidden.scss"
    },
    {
      "hash": "sha256-J1u2wMqzSJbTzd0+7iuJfJaklC1YIWRtuZssLZJSpJw=",
      "url": "assets_old/scss/material-dashboard/bootstrap/utilities/_api.scss"
    },
    {
      "hash": "sha256-UdxmDPoUwqf4bHFywW7GaH3SIa1cTdDmI0vqTocJMdg=",
      "url": "assets_old/scss/material-dashboard/bootstrap/vendor/_rfs.scss"
    },
    {
      "hash": "sha256-Zxh6zDPM7ArNCfHsZfJW/yJI3kdXTBIPD3K4npvGACo=",
      "url": "assets_old/scss/material-dashboard/cards/card-background.scss"
    },
    {
      "hash": "sha256-RaHWZLDWWmp2CUxi25J0iRmvaMHxIAwFVUX8ibg4sh0=",
      "url": "assets_old/scss/material-dashboard/cards/card-blog.scss"
    },
    {
      "hash": "sha256-XBzXM5/PrBh9VCA7hNGvlF0189N+HKSgK85sV1E/nnE=",
      "url": "assets_old/scss/material-dashboard/cards/card-horizontal.scss"
    },
    {
      "hash": "sha256-JUp9umV25B34BRodAvoWGKmFIvw+M46G3ugcxrp8g20=",
      "url": "assets_old/scss/material-dashboard/cards/card-pricing.scss"
    },
    {
      "hash": "sha256-7uwC+AXytH82adZ1YNlDKrUYA41/fB2wITA/fl/CrSM=",
      "url": "assets_old/scss/material-dashboard/cards/card-profile.scss"
    },
    {
      "hash": "sha256-Y4nGsXkiN2v7Mv1qHvVob40NKYhFG/QHJRikbY5uEjo=",
      "url": "assets_old/scss/material-dashboard/cards/card-rotate.scss"
    },
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": "assets_old/scss/material-dashboard/custom/_styles.scss"
    },
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": "assets_old/scss/material-dashboard/custom/_variables.scss"
    },
    {
      "hash": "sha256-29PgMwNy7Zg3KnKxIZfQuPyYsBbO6XN3ve3uOMQyZxk=",
      "url": "assets_old/scss/material-dashboard/forms/_form-check.scss"
    },
    {
      "hash": "sha256-3JA1r06IRQsF2hhuRu2izVi5s2XNbwZz8DF/kelHp9w=",
      "url": "assets_old/scss/material-dashboard/forms/_form-select.scss"
    },
    {
      "hash": "sha256-UzDGUgXfWtxNRJ6lHROH35tSu/Wvqfn8GW686F9nTxU=",
      "url": "assets_old/scss/material-dashboard/forms/_form-switch.scss"
    },
    {
      "hash": "sha256-WTeG301D43b3n+l0FM8pXSa7GmOnGB1duT7LrBL5q3A=",
      "url": "assets_old/scss/material-dashboard/forms/_forms.scss"
    },
    {
      "hash": "sha256-xfM5hPFs3YtfZBRewOhBBmpphYDKE8ldltTvzmJJbgo=",
      "url": "assets_old/scss/material-dashboard/forms/_input-group.scss"
    },
    {
      "hash": "sha256-M+EE16fCW6d/BaY+ynpkaJdfxXtZx9syeySIIJC3dT0=",
      "url": "assets_old/scss/material-dashboard/forms/_inputs.scss"
    },
    {
      "hash": "sha256-tBkXOqecd2Pp/zBOyXgqt/mbjzvvV4KvagNR36ce8T8=",
      "url": "assets_old/scss/material-dashboard/forms/_labels.scss"
    },
    {
      "hash": "sha256-m9U/DfGtqfmkOefhWTXqrmMWExwcyh2WHLkPg1nY0Eg=",
      "url": "assets_old/scss/material-dashboard/mixins/_badge.scss"
    },
    {
      "hash": "sha256-GSgs86bYjTGE4NErsA8QKezmVBzFAF16dTesnvYrsMw=",
      "url": "assets_old/scss/material-dashboard/mixins/_buttons.scss"
    },
    {
      "hash": "sha256-uNy6y1Oy7TPpaMFG8bIwZojd6nFJujyK5sTSvp5jS3Y=",
      "url": "assets_old/scss/material-dashboard/mixins/_colored-shadows.scss"
    },
    {
      "hash": "sha256-IVhj8BVqGToWORy95i99jvyPFxcsSL7P/sOKSZFPcuw=",
      "url": "assets_old/scss/material-dashboard/mixins/_hover.scss"
    },
    {
      "hash": "sha256-UCXUpn2eNxIi9HpENBjuqw+AXWGGsry8Wu7MVuhLJUw=",
      "url": "assets_old/scss/material-dashboard/mixins/_social-buttons.scss"
    },
    {
      "hash": "sha256-b9qw2YuajXC8bDfjrVwKKz+93PGmu69+uBIVvhZ7yeg=",
      "url": "assets_old/scss/material-dashboard/mixins/_vendor.scss"
    },
    {
      "hash": "sha256-mXAVFxi//TT/Qt+suJi9ixEDYbrEorSotQFiWLOqqWQ=",
      "url": "assets_old/scss/material-dashboard/mixins/mixins.scss"
    },
    {
      "hash": "sha256-m8lFzDQba8NCpCM4sRcuJpBq7Gw6KAfHOQZxyXPBpy0=",
      "url": "assets_old/scss/material-dashboard/plugins/free/_flatpickr.scss"
    },
    {
      "hash": "sha256-SE0odqowRSmdp2f7fDK/B6YqJ2YkNu5MlgZ9Ii8TkyE=",
      "url": "assets_old/scss/material-dashboard/plugins/free/_nouislider.scss"
    },
    {
      "hash": "sha256-e2UIyejgTejr/sXeLOHEMDvEagonkoPv9+JIwckAqRs=",
      "url": "assets_old/scss/material-dashboard/plugins/free/_perfect-scrollbar.scss"
    },
    {
      "hash": "sha256-zOYMxD3BkRgc4XKTFRPku2dT4c21qu/eL6ISMTBUFSg=",
      "url": "assets_old/scss/material-dashboard/plugins/free/_prism.scss"
    },
    {
      "hash": "sha256-yEg98DzeNGI9xJR6FQ+b28VTmeSfv7RwgZtjD6DD3F8=",
      "url": "assets_old/scss/material-dashboard/plugins/free/plugins.scss"
    },
    {
      "hash": "sha256-phj7iSFT9V1qalTAI7FXs1rA+z2PQlak1YG8WLljsvk=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_carousel-slick.scss"
    },
    {
      "hash": "sha256-HwIQhS4aGGHH087Kpx3baJoesLn37xrCMLvwYhQ8l9o=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_choices.scss"
    },
    {
      "hash": "sha256-t58uq0wmvCUlsF1K26ZE5MwMOfhKkwgKfpX+0ZEZX+0=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_datatable-extend.scss"
    },
    {
      "hash": "sha256-t9NhnBuvxMd9pDFugpZz3pc4MIUFDK/ywTwh6S42vjg=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_datatable.scss"
    },
    {
      "hash": "sha256-EYSmiSz2daAX5Xq+m8lxGFf+qWABUgdCPUvU5X0vpI4=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_dragula.scss"
    },
    {
      "hash": "sha256-tcFZRmq/3072pzpJaP0RPPONCNBnuJKAU9nB50rs5+s=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_dropzone.scss"
    },
    {
      "hash": "sha256-08XKG8oprJVOvFULT1AaNCo2/ZcQG1g1zsMTLz1esSw=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_fullcalendar-extend.scss"
    },
    {
      "hash": "sha256-B8acxQmEHhFu6mxiJy4LftX5A/6OScJlz8k7SuHN4LU=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_fullcalendar.scss"
    },
    {
      "hash": "sha256-h1iyS03ECBQiLboEPysVV7pMm+iNfeK47LeDF/E+wJ8=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_glidejs.scss"
    },
    {
      "hash": "sha256-LnrX5cPYFq7lTpTx0O6MNAWs5G94BdfzW96+JsGBheo=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_highlight.scss"
    },
    {
      "hash": "sha256-g9F6fAmrfON289dsMim470AEVGGwBVCNZNzJ0dgyUZg=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_kanban.scss"
    },
    {
      "hash": "sha256-2dSBEaTTLTQSdI+XU51IrHKxz0zvuM9N3B7o+Ddkb7c=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_leaflet.scss"
    },
    {
      "hash": "sha256-N8qsEr0Xw+iEWLJFhEZl7Wnzx0bBVROGErWmlFPvSwo=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_list-check.scss"
    },
    {
      "hash": "sha256-gLwcrYL4V4y3nwFo7uS9IUD8we3TNmPN615pAfA258Y=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_photoswipe.scss"
    },
    {
      "hash": "sha256-3+o+4t3GCbuoEQYsgr/mKi3UwAaMhjbbH8UUpaFSzqk=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_quill.scss"
    },
    {
      "hash": "sha256-Qhyx/Bxi4A6ns7ZdeGZk1yAomnM+rIdxxTif6SHgUTU=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_rating-widget.scss"
    },
    {
      "hash": "sha256-0RsIDope+gi+tWH5uiRn2T3Jgtwp2bS1jKdplkl68og=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_sweetalert2-extend.scss"
    },
    {
      "hash": "sha256-v1uWvUtKHnXrPnqX0orAgoL0hodz4BHLDfEulK8HAnc=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_sweetalert2.scss"
    },
    {
      "hash": "sha256-gFtc4r7a/ld+s0LJI3wpVNfhi8CHTtR5T3e1znvc+sU=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/_vector-map.scss"
    },
    {
      "hash": "sha256-vp1uWEV8y3vUENpWQ82TDDKdtGdPF/Hdz6rrAAC/Vss=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/multi-step.scss"
    },
    {
      "hash": "sha256-7SfonYvg37wh4ywny63iDC1qV3Vx7PHwvDa26f9E51g=",
      "url": "assets_old/scss/material-dashboard/plugins/pro/plugins-extend.scss"
    },
    {
      "hash": "sha256-+tRq7DV+Q3Bp9V9wGiQ/X9pP/vCa/gi3362djXElV5o=",
      "url": "assets_old/scss/material-dashboard/theme-pro.scss"
    },
    {
      "hash": "sha256-D+Q3ijcrt6pKXHwIif60eiID244iwuofFl6Gc3nCvhU=",
      "url": "assets_old/scss/material-dashboard/theme.scss"
    },
    {
      "hash": "sha256-dIXXpyjJ2Bht1ess5SJsNrbPPXUtP/QA+vWrMXl1rKI=",
      "url": "assets_old/scss/material-dashboard/variables/_animations.scss"
    },
    {
      "hash": "sha256-+QaQWPxugfyDxlN1bzKIve4ErhxPgtdQsdC/kgSBcd8=",
      "url": "assets_old/scss/material-dashboard/variables/_avatars.scss"
    },
    {
      "hash": "sha256-MgxQ3d7kdTRjjXGecBRttdd7NwCSsbiy40GdpN+xGhc=",
      "url": "assets_old/scss/material-dashboard/variables/_badge.scss"
    },
    {
      "hash": "sha256-Z3R4fhqAAffNV/y4MVhE6j99pTsmitjAXkJLDQEydCM=",
      "url": "assets_old/scss/material-dashboard/variables/_breadcrumb.scss"
    },
    {
      "hash": "sha256-GXb7fmKet61ibswV6ofC0JAmYDTZdTWjNagR5bvR6IY=",
      "url": "assets_old/scss/material-dashboard/variables/_cards-extend.scss"
    },
    {
      "hash": "sha256-aYNdyKZAh+wOakUgNdSGCQSlNB3YYRFwpqJzXCB1nbU=",
      "url": "assets_old/scss/material-dashboard/variables/_cards.scss"
    },
    {
      "hash": "sha256-auK5EvRng1ajkLa9ZdF/F9r69oNxWPFKn1qnBScb+V8=",
      "url": "assets_old/scss/material-dashboard/variables/_choices.scss"
    },
    {
      "hash": "sha256-JLqoWrpWLUWiFrPl7zL6KDeZFfUJM6kPQv+BbwpyjFQ=",
      "url": "assets_old/scss/material-dashboard/variables/_dark-version.scss"
    },
    {
      "hash": "sha256-FG7V4FqPB0jJqd/BT+xzpnVgKNZVvk9pNubFAVdu7RA=",
      "url": "assets_old/scss/material-dashboard/variables/_dropdowns.scss"
    },
    {
      "hash": "sha256-QUlriy0NbxtiDt//1EfkxqV2bl2Ia/DmmhdRWKzBX1w=",
      "url": "assets_old/scss/material-dashboard/variables/_fixed-plugin.scss"
    },
    {
      "hash": "sha256-dY7Tf2qTuxjHgQ4DiMTmFmhdbcgAys9MWqKUJYjW8ng=",
      "url": "assets_old/scss/material-dashboard/variables/_form-switch.scss"
    },
    {
      "hash": "sha256-6HeGrDH5sE0jE9LzYWpd6rthsej9IfZoEw77+tNOqnA=",
      "url": "assets_old/scss/material-dashboard/variables/_full-calendar.scss"
    },
    {
      "hash": "sha256-GuENvtpwbj+S3IQsIzEYGudS5OG9zhhQp1hREZ30pGo=",
      "url": "assets_old/scss/material-dashboard/variables/_header.scss"
    },
    {
      "hash": "sha256-rf4X+ZWOP/yPtcnrtwet7AgZRq8QZ32KFu7kpBiI47A=",
      "url": "assets_old/scss/material-dashboard/variables/_info-areas.scss"
    },
    {
      "hash": "sha256-Eav2dy40VPVtWQ9ozS1EU30VHaGcHri/JY7H1ZT9WJk=",
      "url": "assets_old/scss/material-dashboard/variables/_misc-extend.scss"
    },
    {
      "hash": "sha256-dPjzDfAWE/kUdx/iN/2O4rOgdbu6MUhLDJmo0xmW/nc=",
      "url": "assets_old/scss/material-dashboard/variables/_misc.scss"
    },
    {
      "hash": "sha256-xvND8rMrDxo+o2G5uxDnRNb67TkQFrcRyaakQkSpl0s=",
      "url": "assets_old/scss/material-dashboard/variables/_navbar-vertical.scss"
    },
    {
      "hash": "sha256-MdYSBHua7AHQugrhPx5YFDVy7cqI/Iml+8pw97W3pn4=",
      "url": "assets_old/scss/material-dashboard/variables/_navbar.scss"
    },
    {
      "hash": "sha256-pNIQEdPp5tuYoWpl4BmrNa/vJz146K+r9b5jJk1UeyU=",
      "url": "assets_old/scss/material-dashboard/variables/_pagination.scss"
    },
    {
      "hash": "sha256-2rEtAIyUm0r3qFyZoQBg5oR5YDYsAwC4vhtL5nSnPnY=",
      "url": "assets_old/scss/material-dashboard/variables/_ripple.scss"
    },
    {
      "hash": "sha256-cAfLtaS6L3uC4M1ZAGM0zjgN4DR53ilObEowQCovlaE=",
      "url": "assets_old/scss/material-dashboard/variables/_rtl.scss"
    },
    {
      "hash": "sha256-e0CkZVqxylFzkzJCaUwmaZbFQkHyETDLrSBfTDO29yY=",
      "url": "assets_old/scss/material-dashboard/variables/_social-buttons.scss"
    },
    {
      "hash": "sha256-kZygTUr2ndZslyeqmFnGaO48TQeQVNJ1W3c3tRq7p4c=",
      "url": "assets_old/scss/material-dashboard/variables/_table.scss"
    },
    {
      "hash": "sha256-4fnGPQHZHtq1M7y5I5IMMgX71ysqqGfmJ17gVfuLxjo=",
      "url": "assets_old/scss/material-dashboard/variables/_timeline.scss"
    },
    {
      "hash": "sha256-ycvoZwbQTrYMDSnEd4J3JGRbyLenc4v8LYnTgkK5ieg=",
      "url": "assets_old/scss/material-dashboard/variables/_utilities-extend.scss"
    },
    {
      "hash": "sha256-mPqX8uuDZjFGgGFFB8sqzZsAHE3ltPrqMm0XxbCDJRA=",
      "url": "assets_old/scss/material-dashboard/variables/_utilities.scss"
    },
    {
      "hash": "sha256-c/Pv+3acprWwjhWmzXV4tAOiP5uiySZA3lxaoMRUdEE=",
      "url": "assets_old/scss/material-dashboard/variables/_virtual-reality.scss"
    },
    {
      "hash": "sha256-/nthMD7osWCqLVltq7tw9P/q+OokiRAE6bHQ0od2OLE=",
      "url": "bootstrap-icons/bootstrap-icons.svg"
    },
    {
      "hash": "sha256-AEMichyFVzMXWbxt2qy7aJsPBxXWiK7IK9BW0tW1zDs=",
      "url": "bootstrap-icons/font/bootstrap-icons.css"
    },
    {
      "hash": "sha256-HJ3h46qqG7pZZ7rH6tp5R1CC3Ya0pBlV5Y08JWmyPPA=",
      "url": "bootstrap-icons/font/bootstrap-icons.json"
    },
    {
      "hash": "sha256-pdY4ejLKO67E0CM2tbPtq1DJ3VGDVVdqAR6j3ZwdiE4=",
      "url": "bootstrap-icons/font/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-9VUTt7WRy4SjuH/w406iTUgx1v7cIuVLkRymS1tUShU=",
      "url": "bootstrap-icons/font/fonts/bootstrap-icons.woff"
    },
    {
      "hash": "sha256-bHVxA2ShylYEJncW9tKJl7JjGf2weM8R4LQqtm/y6mE=",
      "url": "bootstrap-icons/font/fonts/bootstrap-icons.woff2"
    },
    {
      "hash": "sha256-CgoKPtvHkyTETBVtMNzXSShQ02LXnyEh/a2K3+BPk1A=",
      "url": "bootstrap-icons/icons/0-circle-fill.svg"
    },
    {
      "hash": "sha256-KOZBUdwwZYg869+kTm7ge9PRFoHFSq8SGGz3M2DjTWo=",
      "url": "bootstrap-icons/icons/0-circle.svg"
    },
    {
      "hash": "sha256-vI+/CzzgknR7Lg9JYdCFukvaXcGCwbJd/70GgNMRASg=",
      "url": "bootstrap-icons/icons/0-square-fill.svg"
    },
    {
      "hash": "sha256-TRjN+0PrZS4PgWbKAA+o23GbnDa6DC8x/E+O0XvENxk=",
      "url": "bootstrap-icons/icons/0-square.svg"
    },
    {
      "hash": "sha256-nvkQd20pyG7/PBqCmetKxItxK5SOqFdH1gWgV6Omij4=",
      "url": "bootstrap-icons/icons/1-circle-fill.svg"
    },
    {
      "hash": "sha256-tXgKR1k1vW+mNCJJmHRKIEQ0CmFhfzTGH8ElU0Adcdo=",
      "url": "bootstrap-icons/icons/1-circle.svg"
    },
    {
      "hash": "sha256-OfHju8vxZhAD7D6XRLGTSprQxBgphkvwf73+j6O6AI0=",
      "url": "bootstrap-icons/icons/1-square-fill.svg"
    },
    {
      "hash": "sha256-PohXev5Uk4MXvS8yhswijMB2ZmXFw5idAw1FPVJjVRk=",
      "url": "bootstrap-icons/icons/1-square.svg"
    },
    {
      "hash": "sha256-WQbiLvwhQL4qAruJVowrFZH6LLgBNWSBJVkM0M25KQ0=",
      "url": "bootstrap-icons/icons/123.svg"
    },
    {
      "hash": "sha256-KbF+XuldIwH09zhSaR3vVpNdao/SS0xRjsLbLagMer8=",
      "url": "bootstrap-icons/icons/2-circle-fill.svg"
    },
    {
      "hash": "sha256-4WnPhwQteLJF9PtX3uR4CZcreka6LAB1+lcctXO5ju0=",
      "url": "bootstrap-icons/icons/2-circle.svg"
    },
    {
      "hash": "sha256-b4qmKdM9KcyrvUweQYtp+1PnwT8LEupnbEcL7/P35/I=",
      "url": "bootstrap-icons/icons/2-square-fill.svg"
    },
    {
      "hash": "sha256-+jevuahd50qqRaxLPAtu7rCfQkD3ESgDJSRReJ3F/Lc=",
      "url": "bootstrap-icons/icons/2-square.svg"
    },
    {
      "hash": "sha256-0HnPR5NE0G6rU0yqTMyx3yCig68dr8AoAQc3Dh+xOc0=",
      "url": "bootstrap-icons/icons/3-circle-fill.svg"
    },
    {
      "hash": "sha256-yZ7nBkohhKOMie77NU8AqT462ierVlDHddG8kLPrZWI=",
      "url": "bootstrap-icons/icons/3-circle.svg"
    },
    {
      "hash": "sha256-Rr6OR85/uCvoH8QGovrLCIDW2yzTk2YfiafYRe8j5Pg=",
      "url": "bootstrap-icons/icons/3-square-fill.svg"
    },
    {
      "hash": "sha256-Rf7TA3V2HJlYk6NMRLEuWMm9d8aQ3XNHfN1zNeibzyM=",
      "url": "bootstrap-icons/icons/3-square.svg"
    },
    {
      "hash": "sha256-AVQSJCO24dlUwWJwxssoJmNPeoygZFlMx1Y7QlOOFn8=",
      "url": "bootstrap-icons/icons/4-circle-fill.svg"
    },
    {
      "hash": "sha256-73peR58tzNiO0HBUxHqZtDcVXhYy5v/VjrHDwUVN8rY=",
      "url": "bootstrap-icons/icons/4-circle.svg"
    },
    {
      "hash": "sha256-X4i/b6Dc0KIFdPn5OSb8krrYqLtnT8ESKNydQ1wuLg4=",
      "url": "bootstrap-icons/icons/4-square-fill.svg"
    },
    {
      "hash": "sha256-lFWm88/JZKIApCufezZlSQ8t+e8abgIeAiJxOm+4pXk=",
      "url": "bootstrap-icons/icons/4-square.svg"
    },
    {
      "hash": "sha256-mul3mnr3TA9MoCyu4xdI2PMO1AmV8Otq3J4HenMNw0o=",
      "url": "bootstrap-icons/icons/5-circle-fill.svg"
    },
    {
      "hash": "sha256-g9QcDYBVkSxsqzhd9PJjowf9kadzlkbPaaEeUeXmBd0=",
      "url": "bootstrap-icons/icons/5-circle.svg"
    },
    {
      "hash": "sha256-KeS6WUcb0NBfWmwn8JOzJo0QTgHL8OAVk0yn/RGX/oI=",
      "url": "bootstrap-icons/icons/5-square-fill.svg"
    },
    {
      "hash": "sha256-KZF3iiO9AOvYTJ+8+3KU3CQ9xVYRJQadwFm27FSiA8k=",
      "url": "bootstrap-icons/icons/5-square.svg"
    },
    {
      "hash": "sha256-5BPMQWESu6sWlJtK+wZCv1panyLU/OWfbbkwezefE5c=",
      "url": "bootstrap-icons/icons/6-circle-fill.svg"
    },
    {
      "hash": "sha256-IwNkqHnoA33wyWvXJVl7kUsqYVo5+GRLXy4MJioOd0c=",
      "url": "bootstrap-icons/icons/6-circle.svg"
    },
    {
      "hash": "sha256-CVCRtG7ZeCsGR/n+zAAFAKOvGwHGo2keYAdf9nCDceY=",
      "url": "bootstrap-icons/icons/6-square-fill.svg"
    },
    {
      "hash": "sha256-vNT+VuNQ6s+adITUuz2kddiNxNHPUn3qIz0XXuBKfiE=",
      "url": "bootstrap-icons/icons/6-square.svg"
    },
    {
      "hash": "sha256-oVPjyy68M/CJtAfcHlbv/gH4Qr79YEiQONWxYlYSRh8=",
      "url": "bootstrap-icons/icons/7-circle-fill.svg"
    },
    {
      "hash": "sha256-N6TVSAwkh7U07jkCA2am1ij1PsjEee3NQ3eO2nOr1Ik=",
      "url": "bootstrap-icons/icons/7-circle.svg"
    },
    {
      "hash": "sha256-a9kVwJYJQHUchE/2I9W4Bqf2KJlhsDdKyU0cS2k8mv8=",
      "url": "bootstrap-icons/icons/7-square-fill.svg"
    },
    {
      "hash": "sha256-rBaSWxU5EDq2OXSRqrmxdZz/tVTTqpEhV4A3p/56jPg=",
      "url": "bootstrap-icons/icons/7-square.svg"
    },
    {
      "hash": "sha256-IiByz0CQAK0G2tZz+vaHgYPUtzxagbYe5E3zzu5d5lY=",
      "url": "bootstrap-icons/icons/8-circle-fill.svg"
    },
    {
      "hash": "sha256-QBX66CZGVNUBUeil2rUFNc13mB9mhMf6KvVljCa4kVk=",
      "url": "bootstrap-icons/icons/8-circle.svg"
    },
    {
      "hash": "sha256-FAHCV5xx5XQN0+CMEGMl4Y+uP5KVFMnb8odvv5A5lxM=",
      "url": "bootstrap-icons/icons/8-square-fill.svg"
    },
    {
      "hash": "sha256-T4fsmKNbFHpaFitnTPDeSc0n4jpux7sZyxWITLfmFfg=",
      "url": "bootstrap-icons/icons/8-square.svg"
    },
    {
      "hash": "sha256-py+bMPeLmJwqeS8rYsgg+6EPmhe780s8Qt0thhjbrEk=",
      "url": "bootstrap-icons/icons/9-circle-fill.svg"
    },
    {
      "hash": "sha256-yGGxL+qZcjoXPrcJPPlmUiM1a85EeWCnFTIYDvTNlf8=",
      "url": "bootstrap-icons/icons/9-circle.svg"
    },
    {
      "hash": "sha256-+hWE4p873K2JwTTy2hvlZ+LDmJQ+rTX7PNMOU/PZlgM=",
      "url": "bootstrap-icons/icons/9-square-fill.svg"
    },
    {
      "hash": "sha256-LeyGV32iQ56Crk+AYelV7yGejW3UH9sV8lnYQ95xmqU=",
      "url": "bootstrap-icons/icons/9-square.svg"
    },
    {
      "hash": "sha256-Nm3PVQiFvDY1r3z7+kUCElZXNNWrTM+i8pcl2hARRCM=",
      "url": "bootstrap-icons/icons/activity.svg"
    },
    {
      "hash": "sha256-aQsTzEo8Ake1qzfn0XBIpPgySG6489Md1ZWnfUhuNn0=",
      "url": "bootstrap-icons/icons/airplane-engines-fill.svg"
    },
    {
      "hash": "sha256-q404XIqbYFLaXJijXFHddn0LxDecuravCbbOXaYHh2Q=",
      "url": "bootstrap-icons/icons/airplane-engines.svg"
    },
    {
      "hash": "sha256-BXr5kFZrF89839ogLqYrraGKvbs4FeX2LaLY4rQFHNA=",
      "url": "bootstrap-icons/icons/airplane-fill.svg"
    },
    {
      "hash": "sha256-2R6cXg5IeQ1btN8PzZqf6lAZUAwLZQxZUT0k3Q+o8OM=",
      "url": "bootstrap-icons/icons/airplane.svg"
    },
    {
      "hash": "sha256-vwf1D5/TtGndYTuH3yTAU1IYZ6yMf0l58gWOXCVmaME=",
      "url": "bootstrap-icons/icons/alarm-fill.svg"
    },
    {
      "hash": "sha256-uFy51vnxkgHT+5fox9I7mG+ysM8LLRmsUSFYAd5WZ5g=",
      "url": "bootstrap-icons/icons/alarm.svg"
    },
    {
      "hash": "sha256-NyqrXsPagzF8PcbFKCoKBvNhg9NIVRI0FWiuDOW+85Y=",
      "url": "bootstrap-icons/icons/alexa.svg"
    },
    {
      "hash": "sha256-vGibcrUbiFRAgJAaIH+9519Lkr2gst+Cf4KCr6kK9L8=",
      "url": "bootstrap-icons/icons/align-bottom.svg"
    },
    {
      "hash": "sha256-9A/FHI1wQcRpPWmU7EwT2kjuuoxfDR+ssAtL8g5O3lc=",
      "url": "bootstrap-icons/icons/align-center.svg"
    },
    {
      "hash": "sha256-4qGDuEWkOdcgbObS+HvgDwFdhkJPmwGYrZmgWw9nLJI=",
      "url": "bootstrap-icons/icons/align-end.svg"
    },
    {
      "hash": "sha256-7qAaPPCgda8LiYPkmWWaqCYgDdro6FMR7S63LpaOats=",
      "url": "bootstrap-icons/icons/align-middle.svg"
    },
    {
      "hash": "sha256-Azcfpjb41ZP1eVgZqN6/mnXaKZQ/wDsY3VLQiI3slzY=",
      "url": "bootstrap-icons/icons/align-start.svg"
    },
    {
      "hash": "sha256-2F4AuysLiDVfdj1v3VY68atXvn8TKQReRe8jA/VRnEk=",
      "url": "bootstrap-icons/icons/align-top.svg"
    },
    {
      "hash": "sha256-1pAyNhdhDOMcYiGTWl/H/XFAkT0utciMYdDAKgkCG7c=",
      "url": "bootstrap-icons/icons/alipay.svg"
    },
    {
      "hash": "sha256-zZ/hRxMDuTKwdHRYN28zwSVu7o5c6b6MnsPKGWklASM=",
      "url": "bootstrap-icons/icons/alphabet-uppercase.svg"
    },
    {
      "hash": "sha256-6bggozRZ9nfJASJdPG6DMy8LEgoh9gLvOxL5D098DPE=",
      "url": "bootstrap-icons/icons/alphabet.svg"
    },
    {
      "hash": "sha256-r2enX86eIMNeVAy74woyE9TIygXm0j5Om+0tmPbNuyk=",
      "url": "bootstrap-icons/icons/alt.svg"
    },
    {
      "hash": "sha256-QD2PjgOSDu5CrFJkeqQuOnKj8YYsNMHWaypdguFL45I=",
      "url": "bootstrap-icons/icons/amazon.svg"
    },
    {
      "hash": "sha256-Qf4kYJCz+kBxdqu/7D9xY9UhrFbj2ZlXCIeoyxei7aU=",
      "url": "bootstrap-icons/icons/amd.svg"
    },
    {
      "hash": "sha256-0BgqT/eh2BUdrsZMu3kwFn45dc4yCDK+zntBgKxvL3Y=",
      "url": "bootstrap-icons/icons/android.svg"
    },
    {
      "hash": "sha256-4CM9a1u7d8zXqk4CdRCHwJV/sL9g09pT6xQFhUrPU5o=",
      "url": "bootstrap-icons/icons/android2.svg"
    },
    {
      "hash": "sha256-iSR0s/cJZOhOdPPUV6JRXe7Jfeut2E/4K33wRV+bemk=",
      "url": "bootstrap-icons/icons/anthropic.svg"
    },
    {
      "hash": "sha256-ftnHm6TrRmCGMAAlkbscCrqxwFa7jgJAeikdQRJRTRw=",
      "url": "bootstrap-icons/icons/app-indicator.svg"
    },
    {
      "hash": "sha256-CM2BPNN/VZ04Wg9/JfCFx+EHUmOy9I127dRKKUPE2sA=",
      "url": "bootstrap-icons/icons/app.svg"
    },
    {
      "hash": "sha256-QDaInTa2ixYFvqluMolLOYpD9KnixhGdbgpnQrO8NVU=",
      "url": "bootstrap-icons/icons/apple-music.svg"
    },
    {
      "hash": "sha256-Dq6fUADQnFAPBr80QprZHGTWnSIzsUrLZbq+yzdFlrY=",
      "url": "bootstrap-icons/icons/apple.svg"
    },
    {
      "hash": "sha256-ZDxUgwBSXov9I8ER3txklylzFfSHyuFESkK1wU/4hhA=",
      "url": "bootstrap-icons/icons/archive-fill.svg"
    },
    {
      "hash": "sha256-bUh+LIgnb2yI3hPjtyWhxZ13L4bXuIFwGkDwGyda5Go=",
      "url": "bootstrap-icons/icons/archive.svg"
    },
    {
      "hash": "sha256-waDavCfxaaBDM1Hcpi7/LtqgZXYGNhgWhab6hUHkVtQ=",
      "url": "bootstrap-icons/icons/arrow-90deg-down.svg"
    },
    {
      "hash": "sha256-GR7b8DUXmOLZhbGAdkXHhbf0LDLRq4JsYOTw/Ct9P4o=",
      "url": "bootstrap-icons/icons/arrow-90deg-left.svg"
    },
    {
      "hash": "sha256-MJbjVZ5QBPAIaJWBTr8ofSJPQ41yqkyTQZ4/myylVwg=",
      "url": "bootstrap-icons/icons/arrow-90deg-right.svg"
    },
    {
      "hash": "sha256-G3ElhwYNg60l0c3Ii5xBY6n/jsIx8DpKEz0D8TImCQQ=",
      "url": "bootstrap-icons/icons/arrow-90deg-up.svg"
    },
    {
      "hash": "sha256-K0gjI8zL8o5uDXUx6dUtsvRC8YNLjM7+XrSwf2ydHpA=",
      "url": "bootstrap-icons/icons/arrow-bar-down.svg"
    },
    {
      "hash": "sha256-epPQcBxWfccpEAm2a0Jo4gb36Hf/aY2wHwnmxYyqieE=",
      "url": "bootstrap-icons/icons/arrow-bar-left.svg"
    },
    {
      "hash": "sha256-y0WDWsMkil8lhKOrsBIj2WQ6A8reAIVhMIStr3kjpP0=",
      "url": "bootstrap-icons/icons/arrow-bar-right.svg"
    },
    {
      "hash": "sha256-WEmyQnWdR+g6id625YJRDz+Hh2Dz7eCOXndWMVpD79M=",
      "url": "bootstrap-icons/icons/arrow-bar-up.svg"
    },
    {
      "hash": "sha256-Y6XPm9XI5rc85gMKHIEqCauXvosf9aoNWzN1G8QVFww=",
      "url": "bootstrap-icons/icons/arrow-clockwise.svg"
    },
    {
      "hash": "sha256-YyUnou4jhrgp/HInk33kCvbiWU0SCnI9M0EInNOso9o=",
      "url": "bootstrap-icons/icons/arrow-counterclockwise.svg"
    },
    {
      "hash": "sha256-A89NrqNthUjUqWriyPIaB7xcbG98+QIcDK9TrQVC2sM=",
      "url": "bootstrap-icons/icons/arrow-down-circle-fill.svg"
    },
    {
      "hash": "sha256-kytarMTLnXp5Us3p78CO5ub4cdQYEpvf3IrQL6c7kqo=",
      "url": "bootstrap-icons/icons/arrow-down-circle.svg"
    },
    {
      "hash": "sha256-q3LN0JB7GU/WIuMY/4VtBBxo/tWWfl6l9iHeOCmHuzQ=",
      "url": "bootstrap-icons/icons/arrow-down-left-circle-fill.svg"
    },
    {
      "hash": "sha256-BUV45wuVmGJYu52uIlONEpQ9Uc+z5dedPoNZK3jYd3M=",
      "url": "bootstrap-icons/icons/arrow-down-left-circle.svg"
    },
    {
      "hash": "sha256-1aQRut3miq8DGE6HZdWrk0SBMiD2rxpYb22kicL7H9g=",
      "url": "bootstrap-icons/icons/arrow-down-left-square-fill.svg"
    },
    {
      "hash": "sha256-30ibYg1+heQ7G42U0sCLBq01M6sHXJLbvHUbOzjn0ww=",
      "url": "bootstrap-icons/icons/arrow-down-left-square.svg"
    },
    {
      "hash": "sha256-4ClqHNR51DFeWLl138krbtID13St0qMNuIoQdi2XUjQ=",
      "url": "bootstrap-icons/icons/arrow-down-left.svg"
    },
    {
      "hash": "sha256-/VsuEEcPzMwrfcCn3SPS0ejO/QaEMtyKf05QwcSaV6A=",
      "url": "bootstrap-icons/icons/arrow-down-right-circle-fill.svg"
    },
    {
      "hash": "sha256-yC/UD9JUqpQreQ3XwxKt4z4ltDJd4x1QitYqOvc8J+0=",
      "url": "bootstrap-icons/icons/arrow-down-right-circle.svg"
    },
    {
      "hash": "sha256-DlA85lnIvAFUsabHb1moVLRAc9ZblA14Bmej3QSo5rM=",
      "url": "bootstrap-icons/icons/arrow-down-right-square-fill.svg"
    },
    {
      "hash": "sha256-9GCdoGd9O3gAcYJUo7fMUKUpgEznPKcXrEbM1vOnE/8=",
      "url": "bootstrap-icons/icons/arrow-down-right-square.svg"
    },
    {
      "hash": "sha256-XejN1y/uhGRfUk9AZ5pFRVCkRgncwPHu5REA+YyzcNI=",
      "url": "bootstrap-icons/icons/arrow-down-right.svg"
    },
    {
      "hash": "sha256-LaBCKcdlPvmRAU9VGNGEo/+GVHUjfIuZlYO1rYgLBgQ=",
      "url": "bootstrap-icons/icons/arrow-down-short.svg"
    },
    {
      "hash": "sha256-16bWliga1htD2fHFS8iB3E7iWrqCuf7U5BKyxdVMqGI=",
      "url": "bootstrap-icons/icons/arrow-down-square-fill.svg"
    },
    {
      "hash": "sha256-d73yb+TJHLw2UcsVzhKmaUtvjaOgz0NZYxbIwl59a7A=",
      "url": "bootstrap-icons/icons/arrow-down-square.svg"
    },
    {
      "hash": "sha256-aq+UWnaNdO60EHbDl3MlYrVotGa3iakY4+B7m3bQoxc=",
      "url": "bootstrap-icons/icons/arrow-down-up.svg"
    },
    {
      "hash": "sha256-nSrgahtPdmWRRQgIhXxytpNTReSy2ONtZMMcTVADzZs=",
      "url": "bootstrap-icons/icons/arrow-down.svg"
    },
    {
      "hash": "sha256-rgi9ibIETq+CJtkTQggOAo8+13S69FWZKbMM3B5TlN0=",
      "url": "bootstrap-icons/icons/arrow-left-circle-fill.svg"
    },
    {
      "hash": "sha256-kGOhRvKgCILtXOdFx5rWBLtZPJNl3sqOO7z4yzkMLq4=",
      "url": "bootstrap-icons/icons/arrow-left-circle.svg"
    },
    {
      "hash": "sha256-F5iyXObFnjqtIq6//2e8as75Mwx1r1nXuXXEU8FWU+0=",
      "url": "bootstrap-icons/icons/arrow-left-right.svg"
    },
    {
      "hash": "sha256-F8XshIozNguH3Id8LdyYzCrodPfVAfGUkpc8156w4HU=",
      "url": "bootstrap-icons/icons/arrow-left-short.svg"
    },
    {
      "hash": "sha256-vBFYpkO8NlG2DvIYCQXkJ0hi13I1rj2ncA0jgFAEIOk=",
      "url": "bootstrap-icons/icons/arrow-left-square-fill.svg"
    },
    {
      "hash": "sha256-wmAxUwMG3nEOMi4pAjchnM4+JyZo7+09i0scg6/ma18=",
      "url": "bootstrap-icons/icons/arrow-left-square.svg"
    },
    {
      "hash": "sha256-507lIBzeGc3bJaOQLQ/3VTKXfj9jb+/Em2jYS3nnHb8=",
      "url": "bootstrap-icons/icons/arrow-left.svg"
    },
    {
      "hash": "sha256-JwX2Vy0n8jMDKaX4fm2GEGXSIe5W1ghw9gSG0qt0fIU=",
      "url": "bootstrap-icons/icons/arrow-repeat.svg"
    },
    {
      "hash": "sha256-qjS7HLPhjdzE1Snmqx2dl/cYR/ogzjm/ZI/KmJMxdi0=",
      "url": "bootstrap-icons/icons/arrow-return-left.svg"
    },
    {
      "hash": "sha256-oCfZ04YOVvw6fG5OgcBC6XbCXhTqBJgvObn2k+Dsxes=",
      "url": "bootstrap-icons/icons/arrow-return-right.svg"
    },
    {
      "hash": "sha256-V6D8cUqKPj7VvpEIPqXUkHIXHAvcB2wzkEd4n2oPWjE=",
      "url": "bootstrap-icons/icons/arrow-right-circle-fill.svg"
    },
    {
      "hash": "sha256-DcxWLn2ItKHNlM2f55ABjc3/UMGzIyDLVsGA8cCXCBk=",
      "url": "bootstrap-icons/icons/arrow-right-circle.svg"
    },
    {
      "hash": "sha256-B9ZFtAMlK6S0TdrfLPU5dCI8pa/Bjb0hzX/WoyA5yRk=",
      "url": "bootstrap-icons/icons/arrow-right-short.svg"
    },
    {
      "hash": "sha256-z92VvPMdFpXK5MhPo6ZHYFl+5LSwSGzpba4a6fIHIGo=",
      "url": "bootstrap-icons/icons/arrow-right-square-fill.svg"
    },
    {
      "hash": "sha256-H0IeqbU32ajT6T91WHl6PRfc+z3F5HqZ0zefGMATtrE=",
      "url": "bootstrap-icons/icons/arrow-right-square.svg"
    },
    {
      "hash": "sha256-7c/hGA3MKvt1Dxy0tFUkpc32YiqGKy51MgtOTwV/wow=",
      "url": "bootstrap-icons/icons/arrow-right.svg"
    },
    {
      "hash": "sha256-mPfzB7it8iCLdicur6S6Rdw/KccGZc7YZnAjpNTo1ps=",
      "url": "bootstrap-icons/icons/arrow-through-heart-fill.svg"
    },
    {
      "hash": "sha256-WQd8NH8Sfwm7OtzlAe6DgS5KjLc+alnhVU5ngqn+jfw=",
      "url": "bootstrap-icons/icons/arrow-through-heart.svg"
    },
    {
      "hash": "sha256-2X36hmtN82ubQPgwxzt8wiVbblkW0DvYmAlUsEGn9ZY=",
      "url": "bootstrap-icons/icons/arrow-up-circle-fill.svg"
    },
    {
      "hash": "sha256-RUF3JrSwH0Bso5tOzi2IrmDAerPo9tj0/u/HuJP8wQ8=",
      "url": "bootstrap-icons/icons/arrow-up-circle.svg"
    },
    {
      "hash": "sha256-JPWOsyhXFc2GDbeB99kHVROP2P41BWFpcBs8n239onA=",
      "url": "bootstrap-icons/icons/arrow-up-left-circle-fill.svg"
    },
    {
      "hash": "sha256-kFi/Gt+0HVH+xvYIHX3sBp4xmGPoRIFTS31YZlI8FPI=",
      "url": "bootstrap-icons/icons/arrow-up-left-circle.svg"
    },
    {
      "hash": "sha256-C72jd18kybDnzQBBnLmoOlG8gwvPl+iMqr+ndDIF7Co=",
      "url": "bootstrap-icons/icons/arrow-up-left-square-fill.svg"
    },
    {
      "hash": "sha256-Kfar6fk9HvM1Ua8JBNNrsXYrNAEsTCMQBZK5L494hLg=",
      "url": "bootstrap-icons/icons/arrow-up-left-square.svg"
    },
    {
      "hash": "sha256-I05v75Az01GnG3yvgq5JXfDu6y4KJNgwmErNhmOiyuw=",
      "url": "bootstrap-icons/icons/arrow-up-left.svg"
    },
    {
      "hash": "sha256-HEMa669yGxg3qiReE+42fOR2JeBpLoSythQGSbe4HPo=",
      "url": "bootstrap-icons/icons/arrow-up-right-circle-fill.svg"
    },
    {
      "hash": "sha256-l/QJf+Z4SXjRmSz0Ka3WUl/gyZDvhxOy9mWILKFmrK8=",
      "url": "bootstrap-icons/icons/arrow-up-right-circle.svg"
    },
    {
      "hash": "sha256-8X4EhjbGauDj7bPUsqs6/7zPASvu4EpNXCrQKOZZNhg=",
      "url": "bootstrap-icons/icons/arrow-up-right-square-fill.svg"
    },
    {
      "hash": "sha256-MxsEP5EqebB+XNfYr0npZDXmO0BjRAf3ijjnFkWL1zc=",
      "url": "bootstrap-icons/icons/arrow-up-right-square.svg"
    },
    {
      "hash": "sha256-ncMDYaPFghbwL/o+IFI2UaNuNOBhnYDreFAF5buK+Ps=",
      "url": "bootstrap-icons/icons/arrow-up-right.svg"
    },
    {
      "hash": "sha256-ehvydWEaP/XoQaorDyygSqetCrRyp4kdab/aRc8ELKk=",
      "url": "bootstrap-icons/icons/arrow-up-short.svg"
    },
    {
      "hash": "sha256-7ZCbjmAXeiUjvwjOSQ3c008XlN8wTUG/oucXEUHi9MQ=",
      "url": "bootstrap-icons/icons/arrow-up-square-fill.svg"
    },
    {
      "hash": "sha256-tGGjgwMYRMmHBGKFnRj2C42Uh3aTCrwG/YZHXmhtXJM=",
      "url": "bootstrap-icons/icons/arrow-up-square.svg"
    },
    {
      "hash": "sha256-tthnkHgaxHXSD1Tq2ChOJrqt0vuGclBFXPeqcDC9fOM=",
      "url": "bootstrap-icons/icons/arrow-up.svg"
    },
    {
      "hash": "sha256-fchCDZT90VK0zJKSIToe3FoSJXFLCSea+fWH2yBejww=",
      "url": "bootstrap-icons/icons/arrows-angle-contract.svg"
    },
    {
      "hash": "sha256-qYiwdQv/UK3DTDyipSLc4Ikzz0MJHCR8xflLbg1Lmmc=",
      "url": "bootstrap-icons/icons/arrows-angle-expand.svg"
    },
    {
      "hash": "sha256-I9Kv6XW6aaQTciFT//Q99DaczGNZc69GnAxkyVRHoAQ=",
      "url": "bootstrap-icons/icons/arrows-collapse-vertical.svg"
    },
    {
      "hash": "sha256-TKPgGvVDmB2y4kArlHVJI3F911IpSEF3cN6w+0d9hRA=",
      "url": "bootstrap-icons/icons/arrows-collapse.svg"
    },
    {
      "hash": "sha256-LFMBQiKAAk5fkcUpDCCalspvRbVxB01Xf0w44JJr4bQ=",
      "url": "bootstrap-icons/icons/arrows-expand-vertical.svg"
    },
    {
      "hash": "sha256-ZyeT7kcg9fALhoNyHElQDzm4C6HkiciMmp5PkEq7wo8=",
      "url": "bootstrap-icons/icons/arrows-expand.svg"
    },
    {
      "hash": "sha256-LWe8Qn8udmeV7AKc0u8ks+u9MG/3aucpdQjae2pggb8=",
      "url": "bootstrap-icons/icons/arrows-fullscreen.svg"
    },
    {
      "hash": "sha256-5e0CLl3WrCHhecQ8DJylESgqplTewgE4m4Xo2V3KucE=",
      "url": "bootstrap-icons/icons/arrows-move.svg"
    },
    {
      "hash": "sha256-+ukTsCn8EPrbOLqbLinIvhu8cU+SYzmC8jsbY2/a5Ro=",
      "url": "bootstrap-icons/icons/arrows-vertical.svg"
    },
    {
      "hash": "sha256-mEpB5ZsI/tr0l7EUYo02408Yn2K3DVrza9PCYVY4+w4=",
      "url": "bootstrap-icons/icons/arrows.svg"
    },
    {
      "hash": "sha256-9O5JGVRbpP9mxfRCdPQXc3AVanYVUQ8aPRNaFDpakQ8=",
      "url": "bootstrap-icons/icons/aspect-ratio-fill.svg"
    },
    {
      "hash": "sha256-Q2OtLUcbfXUvmvSu8gDveTf0SVZcfIYBSmJCd+FEFYg=",
      "url": "bootstrap-icons/icons/aspect-ratio.svg"
    },
    {
      "hash": "sha256-e3YzV4pSQGftcla0eJTWtH7PKfPHjQPWxdMlnC9RlWE=",
      "url": "bootstrap-icons/icons/asterisk.svg"
    },
    {
      "hash": "sha256-PfxnTuzwsuCYJh/CqVfLn6w/VLNkNWxe7sdZ7sZUny4=",
      "url": "bootstrap-icons/icons/at.svg"
    },
    {
      "hash": "sha256-lw6uGCc6YhxHS5/aEl0vouWvlUJ2oAnvxzRUVKBCqnw=",
      "url": "bootstrap-icons/icons/award-fill.svg"
    },
    {
      "hash": "sha256-1fVyXnWXyPfFefNnw4vjP3wZfr/epzB+8XKsXYOPukg=",
      "url": "bootstrap-icons/icons/award.svg"
    },
    {
      "hash": "sha256-9KSzb/cSabP8urUlDU/oageLbgmg4EJCsA6abjiY7HQ=",
      "url": "bootstrap-icons/icons/back.svg"
    },
    {
      "hash": "sha256-aikMihTfGW/o6TaJuAHlI2fulPWgNcJ9E9Zy+ut70rM=",
      "url": "bootstrap-icons/icons/backpack-fill.svg"
    },
    {
      "hash": "sha256-4d/5qKL4HIlm5915FJHPjum1xV3O6gQgt0AH87IDzQ4=",
      "url": "bootstrap-icons/icons/backpack.svg"
    },
    {
      "hash": "sha256-fhBXPYDY120l2JnqKPZ/wheLQB/idxAj10W6cnr7XVg=",
      "url": "bootstrap-icons/icons/backpack2-fill.svg"
    },
    {
      "hash": "sha256-IKweFbf0CjxluwpIaYTCdv/q0Y0bMhU3Qlz377meiWQ=",
      "url": "bootstrap-icons/icons/backpack2.svg"
    },
    {
      "hash": "sha256-nTg08rA+e0eubiM9uo/zJe2rXX0RIj6yzNt4GyLwP3U=",
      "url": "bootstrap-icons/icons/backpack3-fill.svg"
    },
    {
      "hash": "sha256-jsaThsX4A85rNCTdlG5vXaQzc3MxjWWId8LJ7VBWdYA=",
      "url": "bootstrap-icons/icons/backpack3.svg"
    },
    {
      "hash": "sha256-zpk81RyE3id7o9uazdtfo0HnZx7zEfsZlY+Anzu0k9M=",
      "url": "bootstrap-icons/icons/backpack4-fill.svg"
    },
    {
      "hash": "sha256-ls1ueRwozC8B64Psb31eKP5sjfEVTHkR+7lcxxfb6WM=",
      "url": "bootstrap-icons/icons/backpack4.svg"
    },
    {
      "hash": "sha256-mkSq93EZviheopG7Jt8yIkeXnqoNjkV+/w1MFaZZ42w=",
      "url": "bootstrap-icons/icons/backspace-fill.svg"
    },
    {
      "hash": "sha256-7ADS1TI/raxEiKZT9Mio/GJeFTvUfTPPrWuJMWG7lD8=",
      "url": "bootstrap-icons/icons/backspace-reverse-fill.svg"
    },
    {
      "hash": "sha256-XaiP8pmm2hDqwlsGZ1kgd1IuS8N3KmV71iMun5XJlkA=",
      "url": "bootstrap-icons/icons/backspace-reverse.svg"
    },
    {
      "hash": "sha256-1nZbVNrFYRv+77iKif6H3uwcV3GXV9Ut4rO453HbtGc=",
      "url": "bootstrap-icons/icons/backspace.svg"
    },
    {
      "hash": "sha256-tPLYkxj130lum6dz/QpcIkwRhRd5bAlcm7KVhcYL8WQ=",
      "url": "bootstrap-icons/icons/badge-3d-fill.svg"
    },
    {
      "hash": "sha256-9oHwzmKqvDz14MxR6spffmiEezFiHn4Wm6m1T6UD4WA=",
      "url": "bootstrap-icons/icons/badge-3d.svg"
    },
    {
      "hash": "sha256-nrG4CPt0GIBkfhprfXtE9BiPbiJsD+muClfhMYGf/cA=",
      "url": "bootstrap-icons/icons/badge-4k-fill.svg"
    },
    {
      "hash": "sha256-OH0UC1PtASfL4dWOfJ6CsbC591GbZaHL/YBdxFZpBbU=",
      "url": "bootstrap-icons/icons/badge-4k.svg"
    },
    {
      "hash": "sha256-+JHCY3VgzKUhMg/UTe12JaWSAQKIxQtpeuvYAwRp1KI=",
      "url": "bootstrap-icons/icons/badge-8k-fill.svg"
    },
    {
      "hash": "sha256-CXALSOCJdBDUU4xz6+AzTlRoWnWmbcrEzTI5OoLmTYg=",
      "url": "bootstrap-icons/icons/badge-8k.svg"
    },
    {
      "hash": "sha256-B9srsmkblbhGVFCxFPHZSI+oRunAFaPdtjuDLpV8dS0=",
      "url": "bootstrap-icons/icons/badge-ad-fill.svg"
    },
    {
      "hash": "sha256-EDGWNf76PwW9uS93HESzJ2C0YkZ7QOZxsSGc84clB20=",
      "url": "bootstrap-icons/icons/badge-ad.svg"
    },
    {
      "hash": "sha256-cVX//kU1v56iOXIARv1JTS3Jqddogs+WshZzDzRyok8=",
      "url": "bootstrap-icons/icons/badge-ar-fill.svg"
    },
    {
      "hash": "sha256-weERAcwHDHfxUp3GeK40Fg4egvrZ/p2dvMh2iZKGs4Q=",
      "url": "bootstrap-icons/icons/badge-ar.svg"
    },
    {
      "hash": "sha256-UypEL9YHVGj8qkVeUlxIkzXoo13g0Fn3QxmDD9IG7ZQ=",
      "url": "bootstrap-icons/icons/badge-cc-fill.svg"
    },
    {
      "hash": "sha256-oXN8uDHNeJyPSCSYc6e0BxX0U+afdei4GyoPM6h/Lss=",
      "url": "bootstrap-icons/icons/badge-cc.svg"
    },
    {
      "hash": "sha256-iMbIP7PPn8qM7E233pKZqS58Q54rgB90Pebzd9WfgvU=",
      "url": "bootstrap-icons/icons/badge-hd-fill.svg"
    },
    {
      "hash": "sha256-ORo2ey1ycrIGe4t8p743R+uYEhPcwLELPLmQTUogBZI=",
      "url": "bootstrap-icons/icons/badge-hd.svg"
    },
    {
      "hash": "sha256-ZCLIImgsfsOhv+z8g2ZGTTzBkb7W2LqEyd8dpL8ILXE=",
      "url": "bootstrap-icons/icons/badge-sd-fill.svg"
    },
    {
      "hash": "sha256-JQ9I2TIonvjD1L8I3UXFbOgc9rygEbZtYVtOQf+Aan4=",
      "url": "bootstrap-icons/icons/badge-sd.svg"
    },
    {
      "hash": "sha256-+HmLk4kWT/X/lueOaW3OP021zBvM4GFlOc7JTkzVOGA=",
      "url": "bootstrap-icons/icons/badge-tm-fill.svg"
    },
    {
      "hash": "sha256-9KMEb64+cUPIwnuy1JsCyDw+Kbnset014MtKGsx1pp4=",
      "url": "bootstrap-icons/icons/badge-tm.svg"
    },
    {
      "hash": "sha256-ZnoNl60nZ0C8faaCgEQdhnu38Ug3yR1xarbonIBYPyY=",
      "url": "bootstrap-icons/icons/badge-vo-fill.svg"
    },
    {
      "hash": "sha256-+yRzKOiO8W8BsCxW+61dC33wErNLEjVvloAsP947d3Y=",
      "url": "bootstrap-icons/icons/badge-vo.svg"
    },
    {
      "hash": "sha256-w0uAZxzqUtWY3+FsloMP3x1y20o87QDynpRfBMZS4zg=",
      "url": "bootstrap-icons/icons/badge-vr-fill.svg"
    },
    {
      "hash": "sha256-LP9tElKpg+mGdYETqunm6meVmP7jBPvoTewjyqL55uM=",
      "url": "bootstrap-icons/icons/badge-vr.svg"
    },
    {
      "hash": "sha256-MgpDhpfrKN+aqkGiYVPbo3Z/xmXjfRLPXzfdHAOEfYw=",
      "url": "bootstrap-icons/icons/badge-wc-fill.svg"
    },
    {
      "hash": "sha256-aCMDft59XloMcVHJasaF+uLxvbbiuVAEJvjHTLgldyc=",
      "url": "bootstrap-icons/icons/badge-wc.svg"
    },
    {
      "hash": "sha256-tfGGKoCG5FFJ0U0JwtxKpLqV9LgYqCbj0dTaDj+wqLI=",
      "url": "bootstrap-icons/icons/bag-check-fill.svg"
    },
    {
      "hash": "sha256-i9X7xlDs+H3HAfnwKNJkUs9UPCHrdCoZmtAsuwixMLQ=",
      "url": "bootstrap-icons/icons/bag-check.svg"
    },
    {
      "hash": "sha256-SAbrogINlW4buDWV7GNEcbupabGWlm5ZLXDezVHypmk=",
      "url": "bootstrap-icons/icons/bag-dash-fill.svg"
    },
    {
      "hash": "sha256-wgbiac1Ec5yYNnBbKpzgCrVc8wI5QoUD60n8/DDA9j4=",
      "url": "bootstrap-icons/icons/bag-dash.svg"
    },
    {
      "hash": "sha256-EFHCvlPu//+Pa265UOcYfdaffBE7hPvVE6ZYXkUkr6g=",
      "url": "bootstrap-icons/icons/bag-fill.svg"
    },
    {
      "hash": "sha256-+HwOmUQ0bncDRxUaOcSxvqN3SblTYSRRm9h0Tna21Po=",
      "url": "bootstrap-icons/icons/bag-heart-fill.svg"
    },
    {
      "hash": "sha256-ApnORAJH5N6rOq4yvZEJraMkFBseWEwBh7HExhkia/A=",
      "url": "bootstrap-icons/icons/bag-heart.svg"
    },
    {
      "hash": "sha256-vLRbGqKfEigPKZjPLYIkhUKlPhUVletQ/xv7DVDkVAs=",
      "url": "bootstrap-icons/icons/bag-plus-fill.svg"
    },
    {
      "hash": "sha256-TZ3CQzVhgwkHQCv6Z8vXYN+oWbnXhfja26m/TKnwHQg=",
      "url": "bootstrap-icons/icons/bag-plus.svg"
    },
    {
      "hash": "sha256-Kv1hn2UK3062IDiVekhQRgMCE8qy4fw9Pk8Ol8KQuyg=",
      "url": "bootstrap-icons/icons/bag-x-fill.svg"
    },
    {
      "hash": "sha256-tx4pYakes78QQLYKIdgfwEsvEQaRqLQIyYBESQGuIQc=",
      "url": "bootstrap-icons/icons/bag-x.svg"
    },
    {
      "hash": "sha256-bSlXsswctcobCPachkTtJa2YHv2cFTNZntZVC5MWdWk=",
      "url": "bootstrap-icons/icons/bag.svg"
    },
    {
      "hash": "sha256-Hl8V5r5yUB43BFLUj6ZYptB7bOMQr9tLUlfpJGILDWE=",
      "url": "bootstrap-icons/icons/balloon-fill.svg"
    },
    {
      "hash": "sha256-xRE0YO56InqN/IlR+OgaM+2p595oiHgUdmqW7oqqi6Y=",
      "url": "bootstrap-icons/icons/balloon-heart-fill.svg"
    },
    {
      "hash": "sha256-lIa5AX0hpqz2tersjR0VpxW7ouS5nUONvjmhwK7GegU=",
      "url": "bootstrap-icons/icons/balloon-heart.svg"
    },
    {
      "hash": "sha256-nNtwwPcz80G5Zkua9wrka0qBlfiME0OBYQ1WJ0cFmjA=",
      "url": "bootstrap-icons/icons/balloon.svg"
    },
    {
      "hash": "sha256-2a90u/xXsVNq0hVghXke/1AEXC0/X65LAsWFIJTTQ6I=",
      "url": "bootstrap-icons/icons/ban-fill.svg"
    },
    {
      "hash": "sha256-6bnOCw7/K4fK403RuToEl8hwezckUhp5deJ2c53H/q0=",
      "url": "bootstrap-icons/icons/ban.svg"
    },
    {
      "hash": "sha256-4WzD6fPAhWPWDJZUMAoK+FKmrDBFtiX+cVwXsM7kgxI=",
      "url": "bootstrap-icons/icons/bandaid-fill.svg"
    },
    {
      "hash": "sha256-V+ihhvT3wbavBp2aYho0kBKGOYb6gkVvJd7S6FCrxLA=",
      "url": "bootstrap-icons/icons/bandaid.svg"
    },
    {
      "hash": "sha256-r0tQgVhfgVtuHP1Lw4m70GyrCvXGcyYx6p5R61ehmPI=",
      "url": "bootstrap-icons/icons/bank.svg"
    },
    {
      "hash": "sha256-UiSvjD4K/RIYVDx3q+htk1DIgHeXBSGQg0fmwBkYkbU=",
      "url": "bootstrap-icons/icons/bank2.svg"
    },
    {
      "hash": "sha256-NTxOVed2WfXyT234gnE46wckFlwOlV4eMZt/fKTkGy4=",
      "url": "bootstrap-icons/icons/bar-chart-fill.svg"
    },
    {
      "hash": "sha256-7E2v0nV4xffTSXacmsH606TiS9PSYnAdgZoNwAtK5fM=",
      "url": "bootstrap-icons/icons/bar-chart-line-fill.svg"
    },
    {
      "hash": "sha256-Mcb7rfcqVeww6a/3BXaRNekmYtt5i1Vczrq0lNiuSzo=",
      "url": "bootstrap-icons/icons/bar-chart-line.svg"
    },
    {
      "hash": "sha256-MNETviApGKvK+U5pfvEblWliWa/xOgkh2VfRrwOePKg=",
      "url": "bootstrap-icons/icons/bar-chart-steps.svg"
    },
    {
      "hash": "sha256-fJa4mldu8elV2bUDJ0tiVm8Sih5RSNZUNe6vkBb+kb4=",
      "url": "bootstrap-icons/icons/bar-chart.svg"
    },
    {
      "hash": "sha256-dnlCDVk5WK7CyeIKRxw5MSsWS3/t9QnF/Yt5eQ/+4OI=",
      "url": "bootstrap-icons/icons/basket-fill.svg"
    },
    {
      "hash": "sha256-xOe5AFCIBNU90Ee6CbeyDuaPFZb5XD16FLHM6kZk/GI=",
      "url": "bootstrap-icons/icons/basket.svg"
    },
    {
      "hash": "sha256-L+z6KR/DThJyhf3G/794Q943W+WPrA/OX0r+Z2eWtBE=",
      "url": "bootstrap-icons/icons/basket2-fill.svg"
    },
    {
      "hash": "sha256-F/2t92UYihvaHHyEhLtDyLjQJ1EeTH3M539cKDgIaQk=",
      "url": "bootstrap-icons/icons/basket2.svg"
    },
    {
      "hash": "sha256-BJxSEniM0ovsJGW15JawidACgDQ0lsVWT2vIKxvLWMQ=",
      "url": "bootstrap-icons/icons/basket3-fill.svg"
    },
    {
      "hash": "sha256-mEWY+bRM/+Dcbh5t6qFl0APm/T3YTAS5erNRiGEIkMQ=",
      "url": "bootstrap-icons/icons/basket3.svg"
    },
    {
      "hash": "sha256-Zu5tuJzPdw3wLiQs1Waw4Ot3cVGGcPfDtAJxuuV2Fls=",
      "url": "bootstrap-icons/icons/battery-charging.svg"
    },
    {
      "hash": "sha256-OfKrhFAmE6zaCNREyzauKOXkcEn8iHgvv+Jg9bjrwqo=",
      "url": "bootstrap-icons/icons/battery-full.svg"
    },
    {
      "hash": "sha256-I4az5TFeclYXRaMFSjktwfZnCXYn8Ruh7eZ6wcIj2xk=",
      "url": "bootstrap-icons/icons/battery-half.svg"
    },
    {
      "hash": "sha256-qrk1Yc3i6iZBmdnEk6RQ+p3SE0iVUA9dG6wwFYaj+ao=",
      "url": "bootstrap-icons/icons/battery-low.svg"
    },
    {
      "hash": "sha256-jfTAMJThqwUPJFKo/V4jwjQ07QMFoz9i6nLLsD56Ygs=",
      "url": "bootstrap-icons/icons/battery.svg"
    },
    {
      "hash": "sha256-6VeGsk3wm0mcpXbpIDKQAPimuYefowYSEiZf8umigmE=",
      "url": "bootstrap-icons/icons/beaker-fill.svg"
    },
    {
      "hash": "sha256-QhsdQwCeruSzXH1T98WAOLwjsUTubnMN77wdmAF4n5E=",
      "url": "bootstrap-icons/icons/beaker.svg"
    },
    {
      "hash": "sha256-PJfdzERuq+aUD61HrpUPmDmV8gXjCI3Z7KaEhY/YDFA=",
      "url": "bootstrap-icons/icons/behance.svg"
    },
    {
      "hash": "sha256-5Gk6CmyiBe37dwLJC6LbN9mtM+BqvJqkYD1HboCz7c4=",
      "url": "bootstrap-icons/icons/bell-fill.svg"
    },
    {
      "hash": "sha256-An8loMSjnROvpNjzNV7f4DWl41quvDCrTNo8l5Pk1rY=",
      "url": "bootstrap-icons/icons/bell-slash-fill.svg"
    },
    {
      "hash": "sha256-W6aW5Gd2B+MOf62i2zwdRR5nLtyUTv65Y4F6jAJObCE=",
      "url": "bootstrap-icons/icons/bell-slash.svg"
    },
    {
      "hash": "sha256-Ad8117aOKyo1ruxpQUL01n+z5sPiON4eWl8rzzzyWmc=",
      "url": "bootstrap-icons/icons/bell.svg"
    },
    {
      "hash": "sha256-p+pX2wc90P3fJjpsRljACN5Ma1dhEjoWYmQHyhrbleA=",
      "url": "bootstrap-icons/icons/bezier.svg"
    },
    {
      "hash": "sha256-zB+wZbLyAaBTa7e5hkBhpXreKJAE3Sv98NXhboANnNg=",
      "url": "bootstrap-icons/icons/bezier2.svg"
    },
    {
      "hash": "sha256-5Yj8y0mV4vu+N90ZYnhYMtwaoUTNTITqlUfzjxh+tr8=",
      "url": "bootstrap-icons/icons/bicycle.svg"
    },
    {
      "hash": "sha256-GcXierNY7mRkn6/VJT2EjTpK/JM8KjX/MNfgpderVC0=",
      "url": "bootstrap-icons/icons/bing.svg"
    },
    {
      "hash": "sha256-R01mDoZVERRS0jBQ0eISBPqrLhrGcCPeXwHEjHzZ1Vk=",
      "url": "bootstrap-icons/icons/binoculars-fill.svg"
    },
    {
      "hash": "sha256-+0oVlca9hXbCWCy9nqt1CS/Zh5R4mVzTFVwFryNjJ+0=",
      "url": "bootstrap-icons/icons/binoculars.svg"
    },
    {
      "hash": "sha256-HVAz2FbysQarobKNHt0H4xDO+yhbNWi7BjTJopdiYAg=",
      "url": "bootstrap-icons/icons/blockquote-left.svg"
    },
    {
      "hash": "sha256-KEU3LU/dvZxYfrQEejS1otq5EzHsz1Qz5EzPwBt9vgs=",
      "url": "bootstrap-icons/icons/blockquote-right.svg"
    },
    {
      "hash": "sha256-O8zTiJ22CUGPlbqrJRB6C+uLdkLUnZDA+x+HKyoxPTc=",
      "url": "bootstrap-icons/icons/bluesky.svg"
    },
    {
      "hash": "sha256-EELVuCvk7cSRZWgoZfl8l9iFn3Vaiqz/vrBYTFylsbo=",
      "url": "bootstrap-icons/icons/bluetooth.svg"
    },
    {
      "hash": "sha256-tQAI2bM0si6I+RVmHHt4SaN6Zw1bDlCG2TMQuF2Ti3Y=",
      "url": "bootstrap-icons/icons/body-text.svg"
    },
    {
      "hash": "sha256-zT/wRQPlQvo3iiiNyLMCpVgkac0UjbUbpX1nfjTi2hs=",
      "url": "bootstrap-icons/icons/book-fill.svg"
    },
    {
      "hash": "sha256-DW6DBA0ZkVqxpme/w4a+toxZZPohROcJi7EZ1lqUh9w=",
      "url": "bootstrap-icons/icons/book-half.svg"
    },
    {
      "hash": "sha256-rjMOwWCbCkm6lGNegO7/rzgOGmGa/8w4gQZkB/rc2vs=",
      "url": "bootstrap-icons/icons/book.svg"
    },
    {
      "hash": "sha256-Nybw7+i9o8rXmG9X5Az2/43P5IvvDBRtnIVPBjBR8BA=",
      "url": "bootstrap-icons/icons/bookmark-check-fill.svg"
    },
    {
      "hash": "sha256-1puCMSlxJHvFi7PAbOuISiS1MrZwK6T0/jap2rgAgR0=",
      "url": "bootstrap-icons/icons/bookmark-check.svg"
    },
    {
      "hash": "sha256-xCVnZeegh9Rd6MZJr5QckfnLQSAWJG5AicnI4XasQ5c=",
      "url": "bootstrap-icons/icons/bookmark-dash-fill.svg"
    },
    {
      "hash": "sha256-SwG82N9Kxrkq8txBXfGYN9sbcaTJThpTGckWjzQtG0U=",
      "url": "bootstrap-icons/icons/bookmark-dash.svg"
    },
    {
      "hash": "sha256-FdkeKensXkTFKFPxd8rc1u/1vl2NxOJjkKzCqgUKv6s=",
      "url": "bootstrap-icons/icons/bookmark-fill.svg"
    },
    {
      "hash": "sha256-z1x3/WS3Qrvdti8uNakvoTqaSvf5efgykd6SsyodPXg=",
      "url": "bootstrap-icons/icons/bookmark-heart-fill.svg"
    },
    {
      "hash": "sha256-P4Ii4UdaCZgESn+VtQ/7BYIzwJaDwTQk6n93Lv496f8=",
      "url": "bootstrap-icons/icons/bookmark-heart.svg"
    },
    {
      "hash": "sha256-HPqroMlxFO+rilGNsNqDyZubXwjZtpK5KCKnGOk9Rz4=",
      "url": "bootstrap-icons/icons/bookmark-plus-fill.svg"
    },
    {
      "hash": "sha256-QYYkIJ5jhJSKS9coxfC0mSHbDS8Wy3BCmmpJpp3z8kE=",
      "url": "bootstrap-icons/icons/bookmark-plus.svg"
    },
    {
      "hash": "sha256-N0DVUo5CYKTnRzf8LXdneiPlSkeMRCjwGWMY5mzeg2Q=",
      "url": "bootstrap-icons/icons/bookmark-star-fill.svg"
    },
    {
      "hash": "sha256-aB7DvbHEfY+6tJTWbetlUN8uircgot3SFwXi2sKJ6ZU=",
      "url": "bootstrap-icons/icons/bookmark-star.svg"
    },
    {
      "hash": "sha256-GR5v/hEZVQUnyQH0O4Qsj/vYe3GsW69iinHWxc2cH74=",
      "url": "bootstrap-icons/icons/bookmark-x-fill.svg"
    },
    {
      "hash": "sha256-QeHwH4mAcpeEv5mW9/HAGEftOchEutO2uMWIUxT9d8Y=",
      "url": "bootstrap-icons/icons/bookmark-x.svg"
    },
    {
      "hash": "sha256-dv3GdjHlljb6OwiSstdJlU78fCReqTR8ijx/SrAS8H8=",
      "url": "bootstrap-icons/icons/bookmark.svg"
    },
    {
      "hash": "sha256-BjeV+tj1sNb5MxNCyLbPEcfabcXiQnMYC8eFSFZtxEU=",
      "url": "bootstrap-icons/icons/bookmarks-fill.svg"
    },
    {
      "hash": "sha256-G5eNp4WcGCbYGRkXrETovzMKzGffC7fYcS0l6qRXDn8=",
      "url": "bootstrap-icons/icons/bookmarks.svg"
    },
    {
      "hash": "sha256-zLpp4xjBCmIDx/oUMjVt7NklZxV6zw1V388PZd/6LOw=",
      "url": "bootstrap-icons/icons/bookshelf.svg"
    },
    {
      "hash": "sha256-iPOzqiOQwjtYAldI1oC5Qle7TvoGw8u6KHSvu6bCigE=",
      "url": "bootstrap-icons/icons/boombox-fill.svg"
    },
    {
      "hash": "sha256-jx7TBTKTajDi0EHJByt1E56QggZJKyiVTlyTHy2PF/k=",
      "url": "bootstrap-icons/icons/boombox.svg"
    },
    {
      "hash": "sha256-e18kQOePHI56sHfIT5yH9oc4qegr43cQezdDGf+1CwI=",
      "url": "bootstrap-icons/icons/bootstrap-fill.svg"
    },
    {
      "hash": "sha256-t75uTQbaPiS/4u/KwfLp1s9geNZ5XWWQZWlSqhY5hq8=",
      "url": "bootstrap-icons/icons/bootstrap-reboot.svg"
    },
    {
      "hash": "sha256-cGAZfrOKtfgBIaH5/cabj6m4BpVTYiNIB9EN8tu+UvE=",
      "url": "bootstrap-icons/icons/bootstrap.svg"
    },
    {
      "hash": "sha256-L7Kb7vuB61Y61UF5rxW/dIJG2I1VL22IWdz4ycJCjcU=",
      "url": "bootstrap-icons/icons/border-all.svg"
    },
    {
      "hash": "sha256-dmEOj2pfAEeXnYYTB2lTgCUoFftKbjBIV4FULpf7Z1M=",
      "url": "bootstrap-icons/icons/border-bottom.svg"
    },
    {
      "hash": "sha256-Jn9zqWrBmBKs5VfN3M/k3WFiQUbDYTFOymTIr7RQeT4=",
      "url": "bootstrap-icons/icons/border-center.svg"
    },
    {
      "hash": "sha256-XgSqqNBoanRjg09gGc3SmE4OuNU+HvUkobE2J9jyMTU=",
      "url": "bootstrap-icons/icons/border-inner.svg"
    },
    {
      "hash": "sha256-4U1IfucgD5W8HvBnGtyeF0ynOcHnVI4hx21no4gOrUQ=",
      "url": "bootstrap-icons/icons/border-left.svg"
    },
    {
      "hash": "sha256-e8hAZzdaN6a74CrnmLjAvqgTJ2z95zPkw8yBoJHlF+o=",
      "url": "bootstrap-icons/icons/border-middle.svg"
    },
    {
      "hash": "sha256-wg44waCOBXPgzEQ9b9/dMgMY7dOcxVytXDxuZy90S1Y=",
      "url": "bootstrap-icons/icons/border-outer.svg"
    },
    {
      "hash": "sha256-rFbga8giEdDA6pNdLFva2jXoPwbcke0VfAiTyJ56JKY=",
      "url": "bootstrap-icons/icons/border-right.svg"
    },
    {
      "hash": "sha256-4DMRDEYO01k97b/75bgCbcaZozR1ODTVHyZiI2dd8Zc=",
      "url": "bootstrap-icons/icons/border-style.svg"
    },
    {
      "hash": "sha256-Q229R91jC9onuw8SCDPNWfkoF/xKXZYP9jBbMrM60OA=",
      "url": "bootstrap-icons/icons/border-top.svg"
    },
    {
      "hash": "sha256-MqHjwrhoQgJmCxLgQ7eHVwUY8eh5cZ9XOQsh9Z/Pgcs=",
      "url": "bootstrap-icons/icons/border-width.svg"
    },
    {
      "hash": "sha256-scCYH+e9KSbB7vraEY8pmWkxg7u9gFnuRie5v9zlm9M=",
      "url": "bootstrap-icons/icons/border.svg"
    },
    {
      "hash": "sha256-+3l7T2OU/WwtmHk4BLb9mdUMOtJnZQ/2sNgd4BSUhA4=",
      "url": "bootstrap-icons/icons/bounding-box-circles.svg"
    },
    {
      "hash": "sha256-plOxM/wAt9UDMH3uYPvuovw4QpBGIE62ENm+S1m8TR0=",
      "url": "bootstrap-icons/icons/bounding-box.svg"
    },
    {
      "hash": "sha256-Udo/b3aObSiF1FKlEWpjxLErq43vsKAtp+D5+7I6KJE=",
      "url": "bootstrap-icons/icons/box-arrow-down-left.svg"
    },
    {
      "hash": "sha256-EiI+BiePrrVVAqmaOgvbC9i0iZTdCDTon4yLUTMgmQ8=",
      "url": "bootstrap-icons/icons/box-arrow-down-right.svg"
    },
    {
      "hash": "sha256-gXk1ttaQ0GRNW+ab/2taGMoaMenXyhMlTpjTXGzPr8A=",
      "url": "bootstrap-icons/icons/box-arrow-down.svg"
    },
    {
      "hash": "sha256-icLFrrG4os+mjLyWeRsHO0HXWn8J0JGKTMBIofzNkbE=",
      "url": "bootstrap-icons/icons/box-arrow-in-down-left.svg"
    },
    {
      "hash": "sha256-Ew+Snp3J7ymnpHUDDtxuLd8PxxbcHzAgUty6SKO4Vzo=",
      "url": "bootstrap-icons/icons/box-arrow-in-down-right.svg"
    },
    {
      "hash": "sha256-M7FSX3lfiYUaLC3NBnfaJ2YO+V1w/h9Vzac27xcF6U4=",
      "url": "bootstrap-icons/icons/box-arrow-in-down.svg"
    },
    {
      "hash": "sha256-7G5Z0WbRglPx3RXlb94XiPxgimH5sB3oO9bt5Ocd7Go=",
      "url": "bootstrap-icons/icons/box-arrow-in-left.svg"
    },
    {
      "hash": "sha256-PSv5A+f4A1w8UDr31flQAxHynlzsFlSAm6X1l4mKsDw=",
      "url": "bootstrap-icons/icons/box-arrow-in-right.svg"
    },
    {
      "hash": "sha256-PPbF/Kt3jgZvn3yy+uV9GLnOq7ZyKG0OgCFmrUeicmU=",
      "url": "bootstrap-icons/icons/box-arrow-in-up-left.svg"
    },
    {
      "hash": "sha256-AbMDqTNElfc/q2I8puUrmXE/dc4p6/3df3WDjeGcpbg=",
      "url": "bootstrap-icons/icons/box-arrow-in-up-right.svg"
    },
    {
      "hash": "sha256-3N6BUQwF9i3HfeOVWhBLZoJR8DnCPPnJZBIvo8lwq3A=",
      "url": "bootstrap-icons/icons/box-arrow-in-up.svg"
    },
    {
      "hash": "sha256-CtAGf/6UxTSqcoe5W3+GZ4dcJ/Cwvoh1YS3WI3fPQJU=",
      "url": "bootstrap-icons/icons/box-arrow-left.svg"
    },
    {
      "hash": "sha256-oewzeBkKQUApVjvRMm2N5tPFhzJs1Qa3jTDFwFnLkQc=",
      "url": "bootstrap-icons/icons/box-arrow-right.svg"
    },
    {
      "hash": "sha256-X1/OhlDxvoAYqO+4N/KjqgwZMJhpXJnLwOL2FEqPw+U=",
      "url": "bootstrap-icons/icons/box-arrow-up-left.svg"
    },
    {
      "hash": "sha256-tEP74XHSsEgeCAeE2P49yGvuxvZLDuQonIFN/QraZ5w=",
      "url": "bootstrap-icons/icons/box-arrow-up-right.svg"
    },
    {
      "hash": "sha256-wS7LJRTO+SY8d8pPCuG29EkNMTEhsrl4FXS2E1Fk8nA=",
      "url": "bootstrap-icons/icons/box-arrow-up.svg"
    },
    {
      "hash": "sha256-MZjCaOFSTUPc/ZaiNMZwKmYcOndEzYHBr75piyXdRCo=",
      "url": "bootstrap-icons/icons/box-fill.svg"
    },
    {
      "hash": "sha256-f4m8ufZyjsiG7Be/0vc4dJVXQVWYV3NM9Y/9MBtZIg8=",
      "url": "bootstrap-icons/icons/box-seam-fill.svg"
    },
    {
      "hash": "sha256-ZsGcIMC58A2XN82/8uMcUSb+FPvYbSnAHmZzihz9CV4=",
      "url": "bootstrap-icons/icons/box-seam.svg"
    },
    {
      "hash": "sha256-sd/q5vbuwcNaUbkjFRSUO8+p6ATHLhUTUttFVafRz1E=",
      "url": "bootstrap-icons/icons/box.svg"
    },
    {
      "hash": "sha256-aJFispMO8nk2ntypF+0TiUdS61JgGZxpM7ojgmmKtjg=",
      "url": "bootstrap-icons/icons/box2-fill.svg"
    },
    {
      "hash": "sha256-VmzcnVBCiHvZ3d8qA+8XRlMJf5dTDtd0rAV1mm1nnV0=",
      "url": "bootstrap-icons/icons/box2-heart-fill.svg"
    },
    {
      "hash": "sha256-QE3ygBtHSxX7i30zBlCqZvfWs5qLPz74oD6LjO/AOTA=",
      "url": "bootstrap-icons/icons/box2-heart.svg"
    },
    {
      "hash": "sha256-SzbGV++aoGSYFkuUwtSKIaEl70FKFRmSi92KKxU7LKk=",
      "url": "bootstrap-icons/icons/box2.svg"
    },
    {
      "hash": "sha256-rS1AEi/0C2tOmQT2MCdmOjOq9fbIoui5msW/DfFSFYo=",
      "url": "bootstrap-icons/icons/boxes.svg"
    },
    {
      "hash": "sha256-cKFkLlcAR+79e6DMwFhnv/485WFG6yRlC9rms75YtRk=",
      "url": "bootstrap-icons/icons/braces-asterisk.svg"
    },
    {
      "hash": "sha256-2Qs1NibDIuNEMt9FcHTHy91uI/UHlGekmoqkzHtKcA0=",
      "url": "bootstrap-icons/icons/braces.svg"
    },
    {
      "hash": "sha256-LgK3uNlY6pEa3cxkScdvvFg2qhtccfkXOXN2hW7gjvs=",
      "url": "bootstrap-icons/icons/bricks.svg"
    },
    {
      "hash": "sha256-qHQMjsU5H91wK2m+Cinra3JYCLlKIOyvRXuPSYSD98k=",
      "url": "bootstrap-icons/icons/briefcase-fill.svg"
    },
    {
      "hash": "sha256-k+B6n1qaYgchcpodcoBfStrxM0tqtQGbDTRG7Lg2RtE=",
      "url": "bootstrap-icons/icons/briefcase.svg"
    },
    {
      "hash": "sha256-B3eO+vzJ6swiVQK3qmDmRFB976NeeCDui/LSMUJKB2Q=",
      "url": "bootstrap-icons/icons/brightness-alt-high-fill.svg"
    },
    {
      "hash": "sha256-V9wgC5OpTiM1VXjp/LGLK0BQjUXPX7kDY0VLtpo71zU=",
      "url": "bootstrap-icons/icons/brightness-alt-high.svg"
    },
    {
      "hash": "sha256-pXQrOC73yVuBEf8vfGAmwUCDmr5PdgcQ53C7BnRXcvg=",
      "url": "bootstrap-icons/icons/brightness-alt-low-fill.svg"
    },
    {
      "hash": "sha256-d7E+cxdUdfjctOD+AH9aDIA8uy906gYsgjXV9KkvoC8=",
      "url": "bootstrap-icons/icons/brightness-alt-low.svg"
    },
    {
      "hash": "sha256-tuK0EzrAiKsgmrep93OZhKQkj8sN5vZHxxoAnfG2J/U=",
      "url": "bootstrap-icons/icons/brightness-high-fill.svg"
    },
    {
      "hash": "sha256-Z/sExUUjUw3Ej19FNQDjYpJ6vTMUZ8B2brUKxWOZnSg=",
      "url": "bootstrap-icons/icons/brightness-high.svg"
    },
    {
      "hash": "sha256-tlYjVR+dUya3WDV/hPrtltHC91Mdpj48vIvNtApv/qI=",
      "url": "bootstrap-icons/icons/brightness-low-fill.svg"
    },
    {
      "hash": "sha256-kNbLvWxaAiFqAMwYcDFfehhpI788g9l48EGsMvHG2Kk=",
      "url": "bootstrap-icons/icons/brightness-low.svg"
    },
    {
      "hash": "sha256-VNt3JVrUgNzaFB/R0WKVqofslghb8xepkKaP5Jtcewk=",
      "url": "bootstrap-icons/icons/brilliance.svg"
    },
    {
      "hash": "sha256-UlYTGz4pYcSESbPbixy50HC8Oe51OTpUTgaMrKxRtYU=",
      "url": "bootstrap-icons/icons/broadcast-pin.svg"
    },
    {
      "hash": "sha256-JBsWA/JGrQEsmOdDYXMYVm+cwWpaKCnUaSrFWuhOSmk=",
      "url": "bootstrap-icons/icons/broadcast.svg"
    },
    {
      "hash": "sha256-Prp9RJEYgsQXrysbNkDK+Zw5PHSOWDA6J2T21wmuKlc=",
      "url": "bootstrap-icons/icons/browser-chrome.svg"
    },
    {
      "hash": "sha256-7zbwaRztcoxLBgqp8diNstNuAobk4Nyyu1Z8J08Geh0=",
      "url": "bootstrap-icons/icons/browser-edge.svg"
    },
    {
      "hash": "sha256-D8DCThsKCjyJWq2VKOOXuI3W/cU22skhxSQUE5ZOjcw=",
      "url": "bootstrap-icons/icons/browser-firefox.svg"
    },
    {
      "hash": "sha256-5f3e0WCUrHTq9fWoj9yp2h2PPj98s9pl3l3l454noGA=",
      "url": "bootstrap-icons/icons/browser-safari.svg"
    },
    {
      "hash": "sha256-CZK8pQlzCXvhmXM5mVG+thWLTHAKMbFLnbjTk1FIK58=",
      "url": "bootstrap-icons/icons/brush-fill.svg"
    },
    {
      "hash": "sha256-r7mj5TnhT15x26t4kY3uzVgTDk+2bAiNK0lenqJ4ZE8=",
      "url": "bootstrap-icons/icons/brush.svg"
    },
    {
      "hash": "sha256-IAGGOBquSpWt8r9k5ZrVEmEDklulycCWBFuFEbmVeHg=",
      "url": "bootstrap-icons/icons/bucket-fill.svg"
    },
    {
      "hash": "sha256-zFeuejPCj3ecdTJIwcmhE4/C9bhWaGvT8amascKm3ls=",
      "url": "bootstrap-icons/icons/bucket.svg"
    },
    {
      "hash": "sha256-55S/iiqL8YmWG0o7VcnNnzuw2J+1GlcdvrrA+2O3Oos=",
      "url": "bootstrap-icons/icons/bug-fill.svg"
    },
    {
      "hash": "sha256-esfz5TtzXrviG+3F9+NJbsyT6b+7uW5MM01B6nNjiSE=",
      "url": "bootstrap-icons/icons/bug.svg"
    },
    {
      "hash": "sha256-rF+H6ngGy52THk9AxvzkI+lcK8jegiSpAHOYSB2GMMM=",
      "url": "bootstrap-icons/icons/building-add.svg"
    },
    {
      "hash": "sha256-Smntr/PZo0pcw1ok/JTBb9dKwgbNjbG37++rbO6pBlQ=",
      "url": "bootstrap-icons/icons/building-check.svg"
    },
    {
      "hash": "sha256-od+viKfZHlgJUKzRRDDThj9qJcaa5VYCv92My9286mY=",
      "url": "bootstrap-icons/icons/building-dash.svg"
    },
    {
      "hash": "sha256-bhLKJMZXZpswu13xeHzXUHwWzqzqTL1YEAcMoQfRmu0=",
      "url": "bootstrap-icons/icons/building-down.svg"
    },
    {
      "hash": "sha256-zQW05sE/PJlCvB6LlfYw0EcbytmWIxZjdxrPSfCTJeE=",
      "url": "bootstrap-icons/icons/building-exclamation.svg"
    },
    {
      "hash": "sha256-565mLy/f3ggCL8tIYg/tXMMRAeGZR/YoAvsFSrgwKsw=",
      "url": "bootstrap-icons/icons/building-fill-add.svg"
    },
    {
      "hash": "sha256-H8YI+CWBc8/B9RJwJYnVCb8PctMalitRYTfJPirQ0+Q=",
      "url": "bootstrap-icons/icons/building-fill-check.svg"
    },
    {
      "hash": "sha256-IbBf747jlOUf3XRMvWg91o5GaZNm1vdKMtrx6UAdLG4=",
      "url": "bootstrap-icons/icons/building-fill-dash.svg"
    },
    {
      "hash": "sha256-E8mcTp/Jcki6+AyPjM2PRtQD2gdUyONxNO62yZZpqTo=",
      "url": "bootstrap-icons/icons/building-fill-down.svg"
    },
    {
      "hash": "sha256-/yh8f/OSHwhiWnwLJ/eadhlszXbxvDkdQr3ermXHJvg=",
      "url": "bootstrap-icons/icons/building-fill-exclamation.svg"
    },
    {
      "hash": "sha256-j0Vd6JoACIcZHuO92TTNYHrbCdQHmUKCcmXBFk8vSaY=",
      "url": "bootstrap-icons/icons/building-fill-gear.svg"
    },
    {
      "hash": "sha256-Jg6mMqvcCAoqByAElOJa9ybkAKRyzsNe9bAt6b5eINw=",
      "url": "bootstrap-icons/icons/building-fill-lock.svg"
    },
    {
      "hash": "sha256-wCkynZ34/oLrpJYDJfyGRGnSvHRNMwbd3oCZOSDoozU=",
      "url": "bootstrap-icons/icons/building-fill-slash.svg"
    },
    {
      "hash": "sha256-KRgZgKsadE30tFARMh3e1N3JXin2+W1PFPQwlXxjGlE=",
      "url": "bootstrap-icons/icons/building-fill-up.svg"
    },
    {
      "hash": "sha256-v19Q/6TcciRWaDjvKImo7lPt8IdO7v2NaS36wQBUf2Y=",
      "url": "bootstrap-icons/icons/building-fill-x.svg"
    },
    {
      "hash": "sha256-1tBb01g1fITaBL5pb9lMk0SxQ5XszFrf0mDZchmeBS4=",
      "url": "bootstrap-icons/icons/building-fill.svg"
    },
    {
      "hash": "sha256-M4p8EhF0hGLrCnmzhI/b5K/i0WvTt78mUs6plq0ZNTE=",
      "url": "bootstrap-icons/icons/building-gear.svg"
    },
    {
      "hash": "sha256-HIJSbs8IEjVTgtXrA2CYIQZoroalUR+T8dKu2Uubqvo=",
      "url": "bootstrap-icons/icons/building-lock.svg"
    },
    {
      "hash": "sha256-/bd3TJ77bMcxP+eVosR9ZW9f7yP35aHyYyhIKR+vM7k=",
      "url": "bootstrap-icons/icons/building-slash.svg"
    },
    {
      "hash": "sha256-lAbQjBPZU2Fl6eDnwXMDGA5mFCEwzZgjO+iNQceFSE4=",
      "url": "bootstrap-icons/icons/building-up.svg"
    },
    {
      "hash": "sha256-SswY1876fHeHdMYT6uH+e86SLPHN02H4OojaHEd3u64=",
      "url": "bootstrap-icons/icons/building-x.svg"
    },
    {
      "hash": "sha256-BjFeaPLyZnhVop/tvgw6I45GTCr2DtMwwgsj76Rnutc=",
      "url": "bootstrap-icons/icons/building.svg"
    },
    {
      "hash": "sha256-FzQKe7Tu5VHzZ0EqJCeWWOVyY6weq4H7ils417ersH4=",
      "url": "bootstrap-icons/icons/buildings-fill.svg"
    },
    {
      "hash": "sha256-bn9Qab5IcRAD4VBjZ82OAZwJ8pg84vhq/e6qN2azLNU=",
      "url": "bootstrap-icons/icons/buildings.svg"
    },
    {
      "hash": "sha256-ilGbDI9V0hCAjnUgx++QcYvc304/n7XW0ZP7/2OkwK0=",
      "url": "bootstrap-icons/icons/bullseye.svg"
    },
    {
      "hash": "sha256-79iK1Mji1E7n6QoebhUWs0Z4awTH8osjj4H1jaHnLUE=",
      "url": "bootstrap-icons/icons/bus-front-fill.svg"
    },
    {
      "hash": "sha256-IZYH2ut01zltMUjWQifiBMrubuydxgdzCW62LB9nMDY=",
      "url": "bootstrap-icons/icons/bus-front.svg"
    },
    {
      "hash": "sha256-tBGBVYzVRwA8h7vnaw6GOFb7Ab4S5ns36vDwRCuP8Fo=",
      "url": "bootstrap-icons/icons/c-circle-fill.svg"
    },
    {
      "hash": "sha256-22kKKoFgK/kFn781QfW971yiR5KoMZ2BBwe1HnJQ7EY=",
      "url": "bootstrap-icons/icons/c-circle.svg"
    },
    {
      "hash": "sha256-gOw5k7hbYVDeyrpRPJ5Ev/f4v0iGxzjXdVR1Jrk0XqE=",
      "url": "bootstrap-icons/icons/c-square-fill.svg"
    },
    {
      "hash": "sha256-4b2WkRsdCi1/y5L/YjRlb7ptRpre/s0EZjvJ0c44Lpw=",
      "url": "bootstrap-icons/icons/c-square.svg"
    },
    {
      "hash": "sha256-qPGC7uBym4z8xUckaPaE6tSQseEtRTgm9mu8czWOg7g=",
      "url": "bootstrap-icons/icons/cake-fill.svg"
    },
    {
      "hash": "sha256-RIwclS9oDP0SnToCiztK/ulpnPaoPpS8gHKXdz2q0Ls=",
      "url": "bootstrap-icons/icons/cake.svg"
    },
    {
      "hash": "sha256-sFv8tVpIpWfQFq3VPqQ6aMkC0snn1C6P29/vINDR+4Y=",
      "url": "bootstrap-icons/icons/cake2-fill.svg"
    },
    {
      "hash": "sha256-F3hcJbuUSWYokmvDk03o6giO1SsUvQRDYp/rJyuu/po=",
      "url": "bootstrap-icons/icons/cake2.svg"
    },
    {
      "hash": "sha256-3Ni4XqtujV6HQqTLzpyhWIMYCI9cJnJsgyUJSK7hCQw=",
      "url": "bootstrap-icons/icons/calculator-fill.svg"
    },
    {
      "hash": "sha256-D086H3TqLHopsb1HuiWJKlRrdDzoYKfuDe7fhP0+mCE=",
      "url": "bootstrap-icons/icons/calculator.svg"
    },
    {
      "hash": "sha256-KZQPwrtJcmdS3nJJQdeMO8QS+NTwxXS0H7w03ESBh5U=",
      "url": "bootstrap-icons/icons/calendar-check-fill.svg"
    },
    {
      "hash": "sha256-n4+TdixMkX4hFGF3yU+Ww4MoQjzXjpuMvM6e5nB5+8s=",
      "url": "bootstrap-icons/icons/calendar-check.svg"
    },
    {
      "hash": "sha256-mHRzZ+ImG5vWjlDzvQPV8fauVt0B2g0Slew42/WMSiA=",
      "url": "bootstrap-icons/icons/calendar-date-fill.svg"
    },
    {
      "hash": "sha256-K8jig1vUO5e4GYGlaHAIB2n2vbEXvZgytUsWnctDTFw=",
      "url": "bootstrap-icons/icons/calendar-date.svg"
    },
    {
      "hash": "sha256-o8vQSxI5JeFvKId4glcBNLZkwCN9sDZpsZPmDzd0N7o=",
      "url": "bootstrap-icons/icons/calendar-day-fill.svg"
    },
    {
      "hash": "sha256-q7R+gn3s0kFY8v0d8U1t8c2gOCArUq3Asvq3Vv8ee0o=",
      "url": "bootstrap-icons/icons/calendar-day.svg"
    },
    {
      "hash": "sha256-MZ6PYyC6CTUCYwbFheGNEH1HRZYAcUFudn+maV4fZHo=",
      "url": "bootstrap-icons/icons/calendar-event-fill.svg"
    },
    {
      "hash": "sha256-QcypZWq21cOyAM8LYseHBQsRLLkBg0oeZkeXyLpAd3Y=",
      "url": "bootstrap-icons/icons/calendar-event.svg"
    },
    {
      "hash": "sha256-8GI+6IX173DARO5+feqPYDvJ27MzhcZblTRSMb1K/us=",
      "url": "bootstrap-icons/icons/calendar-fill.svg"
    },
    {
      "hash": "sha256-iPpwDVp5EwJsbiaJDlFvcA47xuRrtTKYGUN42TojdCE=",
      "url": "bootstrap-icons/icons/calendar-heart-fill.svg"
    },
    {
      "hash": "sha256-DqvmTWkKmQgdff+Zn09DH0zbKcgsJclGHY6VJyAD1Z0=",
      "url": "bootstrap-icons/icons/calendar-heart.svg"
    },
    {
      "hash": "sha256-iyYr0+D1l53cVPg3nGgpLEqFzTysITFEQAie/rATYxY=",
      "url": "bootstrap-icons/icons/calendar-minus-fill.svg"
    },
    {
      "hash": "sha256-/J/p2Jk2FvojZiwhv17okPwLcmf2/CATjVh+5h7epxw=",
      "url": "bootstrap-icons/icons/calendar-minus.svg"
    },
    {
      "hash": "sha256-BnUm25tjrT8PSn8QmJJ2iC4jYoANZ1lTD+bj/7o5tQY=",
      "url": "bootstrap-icons/icons/calendar-month-fill.svg"
    },
    {
      "hash": "sha256-ydsZ9BeRRmhsxbUiWwgADPHq8jTni4yNMX8JZGOFiuA=",
      "url": "bootstrap-icons/icons/calendar-month.svg"
    },
    {
      "hash": "sha256-9ZNwGDkGUoznVqgFnlVaV3u0R/kyMajyysZCCX7chYs=",
      "url": "bootstrap-icons/icons/calendar-plus-fill.svg"
    },
    {
      "hash": "sha256-b9Y6IIoytTtLqeKoVUSaD1An3JqXQlFqKPUtaZ2VvuU=",
      "url": "bootstrap-icons/icons/calendar-plus.svg"
    },
    {
      "hash": "sha256-adtILZU9HCCOvis1B0RtfwtuX8jLlpJm67/m2jcUky0=",
      "url": "bootstrap-icons/icons/calendar-range-fill.svg"
    },
    {
      "hash": "sha256-et3DeEZVk7hu+SrZKxVXvBfbzXYEeP9Bk2Oyp1n79Mk=",
      "url": "bootstrap-icons/icons/calendar-range.svg"
    },
    {
      "hash": "sha256-6BJ8mlx37qim2XFVvxhpkSeMN3ENEZqDyNdHCrusm5o=",
      "url": "bootstrap-icons/icons/calendar-week-fill.svg"
    },
    {
      "hash": "sha256-VWvzMnLvRNW2A7X62+qwLYZcALqdmh8zSTEp9V/8VR4=",
      "url": "bootstrap-icons/icons/calendar-week.svg"
    },
    {
      "hash": "sha256-ZZ4DZiih6SUEe4wqGpFTJIFFEo6H0HviSo1bHlybGfQ=",
      "url": "bootstrap-icons/icons/calendar-x-fill.svg"
    },
    {
      "hash": "sha256-K5Vb7WS4+E3ZXSp3w4rz1loPg5fgh9ENHfd4p/k1G74=",
      "url": "bootstrap-icons/icons/calendar-x.svg"
    },
    {
      "hash": "sha256-h30/900dyLvp1y8Jk8DMGfsLmttTNKTIzq61Xw8vSPU=",
      "url": "bootstrap-icons/icons/calendar.svg"
    },
    {
      "hash": "sha256-5/Oq5ygM2p3MxHUIKVXdTzu6He8ep+HZ+oq52D/zTMs=",
      "url": "bootstrap-icons/icons/calendar2-check-fill.svg"
    },
    {
      "hash": "sha256-lOOxfZmmIwVZHmNlcaANi1V3JvmQcG0kkSmv6ZgUt54=",
      "url": "bootstrap-icons/icons/calendar2-check.svg"
    },
    {
      "hash": "sha256-I6j9jhcEs+AJWsfqnHDM3l+Or0/578xf4e5C7d1DZEM=",
      "url": "bootstrap-icons/icons/calendar2-date-fill.svg"
    },
    {
      "hash": "sha256-+XEJKgxW7VR3EPck8NemeTsiS5iPCEL6wB2WHqclKL4=",
      "url": "bootstrap-icons/icons/calendar2-date.svg"
    },
    {
      "hash": "sha256-X0wF9jfzemh1RNfjWKUzdLSzjUkC05oGywzsBjJsZck=",
      "url": "bootstrap-icons/icons/calendar2-day-fill.svg"
    },
    {
      "hash": "sha256-+nYRMqVJyvHxIauqcP4h8dMerqdNIueiAc67H4m0rNg=",
      "url": "bootstrap-icons/icons/calendar2-day.svg"
    },
    {
      "hash": "sha256-NFBxog8D5t1BEUt+gvcDhIVpj6PoUFVnBM26IIPfTgo=",
      "url": "bootstrap-icons/icons/calendar2-event-fill.svg"
    },
    {
      "hash": "sha256-vYd+wJSJLVaRc0zNIeLISIoiunQxuWEAB0+TB3bFYbM=",
      "url": "bootstrap-icons/icons/calendar2-event.svg"
    },
    {
      "hash": "sha256-WzHTXdgQgIZCPqHxz75FQ584VrEBDz6OMPm6WvWIIM0=",
      "url": "bootstrap-icons/icons/calendar2-fill.svg"
    },
    {
      "hash": "sha256-/5hp+VkAMXeoN6kbJ7DS5mN2K+5j9Pb0WMgFgDYQy40=",
      "url": "bootstrap-icons/icons/calendar2-heart-fill.svg"
    },
    {
      "hash": "sha256-U8yJkTbrHV6IGX029DqPHnizdEXvXn80STxIVfSz7qY=",
      "url": "bootstrap-icons/icons/calendar2-heart.svg"
    },
    {
      "hash": "sha256-LBskQD357NFf8AdJ+GqB+0nt5vEKv6zHai5oSt+OORE=",
      "url": "bootstrap-icons/icons/calendar2-minus-fill.svg"
    },
    {
      "hash": "sha256-BMi98WDFvsI/HC01T0T9/vy0bMS7DZgoPWnWq56HDdU=",
      "url": "bootstrap-icons/icons/calendar2-minus.svg"
    },
    {
      "hash": "sha256-tyQrHo6jW4gURUUEkX6UUGFwwOZXP6BvPtw8WS4JDEc=",
      "url": "bootstrap-icons/icons/calendar2-month-fill.svg"
    },
    {
      "hash": "sha256-vtGM67WNQORitqPzOJngGfsjSO6BaLBVj1QEBnCEjCM=",
      "url": "bootstrap-icons/icons/calendar2-month.svg"
    },
    {
      "hash": "sha256-dUQ16tri5FGlaEh0GOj0uTRy56yJnv8IPoHCfcKA3fo=",
      "url": "bootstrap-icons/icons/calendar2-plus-fill.svg"
    },
    {
      "hash": "sha256-E8WfaRsE9muT/3/3rLPfBSZ/miBdQnDh5EGH5LkcFc8=",
      "url": "bootstrap-icons/icons/calendar2-plus.svg"
    },
    {
      "hash": "sha256-OTWQlxIxfGQfzBeNjtqfhSM8DIBUPAfwgwRdhimmD20=",
      "url": "bootstrap-icons/icons/calendar2-range-fill.svg"
    },
    {
      "hash": "sha256-4qT4g7XrJ5wkUyLZL+HeMBQfMUrDjMyO/9wl9nUWTrM=",
      "url": "bootstrap-icons/icons/calendar2-range.svg"
    },
    {
      "hash": "sha256-tFkzSIq5bpRUi3g8zXq0g1WPbhgthAyYulHItv+l4n0=",
      "url": "bootstrap-icons/icons/calendar2-week-fill.svg"
    },
    {
      "hash": "sha256-r7ig9MsMvu45mpvS8UxWAOQYArV2zoPSZAPrccCgCt0=",
      "url": "bootstrap-icons/icons/calendar2-week.svg"
    },
    {
      "hash": "sha256-+QHKGS1HVUMPtPcZ/sT5oosplRZ5aeAfBdz2baToKeQ=",
      "url": "bootstrap-icons/icons/calendar2-x-fill.svg"
    },
    {
      "hash": "sha256-QDYYZ9Qhn2s5lrOS2TJuiE43JxMkrrJO09wER3ViV84=",
      "url": "bootstrap-icons/icons/calendar2-x.svg"
    },
    {
      "hash": "sha256-dW9icftmJWL7i6X1WhB9YVcsmZC/9Cd1RDlCgv5Ley8=",
      "url": "bootstrap-icons/icons/calendar2.svg"
    },
    {
      "hash": "sha256-GFOLM4kW5V0b0XsvZJQcCiQ3eacN5tbvmmHeyp0iv1s=",
      "url": "bootstrap-icons/icons/calendar3-event-fill.svg"
    },
    {
      "hash": "sha256-famzy+K6mpTO3vuZ405KjpNJmjVI6gvcKrXIgcC1zDE=",
      "url": "bootstrap-icons/icons/calendar3-event.svg"
    },
    {
      "hash": "sha256-qvpMktBL+glzsjHI1m895UbJi6dL9uxGRypSS+O3Z/I=",
      "url": "bootstrap-icons/icons/calendar3-fill.svg"
    },
    {
      "hash": "sha256-7rhGNBpIIHVECflyaw+OpUwzWM6SrShaqG6iVqMkCyw=",
      "url": "bootstrap-icons/icons/calendar3-range-fill.svg"
    },
    {
      "hash": "sha256-UiHTOcCwihzzC3ARmUVyn/1h1OcGW3CpF2fijU6mQjk=",
      "url": "bootstrap-icons/icons/calendar3-range.svg"
    },
    {
      "hash": "sha256-kh4Ybpoh06fr7ASHAzr2yrOpaJd+zgNRF1BFBIYIoIU=",
      "url": "bootstrap-icons/icons/calendar3-week-fill.svg"
    },
    {
      "hash": "sha256-Vul5iOC9f9TwWJrnihxBs8K/iLdPIAgwVAouVcnumo0=",
      "url": "bootstrap-icons/icons/calendar3-week.svg"
    },
    {
      "hash": "sha256-LHXlJev2qwiLMF6K2DKAjGlJ+UvIA5tBQYYR1cRt6pY=",
      "url": "bootstrap-icons/icons/calendar3.svg"
    },
    {
      "hash": "sha256-hfHGzbfv1RB9rPSxtvstB18D1aMVyZCmetlF/SPcREk=",
      "url": "bootstrap-icons/icons/calendar4-event.svg"
    },
    {
      "hash": "sha256-Z7MYsoBEwRfJrSDaq5ixRaonnZi3d1+x0a43JVpLk9w=",
      "url": "bootstrap-icons/icons/calendar4-range.svg"
    },
    {
      "hash": "sha256-YTnK+wl4cFx0uZbRKtDbw5Zjp4eSoGhteDxHQAD5dhk=",
      "url": "bootstrap-icons/icons/calendar4-week.svg"
    },
    {
      "hash": "sha256-+6SfY7nQQK/2yg7BJCi99ouc85n76OCb0xc++nXKWjk=",
      "url": "bootstrap-icons/icons/calendar4.svg"
    },
    {
      "hash": "sha256-/CfxK71dXjmAANcDSLKiU7xNR87gfagLHJ0ZjJAvHqQ=",
      "url": "bootstrap-icons/icons/camera-fill.svg"
    },
    {
      "hash": "sha256-PU1jdV8Wen/u2r5qQ6xrEJQaN0/Qc8r6sSBWtcJ9g+g=",
      "url": "bootstrap-icons/icons/camera-reels-fill.svg"
    },
    {
      "hash": "sha256-0r+RqbcDGNCHWmMvK9dEBq1uU+LU3olFMQmT6FPJiWE=",
      "url": "bootstrap-icons/icons/camera-reels.svg"
    },
    {
      "hash": "sha256-WwdG6GLkh81bRnpHosepy/pNHK39nJ12JW3nsZvqVlM=",
      "url": "bootstrap-icons/icons/camera-video-fill.svg"
    },
    {
      "hash": "sha256-aRY8JbjvNMC3bLb5jbDBM+YiIpCiayv4Rb+ltn6dXgc=",
      "url": "bootstrap-icons/icons/camera-video-off-fill.svg"
    },
    {
      "hash": "sha256-Qll0pPL2uY+hcBGGBV3FzjIs/87pL+Pc+un7rUz/w9w=",
      "url": "bootstrap-icons/icons/camera-video-off.svg"
    },
    {
      "hash": "sha256-h7WUCRoAKGefTa3kabyMqsLXYx9x1YT9Oy5pbX3wUIM=",
      "url": "bootstrap-icons/icons/camera-video.svg"
    },
    {
      "hash": "sha256-jx5T6QB3LGEfh9zyHEF9lKYnZAySlYE3VC49r14enyA=",
      "url": "bootstrap-icons/icons/camera.svg"
    },
    {
      "hash": "sha256-udma3TY37Ao/Xt+hACHLSt4XGRHZfUvn0/aTkKpF4JQ=",
      "url": "bootstrap-icons/icons/camera2.svg"
    },
    {
      "hash": "sha256-LIs9Te2ctqA3qGsaeG4ZC+McapdugSfBPG7PmALXPKs=",
      "url": "bootstrap-icons/icons/capslock-fill.svg"
    },
    {
      "hash": "sha256-ZOELIkaD0Q3oFuwMXgZimrpx3PK2NQ62e+pJSXzJk3w=",
      "url": "bootstrap-icons/icons/capslock.svg"
    },
    {
      "hash": "sha256-3QR2zbHD9EW+muOyBUcNJFGK7vcTZYL9JAZBvBhleZ0=",
      "url": "bootstrap-icons/icons/capsule-pill.svg"
    },
    {
      "hash": "sha256-lJ2yLmEaWACxXNuHsF8D0DAc/qDKsawEtw6TA7j4Ztw=",
      "url": "bootstrap-icons/icons/capsule.svg"
    },
    {
      "hash": "sha256-w2tpp5zmIhSmLmMIVJmK1zt9x6wimX2NACX7xeBJeTk=",
      "url": "bootstrap-icons/icons/car-front-fill.svg"
    },
    {
      "hash": "sha256-+hmUma3GNlOvoxukqdYd3//KpaxPSsn5t7+j7sigbXc=",
      "url": "bootstrap-icons/icons/car-front.svg"
    },
    {
      "hash": "sha256-eb8KRcNXlS7GfvbMYUgZb8jY5jVIwQVABMwZlxlFNHA=",
      "url": "bootstrap-icons/icons/card-checklist.svg"
    },
    {
      "hash": "sha256-3zccqYpAvL8N7waix7G8Hw3meOxNbzwD9e2ppMulRco=",
      "url": "bootstrap-icons/icons/card-heading.svg"
    },
    {
      "hash": "sha256-sL6tTwmuQugkiOQsg6RNk+lJRKseLFnXV55d3AyaJas=",
      "url": "bootstrap-icons/icons/card-image.svg"
    },
    {
      "hash": "sha256-5Q0irr5zX/D/seHsWbUVmsp19W6srNHgwDaiR/x5Kk0=",
      "url": "bootstrap-icons/icons/card-list.svg"
    },
    {
      "hash": "sha256-fBYtDxiR+Oj0iMs9wIbdJ70ULshavHdbYZxcXJ19KP0=",
      "url": "bootstrap-icons/icons/card-text.svg"
    },
    {
      "hash": "sha256-v8iTU0eX2SMEAe/AXtT3nHu4C53CD1uigkIA7F2x43Y=",
      "url": "bootstrap-icons/icons/caret-down-fill.svg"
    },
    {
      "hash": "sha256-Y7zoxJX+GDr2Ua8kC/s4Ys/bgdufPpWhCYBxAIjGa6Y=",
      "url": "bootstrap-icons/icons/caret-down-square-fill.svg"
    },
    {
      "hash": "sha256-81lROPUoUwcWAOtqXzXwE7MOgP+V9eLKuu80IPgH0co=",
      "url": "bootstrap-icons/icons/caret-down-square.svg"
    },
    {
      "hash": "sha256-L6C1r1aDdDjrh5v82wwfk1fbm3Sw78yEM0fq48ejcAY=",
      "url": "bootstrap-icons/icons/caret-down.svg"
    },
    {
      "hash": "sha256-g6tiY9Fa0GUFtTtWzPTn5gDPNn4K7KzvV6n6BS2NS5U=",
      "url": "bootstrap-icons/icons/caret-left-fill.svg"
    },
    {
      "hash": "sha256-Gm+AkhstPhFf3Qtz5HVL5D6I4sXGpzIy2sEs5LU0Glo=",
      "url": "bootstrap-icons/icons/caret-left-square-fill.svg"
    },
    {
      "hash": "sha256-XfVQU8W3ijzESOriJVDEzqMBii1nFgn5tnAf/S9VSIo=",
      "url": "bootstrap-icons/icons/caret-left-square.svg"
    },
    {
      "hash": "sha256-puIyrxqr6c3a9eH/qDLPxRUeVTUohY+MFwNk4xAZFgQ=",
      "url": "bootstrap-icons/icons/caret-left.svg"
    },
    {
      "hash": "sha256-Ue1QavYKOwm+x/dZWyF8lt33ZeKwsAi1cpue3IAqd6c=",
      "url": "bootstrap-icons/icons/caret-right-fill.svg"
    },
    {
      "hash": "sha256-O4/GykX3kyspYAQbH0DwoQ9MvfWgF9SUkU41ZOwYN5o=",
      "url": "bootstrap-icons/icons/caret-right-square-fill.svg"
    },
    {
      "hash": "sha256-guI824kM4nHsyKmd6jhHiJjDcyEe0vidr6e73gKlNbk=",
      "url": "bootstrap-icons/icons/caret-right-square.svg"
    },
    {
      "hash": "sha256-UZC8BMDG8PyNJgM8JFLzrFRRnsGhvBZP98FPo/n8sco=",
      "url": "bootstrap-icons/icons/caret-right.svg"
    },
    {
      "hash": "sha256-GFruMz5YWQpL41SR9v5vzpt6XkCQ/xphqte6Y61/wiA=",
      "url": "bootstrap-icons/icons/caret-up-fill.svg"
    },
    {
      "hash": "sha256-rdeUSBf6J5EM8mxd2IRsy1JI9/6+lkmLp7oWIZdEVVA=",
      "url": "bootstrap-icons/icons/caret-up-square-fill.svg"
    },
    {
      "hash": "sha256-xaV6zwYZCmIdzP86HkCUcReNgWBNwItWNtDMJayIi0k=",
      "url": "bootstrap-icons/icons/caret-up-square.svg"
    },
    {
      "hash": "sha256-SHhmj36lgYS6SPC4VLtVVZJhF4J2KCtnUZwfQ6qbzos=",
      "url": "bootstrap-icons/icons/caret-up.svg"
    },
    {
      "hash": "sha256-Nhh0XnhAMPrxZJNKRDAV4gFo5AZ7bbXlHu3z3h3Xgc8=",
      "url": "bootstrap-icons/icons/cart-check-fill.svg"
    },
    {
      "hash": "sha256-5v9lCZwWC1XJM1pTnZF4l1BTdqC2fVxvrv4W9Rv7NB0=",
      "url": "bootstrap-icons/icons/cart-check.svg"
    },
    {
      "hash": "sha256-BIXilb90Gu+qH4SvNcKdQkM8eJ/rFFOiW/5U5YOExzI=",
      "url": "bootstrap-icons/icons/cart-dash-fill.svg"
    },
    {
      "hash": "sha256-ltghM75A91Gn31jm5J4PfyiyVOImwWWyuR6JWIVLomU=",
      "url": "bootstrap-icons/icons/cart-dash.svg"
    },
    {
      "hash": "sha256-WLe9k6D9FntBt+U41xhW/XUzegAUcms7/o/Pvhy4Rp4=",
      "url": "bootstrap-icons/icons/cart-fill.svg"
    },
    {
      "hash": "sha256-iQoLCi7jnLyJCfaNU/+Gb02sc9TZGKiXCYeOrc1vp34=",
      "url": "bootstrap-icons/icons/cart-plus-fill.svg"
    },
    {
      "hash": "sha256-Z/QyPtZ9lNnf/PJIh8AoGz0bOo1kvO+EBLpDYf+rTcY=",
      "url": "bootstrap-icons/icons/cart-plus.svg"
    },
    {
      "hash": "sha256-ahJIkZ++XnQlxvUaniva3H+xijVWOOCocKwl9VPhJ4s=",
      "url": "bootstrap-icons/icons/cart-x-fill.svg"
    },
    {
      "hash": "sha256-U9eor0SJ01vBKwEsWWxK4MGA++jUC3lagbqsHMjisJc=",
      "url": "bootstrap-icons/icons/cart-x.svg"
    },
    {
      "hash": "sha256-v5tHDcMf5ui0IBXG2MGlIITEoV2IdwVDbdgr/bgqi9U=",
      "url": "bootstrap-icons/icons/cart.svg"
    },
    {
      "hash": "sha256-ejwYxPcZEXVx7W+NZ3XRjygUl5y1uHgTXg6skReFR8s=",
      "url": "bootstrap-icons/icons/cart2.svg"
    },
    {
      "hash": "sha256-Htzqflx1lYQ5iHszV78lcERXdc/AleWfwA0vEUsYaG0=",
      "url": "bootstrap-icons/icons/cart3.svg"
    },
    {
      "hash": "sha256-4Jy+PnfqyvfLFRZcnMOBi1a9HY0+BG2b/ReDFi7Cm5w=",
      "url": "bootstrap-icons/icons/cart4.svg"
    },
    {
      "hash": "sha256-euEN6p4PVdL23IfVWRZ1uiiml+LyMvUnZI5+y1Lg6Uw=",
      "url": "bootstrap-icons/icons/cash-coin.svg"
    },
    {
      "hash": "sha256-6pBmPbvNrfrfYKGTh0lnaaNoRTvN2Y733iYCR3biW1o=",
      "url": "bootstrap-icons/icons/cash-stack.svg"
    },
    {
      "hash": "sha256-W4fNtaX/F22xbynb+Qchj7sdfNN9udmoJkuIQ9TdAKQ=",
      "url": "bootstrap-icons/icons/cash.svg"
    },
    {
      "hash": "sha256-9Mc3eHTaVJA5UoGQ+bYq9K32s9KKEW7+yQuW2PiOYrA=",
      "url": "bootstrap-icons/icons/cassette-fill.svg"
    },
    {
      "hash": "sha256-sC8Dx7b2vIeJga8WsfUG+U0WqXexT4/3xWoSpB9nkJo=",
      "url": "bootstrap-icons/icons/cassette.svg"
    },
    {
      "hash": "sha256-C2X1608a6n1DAibVulzVvzK72xtL+H6K0Lvsdq2j4Y8=",
      "url": "bootstrap-icons/icons/cast.svg"
    },
    {
      "hash": "sha256-LhunNiTTyEk9A5dawE9J/JU9UCJQmPVcrkrBDkiqVXU=",
      "url": "bootstrap-icons/icons/cc-circle-fill.svg"
    },
    {
      "hash": "sha256-PaH3esq9iSquvlza79PTJ/kJ5plEH7KdJu1cwqe64bs=",
      "url": "bootstrap-icons/icons/cc-circle.svg"
    },
    {
      "hash": "sha256-B0r/LB2zsyCDFfnv+12p3n6tyt8zFm3tesD41P+IOU4=",
      "url": "bootstrap-icons/icons/cc-square-fill.svg"
    },
    {
      "hash": "sha256-ZtJ3uXv+DXyr4ZDw8njSLpR7jUtugIUzidkcXLqJDBY=",
      "url": "bootstrap-icons/icons/cc-square.svg"
    },
    {
      "hash": "sha256-nNrQEF1lUSScWuJBi41Zj8zPbJGMpcj0H65tL202F5M=",
      "url": "bootstrap-icons/icons/chat-dots-fill.svg"
    },
    {
      "hash": "sha256-wFhOokPwNBrzvH7+mkyWWtxV4PKU6k0zHgB1P52zSnY=",
      "url": "bootstrap-icons/icons/chat-dots.svg"
    },
    {
      "hash": "sha256-7ABucy2aciAInvqOH6m6c6sokjW6s9DkpJBePI6Jf88=",
      "url": "bootstrap-icons/icons/chat-fill.svg"
    },
    {
      "hash": "sha256-5uShIsosagW8fRdanBASH5xQuHTzNLuKONg9E9+BqdE=",
      "url": "bootstrap-icons/icons/chat-heart-fill.svg"
    },
    {
      "hash": "sha256-4r+CO/nseGpkcUphxk+jFJLe0Tp7/V9FNEhyMC7ftSc=",
      "url": "bootstrap-icons/icons/chat-heart.svg"
    },
    {
      "hash": "sha256-tKQb6Bg4+5jWphhEb0+hcyOjCTgeni2rorIbfFIUFoc=",
      "url": "bootstrap-icons/icons/chat-left-dots-fill.svg"
    },
    {
      "hash": "sha256-FCIt+kTbs9uAHggEvLmbYBON10mzkH1QZ4iz+OBphrk=",
      "url": "bootstrap-icons/icons/chat-left-dots.svg"
    },
    {
      "hash": "sha256-uX0EqLLAvE/snhhs84n+dN8qaHidJgpmpf9d3ozDAl4=",
      "url": "bootstrap-icons/icons/chat-left-fill.svg"
    },
    {
      "hash": "sha256-iMCN/NVY/0LzTKznr+TraIUREyh26Q9n/iVHNVN0WgM=",
      "url": "bootstrap-icons/icons/chat-left-heart-fill.svg"
    },
    {
      "hash": "sha256-gZ9+PxlWQX2S4fkcydljBKJTb38gSovJYoqc3HRkPmY=",
      "url": "bootstrap-icons/icons/chat-left-heart.svg"
    },
    {
      "hash": "sha256-QC87AdBBlAJgyv6iVVhT0blFKpmBbr0azXberFjvwcw=",
      "url": "bootstrap-icons/icons/chat-left-quote-fill.svg"
    },
    {
      "hash": "sha256-CPlYSfJBfL/mZ6AwEE0VJTCN4s/GSqc5pxlPdsyyFoM=",
      "url": "bootstrap-icons/icons/chat-left-quote.svg"
    },
    {
      "hash": "sha256-b1LMTGi4B/YxbfB77ag8QyuF2tGc0lvYJsOIqFIvRao=",
      "url": "bootstrap-icons/icons/chat-left-text-fill.svg"
    },
    {
      "hash": "sha256-ISbwwYTt/IsjR8oyAyYnLm2j1E+6Sh9kINIGGdn732Y=",
      "url": "bootstrap-icons/icons/chat-left-text.svg"
    },
    {
      "hash": "sha256-AccyG8MuzoBMTvF/5KC+JsUyJmd7dq+kSFi7su4OoyM=",
      "url": "bootstrap-icons/icons/chat-left.svg"
    },
    {
      "hash": "sha256-MuNkW8NgfIyP9us0xIhiON+7EcqCz/OTdDs5FZqimNk=",
      "url": "bootstrap-icons/icons/chat-quote-fill.svg"
    },
    {
      "hash": "sha256-qRq6B8DaFfb6mi/cre8Bv13Xwzy51Rut4RwcksmnsKc=",
      "url": "bootstrap-icons/icons/chat-quote.svg"
    },
    {
      "hash": "sha256-vgMEZAsTM/796TD3+0D5Jv0k0gna3iRmIOqcCHOxEjo=",
      "url": "bootstrap-icons/icons/chat-right-dots-fill.svg"
    },
    {
      "hash": "sha256-KpmoLOvoz3LB1lxkMzePUkHjGkA+QD2W99uIlP+dGN4=",
      "url": "bootstrap-icons/icons/chat-right-dots.svg"
    },
    {
      "hash": "sha256-f1N4/r+mCO0QE5LjkB4nCdl+5R7va3tiunFfmZgt5gA=",
      "url": "bootstrap-icons/icons/chat-right-fill.svg"
    },
    {
      "hash": "sha256-/N9vDSdZx36jJAd+cp/jjGqxfGrLLRXciSgu/G27ucU=",
      "url": "bootstrap-icons/icons/chat-right-heart-fill.svg"
    },
    {
      "hash": "sha256-KnL31qXanLVuoXliqRVOfCyddHucKGyKoRPFyFmNm/k=",
      "url": "bootstrap-icons/icons/chat-right-heart.svg"
    },
    {
      "hash": "sha256-uvbuGQ++cjxycqrvboHdB01dNOjJOt6gdtyvGIWc+30=",
      "url": "bootstrap-icons/icons/chat-right-quote-fill.svg"
    },
    {
      "hash": "sha256-+hvGviCJk/8yJbskMnQBazQyCU8Ukc1kzTPD7QC7cYQ=",
      "url": "bootstrap-icons/icons/chat-right-quote.svg"
    },
    {
      "hash": "sha256-TZHy/pOoh5jhqioC9GdsDcp75kTwi8yLVrjfGPglaw0=",
      "url": "bootstrap-icons/icons/chat-right-text-fill.svg"
    },
    {
      "hash": "sha256-kCnrluI/GjBPlOtfcsQJoTf3Dr4e3vs0Ud3xOywuOjU=",
      "url": "bootstrap-icons/icons/chat-right-text.svg"
    },
    {
      "hash": "sha256-DLG0Ij+bbCdILfcWe2xOyyf/vFVxJQJX36dwiKAX2Ow=",
      "url": "bootstrap-icons/icons/chat-right.svg"
    },
    {
      "hash": "sha256-Af4EOl36RGWTK+y4jQk6Jfl8l0axY4fzgs8yeYBHthA=",
      "url": "bootstrap-icons/icons/chat-square-dots-fill.svg"
    },
    {
      "hash": "sha256-+KqQkIBbO4Xe37N2+mz4W3XKhUP965bFsJPSiJVC3ps=",
      "url": "bootstrap-icons/icons/chat-square-dots.svg"
    },
    {
      "hash": "sha256-QclsWbJXDGDXc1VUO0d2Sbb0VuXCTo/0ffIGsG/sHk0=",
      "url": "bootstrap-icons/icons/chat-square-fill.svg"
    },
    {
      "hash": "sha256-ChjgnLM9BS13Vx3xx1Qrf9Bs1ZyqDHhfkcvgwjPtqIM=",
      "url": "bootstrap-icons/icons/chat-square-heart-fill.svg"
    },
    {
      "hash": "sha256-H8sYqHZmRBPH2BZQz9fMqxBQkdWgAZyLAjajYGCDXoY=",
      "url": "bootstrap-icons/icons/chat-square-heart.svg"
    },
    {
      "hash": "sha256-l9EAqK7n7GO8zaI1j3FaCMpW17LXE8IsJGozK84gP9o=",
      "url": "bootstrap-icons/icons/chat-square-quote-fill.svg"
    },
    {
      "hash": "sha256-dlM5PeHo1F2PvfMZQUoM/3CNdd7EZhUrM5OSQD+EYO4=",
      "url": "bootstrap-icons/icons/chat-square-quote.svg"
    },
    {
      "hash": "sha256-nneMcxbRnnkWBAFKIqWzUrkbIfqoPyH6cO0YWY2C+iI=",
      "url": "bootstrap-icons/icons/chat-square-text-fill.svg"
    },
    {
      "hash": "sha256-VGYUIfqlBFeripLtamW4UT3RkV/bXNOKL9kNWNqc2EA=",
      "url": "bootstrap-icons/icons/chat-square-text.svg"
    },
    {
      "hash": "sha256-DjkyfKjwbxKqx+eln46EZ7dyaV6c4PREID9a+rhi6RM=",
      "url": "bootstrap-icons/icons/chat-square.svg"
    },
    {
      "hash": "sha256-9foz9Oe6tc/M1fU7Pb98ElDQLhj8TlzxjYrvNvOJb6Y=",
      "url": "bootstrap-icons/icons/chat-text-fill.svg"
    },
    {
      "hash": "sha256-b6RfnniXLx2IfULwyEi3FiRF2d4/0sy6Ql/IpGbjTx4=",
      "url": "bootstrap-icons/icons/chat-text.svg"
    },
    {
      "hash": "sha256-4Vt/rwdwICUB79qE2HsfmB9ChtsFqh3psRJzoLfY/n0=",
      "url": "bootstrap-icons/icons/chat.svg"
    },
    {
      "hash": "sha256-bPbTskAWqsYlrDCeLpdBTc4UBKbKE+yhTI8Rg3O7hco=",
      "url": "bootstrap-icons/icons/check-all.svg"
    },
    {
      "hash": "sha256-9vXZcQkXhyGcQibFv2im69TZdskb2Q/FK6O0IlibLcg=",
      "url": "bootstrap-icons/icons/check-circle-fill.svg"
    },
    {
      "hash": "sha256-3a0ssRO448Id7qOuh253kJgrJG3zRfjwNFEhjh6jpxE=",
      "url": "bootstrap-icons/icons/check-circle.svg"
    },
    {
      "hash": "sha256-faen1Fv9l+kGmxcTKD4MsEnM2/Ov+g3uCKvI381rXHI=",
      "url": "bootstrap-icons/icons/check-lg.svg"
    },
    {
      "hash": "sha256-n+ghqsqelnnD5zuTecLUdENaHNwVzye0iJJt00C1Qqc=",
      "url": "bootstrap-icons/icons/check-square-fill.svg"
    },
    {
      "hash": "sha256-xyJJ7YcgAvp0FcGm6oAtwAPyQTY5TkMfmJt15xlrTTk=",
      "url": "bootstrap-icons/icons/check-square.svg"
    },
    {
      "hash": "sha256-Lj4ncuKVobUKMvqls/llLbTDZxCE9ABfSVNki29jlFc=",
      "url": "bootstrap-icons/icons/check.svg"
    },
    {
      "hash": "sha256-xhyxOCRz59yFIx8v7drjHN+LryxL5QPGkCdMGmJ1WOo=",
      "url": "bootstrap-icons/icons/check2-all.svg"
    },
    {
      "hash": "sha256-oKKwv21V1gl7xElKxccfloB//flfAqPLfkDJJQXurZw=",
      "url": "bootstrap-icons/icons/check2-circle.svg"
    },
    {
      "hash": "sha256-qXqYTVOvwq8Rl9/d7XQg589bb4lDaFe2McV+bJr4bnM=",
      "url": "bootstrap-icons/icons/check2-square.svg"
    },
    {
      "hash": "sha256-S8rgD9dJsv0+2v9kX2ZQOcrLcHUVCbLicigaXhHmNdQ=",
      "url": "bootstrap-icons/icons/check2.svg"
    },
    {
      "hash": "sha256-6VEzbgWCLUUt9VioOJuRmCd6QpgxmkXfDvSvd1SZIUs=",
      "url": "bootstrap-icons/icons/chevron-bar-contract.svg"
    },
    {
      "hash": "sha256-Ce7oV7e23pHyXSwLyTuf70inu3B/jU4xgIZB9hfNLdE=",
      "url": "bootstrap-icons/icons/chevron-bar-down.svg"
    },
    {
      "hash": "sha256-5f00O22kF3jwN5Owk5ErP7L3lw1u9+QJPyMEZ/h7xgY=",
      "url": "bootstrap-icons/icons/chevron-bar-expand.svg"
    },
    {
      "hash": "sha256-h3nuXkrIEatMjoaZVP8jf3BFTjXPWjU87XfHnKTiYiU=",
      "url": "bootstrap-icons/icons/chevron-bar-left.svg"
    },
    {
      "hash": "sha256-NS1t4FyL3Za1J6Z68YvXyUhDJlzog+7slM/FrQDx2t4=",
      "url": "bootstrap-icons/icons/chevron-bar-right.svg"
    },
    {
      "hash": "sha256-T2//qJzP52/uCZRJP7BL1PCG96/a4sahBRPy5PU97wc=",
      "url": "bootstrap-icons/icons/chevron-bar-up.svg"
    },
    {
      "hash": "sha256-guDAGvfcSz4jxe+wu/EFu7Rg5nmLqR1Jz288j3wYkQw=",
      "url": "bootstrap-icons/icons/chevron-compact-down.svg"
    },
    {
      "hash": "sha256-1gnM7P8CCGzNQjZSUoK7fbOAbP5L5hlAOYVnH5YSUbw=",
      "url": "bootstrap-icons/icons/chevron-compact-left.svg"
    },
    {
      "hash": "sha256-tlmPVb0sur4cnQ9TIO/LWv2XonhApvFqTpmgrHkEXdk=",
      "url": "bootstrap-icons/icons/chevron-compact-right.svg"
    },
    {
      "hash": "sha256-HWdRrwCq5UPHSoXlISGENwQEkdzUZ4/m8RHOpqqJgqo=",
      "url": "bootstrap-icons/icons/chevron-compact-up.svg"
    },
    {
      "hash": "sha256-AI09wHd3/DVBzpZSu5ijMQSM2Wbv4Qb3UWCd8oW2DgM=",
      "url": "bootstrap-icons/icons/chevron-contract.svg"
    },
    {
      "hash": "sha256-a6qLsKgsuGzJg7XQJ4ml79EUh0Z3U5auGZ9WYSkHYeA=",
      "url": "bootstrap-icons/icons/chevron-double-down.svg"
    },
    {
      "hash": "sha256-u65O7TcbEa4YgKZ6NEPh87/yBie8CxZAVgkv6+dAZ+U=",
      "url": "bootstrap-icons/icons/chevron-double-left.svg"
    },
    {
      "hash": "sha256-QDf6Zafw+7vayWPflQIasFx8MZYtOp9kan/e0SIKL4E=",
      "url": "bootstrap-icons/icons/chevron-double-right.svg"
    },
    {
      "hash": "sha256-wQ4wb3dJEJ2VkP/QhQegSPcHeLomouv7IfBnfRIf4S0=",
      "url": "bootstrap-icons/icons/chevron-double-up.svg"
    },
    {
      "hash": "sha256-bJivc9nNZND0rokMQFZqQ2ocyQSvk8KD5SERry1LpEw=",
      "url": "bootstrap-icons/icons/chevron-down.svg"
    },
    {
      "hash": "sha256-O7Qw4MocOMRL8XWXi33t+ZovztQT97kIhCoKEB40JfM=",
      "url": "bootstrap-icons/icons/chevron-expand.svg"
    },
    {
      "hash": "sha256-wy9vGavkCBYeN2UQn/Y8ej2I4iwNvMKK0ZF0gqrhPfI=",
      "url": "bootstrap-icons/icons/chevron-left.svg"
    },
    {
      "hash": "sha256-UbnEFosSs3is3jExI0/+Ky+l7TyAqUSn3IZLtRW0ac8=",
      "url": "bootstrap-icons/icons/chevron-right.svg"
    },
    {
      "hash": "sha256-B3q0ELau/VoGTAlVwZqPCG//r14Ix7bupY9hHNFeiFM=",
      "url": "bootstrap-icons/icons/chevron-up.svg"
    },
    {
      "hash": "sha256-m7ysZJzxAAKJpa+v9JF7nqnrewY8AULViXdvqWVlgOI=",
      "url": "bootstrap-icons/icons/circle-fill.svg"
    },
    {
      "hash": "sha256-Zd40cmLNiooehS569gCLEORfQXth2wDdVOUeX9E8zdU=",
      "url": "bootstrap-icons/icons/circle-half.svg"
    },
    {
      "hash": "sha256-9omTS3YLTA7B5TgacF+jA8iR7G9k6ff21fgS/fmXH1o=",
      "url": "bootstrap-icons/icons/circle-square.svg"
    },
    {
      "hash": "sha256-crOzKoWvmNKouogFcG1WgoclLu2D/IdmrKIW5WrdFAs=",
      "url": "bootstrap-icons/icons/circle.svg"
    },
    {
      "hash": "sha256-IEuLIYQlWeDA99+Lw9t1cTtzL0a0yoEIMUBHfXeqM1A=",
      "url": "bootstrap-icons/icons/claude.svg"
    },
    {
      "hash": "sha256-74IhMhs1SRqp31UcKC1LrgukHF2JYcj91jO2AHJF8bo=",
      "url": "bootstrap-icons/icons/clipboard-check-fill.svg"
    },
    {
      "hash": "sha256-qYdaklT7Lz3ewtM6jJFplmAXTnMorQDEsGfoIqG4dDE=",
      "url": "bootstrap-icons/icons/clipboard-check.svg"
    },
    {
      "hash": "sha256-Yp26J5LBUrQnNSNIl+beARWB9G5UVhn0nFJmkQvhch8=",
      "url": "bootstrap-icons/icons/clipboard-data-fill.svg"
    },
    {
      "hash": "sha256-0glb91GgEYVD5HISVYpAWJ7LonopH3je565p3QwWE2U=",
      "url": "bootstrap-icons/icons/clipboard-data.svg"
    },
    {
      "hash": "sha256-jFHN+sRcXd/vQsADJ8JZLteQ6uHsxGKAizRnu8KHX2Y=",
      "url": "bootstrap-icons/icons/clipboard-fill.svg"
    },
    {
      "hash": "sha256-EnZpdH4xRWIeCsw9AI4k3F0NAof0drI0gzTMDZIS6K8=",
      "url": "bootstrap-icons/icons/clipboard-heart-fill.svg"
    },
    {
      "hash": "sha256-j8/HjmSXcjwhglFgGU2t4m7CE/FveH0dnqRIq6c/064=",
      "url": "bootstrap-icons/icons/clipboard-heart.svg"
    },
    {
      "hash": "sha256-8IF6vLI2hvb+gnzS0magNkLS6ibds7OKUTrtYJIEoqA=",
      "url": "bootstrap-icons/icons/clipboard-minus-fill.svg"
    },
    {
      "hash": "sha256-F62uB0RvbJYOlWaSSivJwTBkgXxti7DXvn8g5pd6HF4=",
      "url": "bootstrap-icons/icons/clipboard-minus.svg"
    },
    {
      "hash": "sha256-cWAmWgE83kTJw7XOwumqrEDq+ebYjnJJ3x6az/7saBI=",
      "url": "bootstrap-icons/icons/clipboard-plus-fill.svg"
    },
    {
      "hash": "sha256-JmJy09ArjMm46g809fVJVIxF7PDv4IBrl6bvlPCsexU=",
      "url": "bootstrap-icons/icons/clipboard-plus.svg"
    },
    {
      "hash": "sha256-KTY1oqAGene9n1TJwPwvGPnZ+c5Bg+idpUR+LEq/QQg=",
      "url": "bootstrap-icons/icons/clipboard-pulse.svg"
    },
    {
      "hash": "sha256-l792IFKoKCLjobrm5AMEdShgwqLq26/TmpBu82EJ7TA=",
      "url": "bootstrap-icons/icons/clipboard-x-fill.svg"
    },
    {
      "hash": "sha256-7N5J/eCU9O9bzhgII4/rCN5DENdBjEKh5BrAHDi+aMQ=",
      "url": "bootstrap-icons/icons/clipboard-x.svg"
    },
    {
      "hash": "sha256-tc14pshrzAcFVVvogAAJCLgQMKzHyaYWdi0e2qz3Gpg=",
      "url": "bootstrap-icons/icons/clipboard.svg"
    },
    {
      "hash": "sha256-ERfNluMP9kT6xzFTtchwEPO1zyVr3Iwnbbb77ZmZNYc=",
      "url": "bootstrap-icons/icons/clipboard2-check-fill.svg"
    },
    {
      "hash": "sha256-M3uWKPNbvZ+hp6UORc0lXnMptny1PP65pXB7hvTerc8=",
      "url": "bootstrap-icons/icons/clipboard2-check.svg"
    },
    {
      "hash": "sha256-STAMu5P8LWzq0gYD5FAUfLgzOOyP9AgKC+VkFsBnqSY=",
      "url": "bootstrap-icons/icons/clipboard2-data-fill.svg"
    },
    {
      "hash": "sha256-U99X0NRfxm3PMNgJ0A+a5GqCdBi6maLNVg4cz58NXIo=",
      "url": "bootstrap-icons/icons/clipboard2-data.svg"
    },
    {
      "hash": "sha256-mfXpBB4lFgpumnU++3vbKzaG86hu1IysfgzA4o41tNo=",
      "url": "bootstrap-icons/icons/clipboard2-fill.svg"
    },
    {
      "hash": "sha256-sEQSMkBOPeI2SKs988ejjM0nCLRI+/h6xTpnfzajezM=",
      "url": "bootstrap-icons/icons/clipboard2-heart-fill.svg"
    },
    {
      "hash": "sha256-3d8easfDUcQIbiUoWuIDoUy4O/KSC9MupjJxuGxSAoA=",
      "url": "bootstrap-icons/icons/clipboard2-heart.svg"
    },
    {
      "hash": "sha256-Tx4m8YWEY5JGXWxfdVto6lLqrPr2l9JXy1bYvLx1SkQ=",
      "url": "bootstrap-icons/icons/clipboard2-minus-fill.svg"
    },
    {
      "hash": "sha256-LIOAgsionBb2KRwUGUyNjY7spScSbCCXhOfke4ZvaHQ=",
      "url": "bootstrap-icons/icons/clipboard2-minus.svg"
    },
    {
      "hash": "sha256-OeYBRS9PritmtQDOKhW+vd9yihBuKYBabcjpYCh48EA=",
      "url": "bootstrap-icons/icons/clipboard2-plus-fill.svg"
    },
    {
      "hash": "sha256-9BgbuOoACymZfHQrhmPzIKSWTApyQJa2iCkAvQJlJRE=",
      "url": "bootstrap-icons/icons/clipboard2-plus.svg"
    },
    {
      "hash": "sha256-IoBMS+R61u5xPBx0JBZNvDl0aI6gBcp7y6iPlYWFAwY=",
      "url": "bootstrap-icons/icons/clipboard2-pulse-fill.svg"
    },
    {
      "hash": "sha256-FC8gS2B+McKXbjx2ERrHI+iJ0yhtAGr1tL0o0n3MZ7A=",
      "url": "bootstrap-icons/icons/clipboard2-pulse.svg"
    },
    {
      "hash": "sha256-8OGVZ35bLaVnhZDwG8d80afaTseYBXYoIGz76KbOai8=",
      "url": "bootstrap-icons/icons/clipboard2-x-fill.svg"
    },
    {
      "hash": "sha256-i2XCrBBVVVhrlZMbencY4FkxHem8SUH7EMjKBWI11a4=",
      "url": "bootstrap-icons/icons/clipboard2-x.svg"
    },
    {
      "hash": "sha256-4KbDI1+tHQg0Loj/Kn/RoFZ6UVNc4CfO3pXa9KJWgZ4=",
      "url": "bootstrap-icons/icons/clipboard2.svg"
    },
    {
      "hash": "sha256-JrTbxqhcEns8jOZprTIFi4riOIavmbgk9Ks1rfAg2Us=",
      "url": "bootstrap-icons/icons/clock-fill.svg"
    },
    {
      "hash": "sha256-TjeYdPW8ZUeEVe6lGBVjjCSgBBsIcUn/vH0kNTXU2Ck=",
      "url": "bootstrap-icons/icons/clock-history.svg"
    },
    {
      "hash": "sha256-UIkyjupzk00b+Ysw4vERyYPxRVJDsGCVsUVKNsRi57I=",
      "url": "bootstrap-icons/icons/clock.svg"
    },
    {
      "hash": "sha256-RuixRr4ypsodexvc2f92e/JSDXfcdfSrPKXpvi0HvyQ=",
      "url": "bootstrap-icons/icons/cloud-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-GoZg1Fb/oN26dxaOJsibaGH61YxKFBgLAUn5zoWBcc8=",
      "url": "bootstrap-icons/icons/cloud-arrow-down.svg"
    },
    {
      "hash": "sha256-EWZlKWLXcDY8hgTEqWgVWTFdZ434171oeklKv79kDt4=",
      "url": "bootstrap-icons/icons/cloud-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-oYeMcJ0YWFp0jgAd1fN5LIwmyakR6QPfGqKEhsXMCPc=",
      "url": "bootstrap-icons/icons/cloud-arrow-up.svg"
    },
    {
      "hash": "sha256-u1UMG0S09Uy1t/gaxQe2te3IoyqC0TrJSLyghE64GY8=",
      "url": "bootstrap-icons/icons/cloud-check-fill.svg"
    },
    {
      "hash": "sha256-kgLNeSh5beqpKJmvmdQ0Q7vz4/KoN0G0k1O6b49mWAA=",
      "url": "bootstrap-icons/icons/cloud-check.svg"
    },
    {
      "hash": "sha256-IahaDH832yjbX1UfmHqKbK1CtVhJ4YG8hqZ/Bu+4C6w=",
      "url": "bootstrap-icons/icons/cloud-download-fill.svg"
    },
    {
      "hash": "sha256-gWMKTV1DisMn+XJUlFdWDhnVGdvuDZvz4E+/BeG+E/o=",
      "url": "bootstrap-icons/icons/cloud-download.svg"
    },
    {
      "hash": "sha256-lf14heEJIWusfw6bwoJOzU/4Ee4RJfvbqbERBHbVaWw=",
      "url": "bootstrap-icons/icons/cloud-drizzle-fill.svg"
    },
    {
      "hash": "sha256-qn0xULtUoeuO8NgPnIpjce6sbMhZl1dX9/CcV2+B6Bw=",
      "url": "bootstrap-icons/icons/cloud-drizzle.svg"
    },
    {
      "hash": "sha256-Clsr00B8/eFM4YjnIsDhUMu8ySiDvR3tcUYFON+KOEE=",
      "url": "bootstrap-icons/icons/cloud-fill.svg"
    },
    {
      "hash": "sha256-yBgtIlBAt7AWTF4b5Iy2qHrMZR5gYYIjj7Bycj8dfB0=",
      "url": "bootstrap-icons/icons/cloud-fog-fill.svg"
    },
    {
      "hash": "sha256-BzcEQg0Xwv+3TJkYkTj9huK4nAZ81YgAXmbURj+LvP4=",
      "url": "bootstrap-icons/icons/cloud-fog.svg"
    },
    {
      "hash": "sha256-KtIBrsIuBBrVa0nWXrix8Mu/Lti7EOklHjDwC3SHzWA=",
      "url": "bootstrap-icons/icons/cloud-fog2-fill.svg"
    },
    {
      "hash": "sha256-DD8/YBo+59pg7GyBEVlIgbQiD5axLMS6yoSCeaEQrVk=",
      "url": "bootstrap-icons/icons/cloud-fog2.svg"
    },
    {
      "hash": "sha256-NgCj65/E2NttXyX1YFr04pXDPKD/fogfPnqYDgqc7Vg=",
      "url": "bootstrap-icons/icons/cloud-hail-fill.svg"
    },
    {
      "hash": "sha256-rcDS372SW8uNhiwpHHEeHq0S0d86JHrGNw/AUvnjYzs=",
      "url": "bootstrap-icons/icons/cloud-hail.svg"
    },
    {
      "hash": "sha256-px8oCxWb2iPWP+LGwEJh/iGIv5KMs/Q+x6+zs/roz4w=",
      "url": "bootstrap-icons/icons/cloud-haze-fill.svg"
    },
    {
      "hash": "sha256-WlKEc0hqOpldj8Y+7FBCz7r7SgyR6V0dVQRPNy1+pnE=",
      "url": "bootstrap-icons/icons/cloud-haze.svg"
    },
    {
      "hash": "sha256-UCUr/CvjKDP8ctyntMxBobwSMvWlW9V7tPb4ovG9KIQ=",
      "url": "bootstrap-icons/icons/cloud-haze2-fill.svg"
    },
    {
      "hash": "sha256-xWP7eyT682UfHhmv32tsNAHATZZ9e3+Rt7UUjPcvZj0=",
      "url": "bootstrap-icons/icons/cloud-haze2.svg"
    },
    {
      "hash": "sha256-w13igU7zU/uOTvJ5NDPO+hXNpqds/tmLhxEW7BoLBoE=",
      "url": "bootstrap-icons/icons/cloud-lightning-fill.svg"
    },
    {
      "hash": "sha256-nTx6mmoa0c2OWF7IsEIDxSkYA80Ev41ck5A0vnaKeAw=",
      "url": "bootstrap-icons/icons/cloud-lightning-rain-fill.svg"
    },
    {
      "hash": "sha256-U/3j1q3ApF3BRsAf5K+p/L4IvkaAE8B0pEGd2FkOcng=",
      "url": "bootstrap-icons/icons/cloud-lightning-rain.svg"
    },
    {
      "hash": "sha256-odTIXxDzp/SL/DIOvCHvDssgxpxODzPO0F3Qb1uM1W0=",
      "url": "bootstrap-icons/icons/cloud-lightning.svg"
    },
    {
      "hash": "sha256-ijBBYFhSxMTSWbMor+32C7l2B6LQUGJMN7ungE9q1Pw=",
      "url": "bootstrap-icons/icons/cloud-minus-fill.svg"
    },
    {
      "hash": "sha256-FsTjh7mftMXiEuaS2u0REw6A533aeLh4rWIDNg/5ywg=",
      "url": "bootstrap-icons/icons/cloud-minus.svg"
    },
    {
      "hash": "sha256-JocV3rUPNG/oM61hNfJyBv8VXEoZf9ibCZNVU884kSs=",
      "url": "bootstrap-icons/icons/cloud-moon-fill.svg"
    },
    {
      "hash": "sha256-4Zlj7o14TkYAAVxTP9lThAfUB24ofrrzjpius8ocguk=",
      "url": "bootstrap-icons/icons/cloud-moon.svg"
    },
    {
      "hash": "sha256-E17bcVsGs4O2f0b5ABqxQDqDIqdnT4J9rlyeFvvOCSc=",
      "url": "bootstrap-icons/icons/cloud-plus-fill.svg"
    },
    {
      "hash": "sha256-0qWUzBust52NKgATKUdNyGMtoldcoCKd8WekK21xDqg=",
      "url": "bootstrap-icons/icons/cloud-plus.svg"
    },
    {
      "hash": "sha256-QGtXUHsTSgxNXPnvHiNXKZcEo+SCbbHSviMl5IdQj7U=",
      "url": "bootstrap-icons/icons/cloud-rain-fill.svg"
    },
    {
      "hash": "sha256-JftXXKxrSArdrs/tfIZO0zChMfB9PoEUnAOyEZU2AUY=",
      "url": "bootstrap-icons/icons/cloud-rain-heavy-fill.svg"
    },
    {
      "hash": "sha256-1mC9kYVWhChf38Y/K+4QrCfoqFmKSfK+Rxb7FFUjG7M=",
      "url": "bootstrap-icons/icons/cloud-rain-heavy.svg"
    },
    {
      "hash": "sha256-FbTtIpkbPn2qxeOna46MwTOtTOww5p4F72lamUMM6C0=",
      "url": "bootstrap-icons/icons/cloud-rain.svg"
    },
    {
      "hash": "sha256-CeD0famLjbvdcBDA8QeWU5WzASSv+INkvZpyBBIC1s0=",
      "url": "bootstrap-icons/icons/cloud-slash-fill.svg"
    },
    {
      "hash": "sha256-qUvkNMwNNyPGFhPO0RuqIURVSNp04pvDJumM9XtF6bI=",
      "url": "bootstrap-icons/icons/cloud-slash.svg"
    },
    {
      "hash": "sha256-qQeCub1Oq8iFAq24dyb8VjVK8FH3FiCVMlpA3SM58ko=",
      "url": "bootstrap-icons/icons/cloud-sleet-fill.svg"
    },
    {
      "hash": "sha256-+6bFPtggYX9A6Sx19r77rgyj/i4K/fcvQWfkrzPH0VY=",
      "url": "bootstrap-icons/icons/cloud-sleet.svg"
    },
    {
      "hash": "sha256-/3v0q4UUH+xlVbChYYJhWRDaM5vHlTRuH8LmS/eMPZ4=",
      "url": "bootstrap-icons/icons/cloud-snow-fill.svg"
    },
    {
      "hash": "sha256-OZxtSsAwTwedokwxxQn3En+JHRIyMxFBYP7VpCezPlY=",
      "url": "bootstrap-icons/icons/cloud-snow.svg"
    },
    {
      "hash": "sha256-G1eFb/quhQoCJxWYeH0HFHmkinzVzt5g/A8ebfAUBoI=",
      "url": "bootstrap-icons/icons/cloud-sun-fill.svg"
    },
    {
      "hash": "sha256-g0u1bR3BT8ZTF320JGDuIRys64VeCSneUoA4/vQf6lA=",
      "url": "bootstrap-icons/icons/cloud-sun.svg"
    },
    {
      "hash": "sha256-L2yX2GTi1nfSh6jRcEN0p/B/MbMbz+7Mov1H74kGSS8=",
      "url": "bootstrap-icons/icons/cloud-upload-fill.svg"
    },
    {
      "hash": "sha256-l+PNyw5kL0B1JkiJsq6Ri6fU27JItloC45CVHHTyL8k=",
      "url": "bootstrap-icons/icons/cloud-upload.svg"
    },
    {
      "hash": "sha256-5DdVrlg3+USpex3LhdczknJatY6k152zN10puwjjiq0=",
      "url": "bootstrap-icons/icons/cloud.svg"
    },
    {
      "hash": "sha256-WZUj3AfpL3IFlgTgaatQcIy0mEgcOs1zgwXF+yaEM1k=",
      "url": "bootstrap-icons/icons/clouds-fill.svg"
    },
    {
      "hash": "sha256-rksgYRoVLiuE2n/7hLWOX7WunOxrMU0ex99mlWTyZOY=",
      "url": "bootstrap-icons/icons/clouds.svg"
    },
    {
      "hash": "sha256-+Xmo5HDfFzsunRa54TFyDeYiAjV8dBqYCF4Bf7fnR9M=",
      "url": "bootstrap-icons/icons/cloudy-fill.svg"
    },
    {
      "hash": "sha256-E3W/koqC6nqaS+a66qe+vXYGwgTIlr2UvhxN0LytPU4=",
      "url": "bootstrap-icons/icons/cloudy.svg"
    },
    {
      "hash": "sha256-wHebHnWBnu7ZBrqUE+0wt4YeVE0WsNkDXDsZt4wvTLM=",
      "url": "bootstrap-icons/icons/code-slash.svg"
    },
    {
      "hash": "sha256-N3aeNsDU6NgXLnuja4UQSIiq2uNvbHO1qRBaEixJU8w=",
      "url": "bootstrap-icons/icons/code-square.svg"
    },
    {
      "hash": "sha256-zQPMHoiGOH0WQlU+5OtJxDXLSShiI9dRTgYYFkuRJsk=",
      "url": "bootstrap-icons/icons/code.svg"
    },
    {
      "hash": "sha256-s0jOIAUNjE9vsQitifv9TWEIRUJf0TIQUSqNYFOeHHI=",
      "url": "bootstrap-icons/icons/coin.svg"
    },
    {
      "hash": "sha256-FyMdVd0dDH7VMLGszXf0fsOs2Tx71SDfpXg6fRmlohI=",
      "url": "bootstrap-icons/icons/collection-fill.svg"
    },
    {
      "hash": "sha256-VauqLXL0NOaUqWBtfIuTBzIGuPkxsQDRfibgrCC+9dA=",
      "url": "bootstrap-icons/icons/collection-play-fill.svg"
    },
    {
      "hash": "sha256-HBH6pse7YJNbC7FctwCcHuXu8WTEzNGZdG72fXZd0VE=",
      "url": "bootstrap-icons/icons/collection-play.svg"
    },
    {
      "hash": "sha256-MMOaKgHCUwD/VudTOnh3DdofMSrxn9202ndf11oCKuU=",
      "url": "bootstrap-icons/icons/collection.svg"
    },
    {
      "hash": "sha256-ADq2Q+ZehcKpDhrwojaRQ4Xm0MZRcClCjcVZy7bZFOQ=",
      "url": "bootstrap-icons/icons/columns-gap.svg"
    },
    {
      "hash": "sha256-6zMr+nFyLbUrAljW/oblQMgdCCI8jjgP9W/gPhXfXT0=",
      "url": "bootstrap-icons/icons/columns.svg"
    },
    {
      "hash": "sha256-If0nS+MScVwZ2qvgRfcL1PQ+7Dz/7qC7J8/DViAg/Sc=",
      "url": "bootstrap-icons/icons/command.svg"
    },
    {
      "hash": "sha256-2z64RHBCfd/CFR3vq3t0hWc7f8gh5eFMHRGv96lxRYs=",
      "url": "bootstrap-icons/icons/compass-fill.svg"
    },
    {
      "hash": "sha256-22DoGLvviWICxIQDtA6E3lml0HsuaKg/OiOIGXZ6YGM=",
      "url": "bootstrap-icons/icons/compass.svg"
    },
    {
      "hash": "sha256-82C3xJ5qxQ7v3VaJZA8LoUEZwLx0yM26gHJX8MxX72Q=",
      "url": "bootstrap-icons/icons/cone-striped.svg"
    },
    {
      "hash": "sha256-mO1GCcZaEIQ46v02x0nlOwGc/J1vqpF/2T4BBOyhEmQ=",
      "url": "bootstrap-icons/icons/cone.svg"
    },
    {
      "hash": "sha256-H2Gol346qPYgNFzO0LvrYhrFQ2nYdqzmi+LQQcRaO2o=",
      "url": "bootstrap-icons/icons/controller.svg"
    },
    {
      "hash": "sha256-ZrmTBwMK/G+ITVLiR0EFXBeFBIEKoMKLj95x3sMs/iY=",
      "url": "bootstrap-icons/icons/cookie.svg"
    },
    {
      "hash": "sha256-KDSy7iEFVEEVasLQM6IHwc50+s3bv5za3Njmex1tA/I=",
      "url": "bootstrap-icons/icons/copy.svg"
    },
    {
      "hash": "sha256-o0UcyXqL1KCJJ4BpPQU3cGs0S6pXS/AIhNVA3hqJB68=",
      "url": "bootstrap-icons/icons/cpu-fill.svg"
    },
    {
      "hash": "sha256-KMzyNCJG0tXii49je+vLgBFlxMtDdwqvbuZnLLbJQc4=",
      "url": "bootstrap-icons/icons/cpu.svg"
    },
    {
      "hash": "sha256-PraeOIt4GLCWN2BzsR3v80LlsD0I+s4m18QNhhmqmN0=",
      "url": "bootstrap-icons/icons/credit-card-2-back-fill.svg"
    },
    {
      "hash": "sha256-WCxbJ59e8wVXkT6d99TmYHLmOzw5urX1Acizd3hi1OQ=",
      "url": "bootstrap-icons/icons/credit-card-2-back.svg"
    },
    {
      "hash": "sha256-T9IoJmivWyQ14MC3bqECh4Xo3Zs0eQ+wd5liXcr1YFQ=",
      "url": "bootstrap-icons/icons/credit-card-2-front-fill.svg"
    },
    {
      "hash": "sha256-n56wnHLB2zyvnlTHJxKnkdvisYW51qUbjYQeI22mxyU=",
      "url": "bootstrap-icons/icons/credit-card-2-front.svg"
    },
    {
      "hash": "sha256-lNYaj0xxWYujT9OhnokTU4ZTE/F/71Apbaz64yW5Tzk=",
      "url": "bootstrap-icons/icons/credit-card-fill.svg"
    },
    {
      "hash": "sha256-42SvdgxiJ2Uu1pVuLWHQ8fLpTZ4IMPWO5YcQhFh60nI=",
      "url": "bootstrap-icons/icons/credit-card.svg"
    },
    {
      "hash": "sha256-UffSe33iWjVapwOKf+3JIU7GIVUwteaKpJHhqMk5oTY=",
      "url": "bootstrap-icons/icons/crop.svg"
    },
    {
      "hash": "sha256-8P8U8l1jKEA0h0JoRQw+kKin4n2mW4wev5n7pBinepA=",
      "url": "bootstrap-icons/icons/crosshair.svg"
    },
    {
      "hash": "sha256-eWPrf4hN5zF/wPgze8khvvALCMo84gBRhwKygjIOVj4=",
      "url": "bootstrap-icons/icons/crosshair2.svg"
    },
    {
      "hash": "sha256-wW9Z8iByh/zY2YYP/MhbkBSE/SYhrcV6CdTXDbmUeGg=",
      "url": "bootstrap-icons/icons/css.svg"
    },
    {
      "hash": "sha256-0zsfXgb35oJ+mnK/NNrIPuSN4Wsz87pRC55AU4xruZc=",
      "url": "bootstrap-icons/icons/cup-fill.svg"
    },
    {
      "hash": "sha256-P5/RRtTFj2T5MZpJvUvEUU5M9mpzb0mqkuu0NbE/zsQ=",
      "url": "bootstrap-icons/icons/cup-hot-fill.svg"
    },
    {
      "hash": "sha256-123RY8T53lm8lNSKp2CxgeNYmwxmpgCZVB8wVt9rBA0=",
      "url": "bootstrap-icons/icons/cup-hot.svg"
    },
    {
      "hash": "sha256-Gq9LCHDLdtT/wRLblYkrtyaH9SrI3gKDlKHsxACyIQE=",
      "url": "bootstrap-icons/icons/cup-straw.svg"
    },
    {
      "hash": "sha256-fB3jrdzv6gLYGjwIJBmOdJgqhv1BYT/TxFGeprGYnMw=",
      "url": "bootstrap-icons/icons/cup.svg"
    },
    {
      "hash": "sha256-gECvmi2Al6wjI41D+Zz9DkvmtimM1SSROLPXNW5qyIY=",
      "url": "bootstrap-icons/icons/currency-bitcoin.svg"
    },
    {
      "hash": "sha256-ZQpW3TfVyaHefSANI0aR2ueSr+pzkUid9TfIowOZhPs=",
      "url": "bootstrap-icons/icons/currency-dollar.svg"
    },
    {
      "hash": "sha256-ttCyiLDB12U7XUpGu0ZXPVyIz2IWjqC4pH//ehhRh4M=",
      "url": "bootstrap-icons/icons/currency-euro.svg"
    },
    {
      "hash": "sha256-RuC13szVpoDxTDTCAIlOsjHlOxd7BBXTixrcynwK0fU=",
      "url": "bootstrap-icons/icons/currency-exchange.svg"
    },
    {
      "hash": "sha256-/BO8Xyvbb/3cfKSPB+sBmQTR/AYYKrf+i/KGhXhBhyk=",
      "url": "bootstrap-icons/icons/currency-pound.svg"
    },
    {
      "hash": "sha256-XbG006b81OOnUvdkQ+PiSW2eY7AXw7wUBh4qQsCMtLM=",
      "url": "bootstrap-icons/icons/currency-rupee.svg"
    },
    {
      "hash": "sha256-HY5m/+l5tYMaQUOB4ubWyyNGDDBuPW8wXa6XbdCWYF4=",
      "url": "bootstrap-icons/icons/currency-yen.svg"
    },
    {
      "hash": "sha256-weINWUiwnc76678PXRShIllZsmR3KvPfpXxVoiHBJzk=",
      "url": "bootstrap-icons/icons/cursor-fill.svg"
    },
    {
      "hash": "sha256-x1B+PriOoRt96aQBnX2qh4a1DGOz13ipF3kxxhDE7Ic=",
      "url": "bootstrap-icons/icons/cursor-text.svg"
    },
    {
      "hash": "sha256-b7mDWgO8GeWsiKQgJM64xuQ0R30AR5thSpx7PtfN0k4=",
      "url": "bootstrap-icons/icons/cursor.svg"
    },
    {
      "hash": "sha256-0lF7Vabmz5TsNGD8yOEzipkSAzQi7AXrw12394LHIT8=",
      "url": "bootstrap-icons/icons/dash-circle-dotted.svg"
    },
    {
      "hash": "sha256-ZeFW9ZDYDKZQHVlf2wWFixm0mS8VkBXkyRjkLSezEXA=",
      "url": "bootstrap-icons/icons/dash-circle-fill.svg"
    },
    {
      "hash": "sha256-287xfie9QQf6H26AtNx1etdwy3WZfxucc17HD00OBHY=",
      "url": "bootstrap-icons/icons/dash-circle.svg"
    },
    {
      "hash": "sha256-YcrC1NQk81nIexBu8+tuG6cGkxQqYhUKJeKT1ZnUSZw=",
      "url": "bootstrap-icons/icons/dash-lg.svg"
    },
    {
      "hash": "sha256-qIih5OOOOiNWvsjqFlC0X65lKQfD9/Qi25MAab7lRYA=",
      "url": "bootstrap-icons/icons/dash-square-dotted.svg"
    },
    {
      "hash": "sha256-Fo2tBCy79jyJkBzYwx4F6rMW3pbNzl6hjUNps8D+Hvw=",
      "url": "bootstrap-icons/icons/dash-square-fill.svg"
    },
    {
      "hash": "sha256-db8I1RQ8ZI8ickgd0tg2VZfF/SfM647Sz9kSsjdX3fE=",
      "url": "bootstrap-icons/icons/dash-square.svg"
    },
    {
      "hash": "sha256-vvTOPoGhbLjguTXQucI1yDvln58NtmZbtbTv4ezuXq8=",
      "url": "bootstrap-icons/icons/dash.svg"
    },
    {
      "hash": "sha256-5eT1Mce5UcOPi9AVmuYjmfxBK0kGD54M7Q+nV385wsQ=",
      "url": "bootstrap-icons/icons/database-add.svg"
    },
    {
      "hash": "sha256-rDyXmDRYUTgR9Kut7sj1qwimbacPJCMRJimKAmBvBqE=",
      "url": "bootstrap-icons/icons/database-check.svg"
    },
    {
      "hash": "sha256-jehuA2TCKr6x7Wan1mmcf8QMpbstwTM4aJ2sF2XEp/Y=",
      "url": "bootstrap-icons/icons/database-dash.svg"
    },
    {
      "hash": "sha256-DrQqZCx7h+C1kUSO+XGKFEo1vs0ICOLuxn+lCrRaaGI=",
      "url": "bootstrap-icons/icons/database-down.svg"
    },
    {
      "hash": "sha256-3Hn4XSeBjneh5GEDj7Z1pEXSwDQ6p6qEHO8v0XXGQcA=",
      "url": "bootstrap-icons/icons/database-exclamation.svg"
    },
    {
      "hash": "sha256-SpRd3eMWdCgMn5snTsrFggYlrwlotoiDraG3vXF+Uf4=",
      "url": "bootstrap-icons/icons/database-fill-add.svg"
    },
    {
      "hash": "sha256-Z1ZfcvfkVZKTMUtRih0K8uTWY8gdFo4tdoMyI9y9X6M=",
      "url": "bootstrap-icons/icons/database-fill-check.svg"
    },
    {
      "hash": "sha256-uGNsHA5Nm4TTJ0lhWgVKieBQNT62S22jdiG31X2XdQo=",
      "url": "bootstrap-icons/icons/database-fill-dash.svg"
    },
    {
      "hash": "sha256-SMCIgVX4/fzFbJtYbQG8G/GXgAWlbAo0guwbiCFH1oY=",
      "url": "bootstrap-icons/icons/database-fill-down.svg"
    },
    {
      "hash": "sha256-3ib292DASIEhLPXKcOLqi+f5FpraJQ71zsizSMeZaSQ=",
      "url": "bootstrap-icons/icons/database-fill-exclamation.svg"
    },
    {
      "hash": "sha256-JeRev9MnwTtgPKRXNl4mSluK3+lZXvaxUOY3Rk0Tdyo=",
      "url": "bootstrap-icons/icons/database-fill-gear.svg"
    },
    {
      "hash": "sha256-fxTeWx9qCVD/lUU0VB+4N3HVkPZvLasZnF++anA27cg=",
      "url": "bootstrap-icons/icons/database-fill-lock.svg"
    },
    {
      "hash": "sha256-aoUtqSmU+Yn4BhlPl++9Xknn+5tGdx4SG1eytkNkgmw=",
      "url": "bootstrap-icons/icons/database-fill-slash.svg"
    },
    {
      "hash": "sha256-AngTUGIV08GfmQ4tUEdB5lbrSuaWbtqBag/rp7mC+3g=",
      "url": "bootstrap-icons/icons/database-fill-up.svg"
    },
    {
      "hash": "sha256-6Pn28yJLuzPca+ELuKif0UATTLoL4wnH5jqYSdxMbzk=",
      "url": "bootstrap-icons/icons/database-fill-x.svg"
    },
    {
      "hash": "sha256-F+ED3IfzV3rGkJLYcB2FTJP57udeMjaYfuBryXRWQOY=",
      "url": "bootstrap-icons/icons/database-fill.svg"
    },
    {
      "hash": "sha256-H/VdWzDnO4Yfij87IrMi+O47Qvz4k07e4sw/0CF0YbU=",
      "url": "bootstrap-icons/icons/database-gear.svg"
    },
    {
      "hash": "sha256-B72mfWSjmaNDruIGl8ftoWbHUU3prLsKycu5m1ipPl8=",
      "url": "bootstrap-icons/icons/database-lock.svg"
    },
    {
      "hash": "sha256-hlgq1Y5yE5qDuN5u2+wSocIMTk8sxCX+EYR1Om0S8KI=",
      "url": "bootstrap-icons/icons/database-slash.svg"
    },
    {
      "hash": "sha256-3QbmYK6unhPzzCV1XYSKNK7El4/ZmN6VqzDzYgWkyfY=",
      "url": "bootstrap-icons/icons/database-up.svg"
    },
    {
      "hash": "sha256-uE3LxTHr125OzvFRjdLq6LXKuYaQI24okhl/NXfntSE=",
      "url": "bootstrap-icons/icons/database-x.svg"
    },
    {
      "hash": "sha256-BOtSd0FoAd5yfrtNKJhnlydu2W8M4R0W75URE2C3oR0=",
      "url": "bootstrap-icons/icons/database.svg"
    },
    {
      "hash": "sha256-G2D0UGMJRwB1VpVKW2f8HYdz3C8jtxTWz7MQ2SgdqSk=",
      "url": "bootstrap-icons/icons/device-hdd-fill.svg"
    },
    {
      "hash": "sha256-fYEhq4qSFpfnQTGCNbv4XMYDmxeatKIw8qnZnJXCSzs=",
      "url": "bootstrap-icons/icons/device-hdd.svg"
    },
    {
      "hash": "sha256-RPBqqNfTNrdpwVbx4bUMF679gtKiTO1IMtC/SxT6eEI=",
      "url": "bootstrap-icons/icons/device-ssd-fill.svg"
    },
    {
      "hash": "sha256-xRuDYyeMSCweAW1LXUHlzv0XichOcsCg/1ENt/8fy+s=",
      "url": "bootstrap-icons/icons/device-ssd.svg"
    },
    {
      "hash": "sha256-/798HqKVt7+NSyeRfFZk9sftYmqexKTDppHSd684C/Q=",
      "url": "bootstrap-icons/icons/diagram-2-fill.svg"
    },
    {
      "hash": "sha256-x2PaGTiIR+gGbQdlPITelT5f9WkgeoUMqapfnNKxcCM=",
      "url": "bootstrap-icons/icons/diagram-2.svg"
    },
    {
      "hash": "sha256-gs1sDg7tQ8pCgdtT21TsFK7AkvURxFVaeQO0xdbUATE=",
      "url": "bootstrap-icons/icons/diagram-3-fill.svg"
    },
    {
      "hash": "sha256-1IEHt30TnixvcTVKOgu5uakxTFHitgaTIILuUdWAqa4=",
      "url": "bootstrap-icons/icons/diagram-3.svg"
    },
    {
      "hash": "sha256-aZ35vtnw297xZPJpiO3rw4+40GBp77HENoW/oW9vWX4=",
      "url": "bootstrap-icons/icons/diamond-fill.svg"
    },
    {
      "hash": "sha256-TT9lPmIQnUdJ7WzHnWq1BiGXlSGmf7vnAHLfkDgQHLQ=",
      "url": "bootstrap-icons/icons/diamond-half.svg"
    },
    {
      "hash": "sha256-qc8tmOnjMidL53XjCe9YdXYPy+3XOj1kbOQ3Fb7DoaA=",
      "url": "bootstrap-icons/icons/diamond.svg"
    },
    {
      "hash": "sha256-hYcC888HWueC+VOUjIdr+o9xnIMAJ8GDjMGNl6+aSjQ=",
      "url": "bootstrap-icons/icons/dice-1-fill.svg"
    },
    {
      "hash": "sha256-ayGL5KTwQHtWLn2n+n1O9aBRqJye0GqoW3muP02NSNw=",
      "url": "bootstrap-icons/icons/dice-1.svg"
    },
    {
      "hash": "sha256-6BavQc0udQECBLP0A5hXFuIlHj9+sQfQ0/4LsImTIlc=",
      "url": "bootstrap-icons/icons/dice-2-fill.svg"
    },
    {
      "hash": "sha256-ZOKdISHcAOgaXxrPw1cbZ1nrp5Av66UpC556PlygQPo=",
      "url": "bootstrap-icons/icons/dice-2.svg"
    },
    {
      "hash": "sha256-z7VC5ZF/BF00tlvcrd3XxbeKdwOEX0ueGmoPFfxS0wY=",
      "url": "bootstrap-icons/icons/dice-3-fill.svg"
    },
    {
      "hash": "sha256-8vFrPMNnxSLhGDVPaNEbr36E/TuDPx89KZP8syaQYK0=",
      "url": "bootstrap-icons/icons/dice-3.svg"
    },
    {
      "hash": "sha256-Ciyo3id2Q0xNj1jLdniKUdO2ePi49pCzYp3YO1QOCzU=",
      "url": "bootstrap-icons/icons/dice-4-fill.svg"
    },
    {
      "hash": "sha256-afjsgME932OTbiIb5ykldCWXN62yuo9XoqDUOEqlmIk=",
      "url": "bootstrap-icons/icons/dice-4.svg"
    },
    {
      "hash": "sha256-m6kTduVJrybLclUJdo4t4ydlV8nrtraZItikY0oLrzg=",
      "url": "bootstrap-icons/icons/dice-5-fill.svg"
    },
    {
      "hash": "sha256-TchWAGSvhTIfj7Zei5Hgw5CpxYg73QKoXBIy6qPQUes=",
      "url": "bootstrap-icons/icons/dice-5.svg"
    },
    {
      "hash": "sha256-JIWoxonHbCisrSpN0qJy+N61YYew2G1g4lvSQzgp8Fk=",
      "url": "bootstrap-icons/icons/dice-6-fill.svg"
    },
    {
      "hash": "sha256-6dXXZ2YrPoF7dRmRZnPGJbHXbL5YjZ2V+/YpAlsMigA=",
      "url": "bootstrap-icons/icons/dice-6.svg"
    },
    {
      "hash": "sha256-sziyD6YtfpXEpVF+NGwamB9/D22b8F8bX9QPWrrTAfQ=",
      "url": "bootstrap-icons/icons/disc-fill.svg"
    },
    {
      "hash": "sha256-dYHUIns0yCJ68LHh2w3WpYFkd3quOSjCwp/Nd5oQDH8=",
      "url": "bootstrap-icons/icons/disc.svg"
    },
    {
      "hash": "sha256-EOSQK5b9IoblQKtglbHWPMgKz/i1tCQAwfU9LN9Rg9k=",
      "url": "bootstrap-icons/icons/discord.svg"
    },
    {
      "hash": "sha256-miFgqp1NX/4FigkWWWi2mZK4MZt6gzzIYWmsMGoTaFY=",
      "url": "bootstrap-icons/icons/display-fill.svg"
    },
    {
      "hash": "sha256-Kfy9uKumMnQ5zdL37NywuDH4HYDQn3vfM6kEOAwOL0Q=",
      "url": "bootstrap-icons/icons/display.svg"
    },
    {
      "hash": "sha256-exVVhNwt9dpWhA+c7D3A0VVl6l1IiDW6ZRsW+GZiZxE=",
      "url": "bootstrap-icons/icons/displayport-fill.svg"
    },
    {
      "hash": "sha256-ANn6HzJqS/NQQ8h7Nny8FYpK2zhCz194yruizl/lT94=",
      "url": "bootstrap-icons/icons/displayport.svg"
    },
    {
      "hash": "sha256-GRGgki0KIhVgc5yd8DI/87E/GH5DqtoHOYi4kLwUKKM=",
      "url": "bootstrap-icons/icons/distribute-horizontal.svg"
    },
    {
      "hash": "sha256-rob4z7VoO7tzfwGfOkiWM4G7bCvh727rfuiSczAtkhA=",
      "url": "bootstrap-icons/icons/distribute-vertical.svg"
    },
    {
      "hash": "sha256-suRw0gktYkcbjLqa6McRJKAY5pOZwWkYw9K8wfcJmt8=",
      "url": "bootstrap-icons/icons/door-closed-fill.svg"
    },
    {
      "hash": "sha256-NKbez55meKTrs/2cl5yce8tKY1sSK3GNUKxj6RxpIjA=",
      "url": "bootstrap-icons/icons/door-closed.svg"
    },
    {
      "hash": "sha256-X+IOwObMObXquH7fhOI4ttjTT2b2ZGmMgqSeHluDYTM=",
      "url": "bootstrap-icons/icons/door-open-fill.svg"
    },
    {
      "hash": "sha256-bhj2/q6hZXwaBajfm60UCwMBqKy5l7yLIiWcvCetsUc=",
      "url": "bootstrap-icons/icons/door-open.svg"
    },
    {
      "hash": "sha256-rltHMWvPEOyp76XQZcTDESAUU2ul+i7V1+J7OcHK0e0=",
      "url": "bootstrap-icons/icons/dot.svg"
    },
    {
      "hash": "sha256-74J4KDU1HEPw5BAliIsARZJop2cRPTNSTU+Pv+gAjBY=",
      "url": "bootstrap-icons/icons/download.svg"
    },
    {
      "hash": "sha256-TiWTOx8S3p9zvyjLgh/1t/lsfxPPM/KOnsp/2DdnyXI=",
      "url": "bootstrap-icons/icons/dpad-fill.svg"
    },
    {
      "hash": "sha256-bddaVE5gkps+FTgm3MTsR3FUCRnE/BOytrMBD0WDlCU=",
      "url": "bootstrap-icons/icons/dpad.svg"
    },
    {
      "hash": "sha256-2fN976iJLyFFIIOdTQg5cpP/REmsvdEJTpW8PlG3X9g=",
      "url": "bootstrap-icons/icons/dribbble.svg"
    },
    {
      "hash": "sha256-A5i6e1e/CuneZALga9p/x+BG/k8iQj4J33NSx+E1Xxc=",
      "url": "bootstrap-icons/icons/dropbox.svg"
    },
    {
      "hash": "sha256-Bw4vjFG9GZfHe31rVYYyq+nl1LGnogGHXRN6QdHLtE4=",
      "url": "bootstrap-icons/icons/droplet-fill.svg"
    },
    {
      "hash": "sha256-Nq086vx7PEll9Esqeo79Wv8A4Xh62x6eW/UP+gfWRU0=",
      "url": "bootstrap-icons/icons/droplet-half.svg"
    },
    {
      "hash": "sha256-ur4015tt8D5jy9XPYWSXlHNobyHGWlh+nODd5gRUzPI=",
      "url": "bootstrap-icons/icons/droplet.svg"
    },
    {
      "hash": "sha256-aT9/s0c4i+kEkYS437JxiDLDkGrgpujsBKBEPcUlfNQ=",
      "url": "bootstrap-icons/icons/duffle-fill.svg"
    },
    {
      "hash": "sha256-rE1MSwsfjBIAu1R2TVMlTMRzdcxRUkOguHmKJ1jLBOs=",
      "url": "bootstrap-icons/icons/duffle.svg"
    },
    {
      "hash": "sha256-hcE5DaWHmJ/J8CGbhkkTExZT7OraOrrzyRgOAuH1lbI=",
      "url": "bootstrap-icons/icons/ear-fill.svg"
    },
    {
      "hash": "sha256-GFiwHeG/xl39H/QDjcdJ/1phlHFFaVkQdM0Zocpb4Ok=",
      "url": "bootstrap-icons/icons/ear.svg"
    },
    {
      "hash": "sha256-DgScMBotVrxizKtVHIFkYRUo5H3F6IIpiOsj0bT+CaM=",
      "url": "bootstrap-icons/icons/earbuds.svg"
    },
    {
      "hash": "sha256-bu0/k0hjwH+d4jyXIthKg0mgAdT/K4vn6P7UJyqNBeY=",
      "url": "bootstrap-icons/icons/easel-fill.svg"
    },
    {
      "hash": "sha256-4OHz+uIHpYi5lVcpvB5lBk3QBvsPWxcr/If9JfFCkS8=",
      "url": "bootstrap-icons/icons/easel.svg"
    },
    {
      "hash": "sha256-TKv6SKH24fHoPJntLCOhFGQliYFIM5lchSmCQ87+/Rw=",
      "url": "bootstrap-icons/icons/easel2-fill.svg"
    },
    {
      "hash": "sha256-iPpNlV89Se4TXmw8Z7YDYEXSXbwBM0S3IEQDoos7HCQ=",
      "url": "bootstrap-icons/icons/easel2.svg"
    },
    {
      "hash": "sha256-+IYdu+dV6rg5/LlhXHmsvV8UZDIuocZnocLXdUsJDlI=",
      "url": "bootstrap-icons/icons/easel3-fill.svg"
    },
    {
      "hash": "sha256-nFtDzQLXB8Nj5LAbteefLxk8VPDuV9sr/ZTV9RvHHkY=",
      "url": "bootstrap-icons/icons/easel3.svg"
    },
    {
      "hash": "sha256-GF8XG4Ik4DqZb1SZoxP2LrMhCYwHNaTKbWqhGmIOr5c=",
      "url": "bootstrap-icons/icons/egg-fill.svg"
    },
    {
      "hash": "sha256-x72wBPA+EICMv1IL5jkkr8b9U0tBjKPQ9fhBzno2Y3E=",
      "url": "bootstrap-icons/icons/egg-fried.svg"
    },
    {
      "hash": "sha256-0ehfvs3TxOUJsq2pHRto3ibnE332vfGfRMCU/k4br50=",
      "url": "bootstrap-icons/icons/egg.svg"
    },
    {
      "hash": "sha256-xZBtBsHNMe6QP24CEm7Q2KP7vhpgEnlRVsiM2gkVN/k=",
      "url": "bootstrap-icons/icons/eject-fill.svg"
    },
    {
      "hash": "sha256-43bKDXz7L78m74Hr2RKcf8OxwqTtQVpuSlagoOxm9NQ=",
      "url": "bootstrap-icons/icons/eject.svg"
    },
    {
      "hash": "sha256-yuL94OC9eaZgwIU5tjVlppQbQok7Bz+q4yoMASCo5gU=",
      "url": "bootstrap-icons/icons/emoji-angry-fill.svg"
    },
    {
      "hash": "sha256-AIwWoyp0R4h+8bWwBELr/CpVDxiknPnPOx1XLdtKAho=",
      "url": "bootstrap-icons/icons/emoji-angry.svg"
    },
    {
      "hash": "sha256-/Lc7he2J2LzWEz4KOHVpWgvMn2FQugUvJI3Jia88n5o=",
      "url": "bootstrap-icons/icons/emoji-astonished-fill.svg"
    },
    {
      "hash": "sha256-6fne3NCw6fz2mGzDBS1LN6SSLLrVIVRlkJJWm0jC09U=",
      "url": "bootstrap-icons/icons/emoji-astonished.svg"
    },
    {
      "hash": "sha256-qHpo+8jqG2wN/yk/K4VbptBGlgHMNptsJzjfGswmoPY=",
      "url": "bootstrap-icons/icons/emoji-dizzy-fill.svg"
    },
    {
      "hash": "sha256-zLHj4Rp9Oi+3Xb4da33OY946Ox9LwOdS3zQcwakIBzE=",
      "url": "bootstrap-icons/icons/emoji-dizzy.svg"
    },
    {
      "hash": "sha256-BGGHCKntq4Uhb3oMg3l1z67FTNgQ0/fhulNAfoy3L7Y=",
      "url": "bootstrap-icons/icons/emoji-expressionless-fill.svg"
    },
    {
      "hash": "sha256-G+vgEm3WPuviIKG0+HFCqtI/q3JCk4iueDs+1NiN1u0=",
      "url": "bootstrap-icons/icons/emoji-expressionless.svg"
    },
    {
      "hash": "sha256-ebF1iAL631OLE9sGDLo3CjKvgB9LK3S4FkkOfwl8CN0=",
      "url": "bootstrap-icons/icons/emoji-frown-fill.svg"
    },
    {
      "hash": "sha256-0taKNFVO7Gfhy839IYowz7S+sxkYXC/RYifkHDRfmrY=",
      "url": "bootstrap-icons/icons/emoji-frown.svg"
    },
    {
      "hash": "sha256-wsW54fuNDjMNQXcu90IzJF0OCLA0mov+uppRHctSv4s=",
      "url": "bootstrap-icons/icons/emoji-grimace-fill.svg"
    },
    {
      "hash": "sha256-Kas7KwqI7NlwDQGOdM1Z1fKjju6yZYGR+5lHIo7YUD8=",
      "url": "bootstrap-icons/icons/emoji-grimace.svg"
    },
    {
      "hash": "sha256-CGVlv4iUGj7qvEMyF2JRR1jFT8rmQioa7E5TZ5BpqKM=",
      "url": "bootstrap-icons/icons/emoji-grin-fill.svg"
    },
    {
      "hash": "sha256-qnZjKvj5xAFjZFKcrnstaCk3FwOsGCa8bzUydvbyKPk=",
      "url": "bootstrap-icons/icons/emoji-grin.svg"
    },
    {
      "hash": "sha256-mwftIfmB30CtygeRj+6K3UgweczzyEQKadoCL4dvzRw=",
      "url": "bootstrap-icons/icons/emoji-heart-eyes-fill.svg"
    },
    {
      "hash": "sha256-U3voXEOtKZUbZMJTMJ4BHaPcu1Mw07vuH05qIAPIvyY=",
      "url": "bootstrap-icons/icons/emoji-heart-eyes.svg"
    },
    {
      "hash": "sha256-R7icNN81D84GH7Qir4AlIj5oKuanpusAdCkyP8sUOOg=",
      "url": "bootstrap-icons/icons/emoji-kiss-fill.svg"
    },
    {
      "hash": "sha256-xgtmwYBvULDDg3hzJ/DrM7MuHUrh3LImtUKs//PzYrs=",
      "url": "bootstrap-icons/icons/emoji-kiss.svg"
    },
    {
      "hash": "sha256-aYVwW79iPcaWMsh2RhkI7QCLbtmYG5hiLlsDsffH/Tg=",
      "url": "bootstrap-icons/icons/emoji-laughing-fill.svg"
    },
    {
      "hash": "sha256-DdLAebTxfU/HitrhZeOuVg2gaQn2ECOvaCRodPwtXJE=",
      "url": "bootstrap-icons/icons/emoji-laughing.svg"
    },
    {
      "hash": "sha256-06lficYj0CTSKEWKLF1bDUCosR4P15pqgFFJ3yikQKc=",
      "url": "bootstrap-icons/icons/emoji-neutral-fill.svg"
    },
    {
      "hash": "sha256-1pUU699FYxQITREqr4oquZXV871uczuIr9Tw8gV47ZA=",
      "url": "bootstrap-icons/icons/emoji-neutral.svg"
    },
    {
      "hash": "sha256-4QXLH2N03KROUqKdktg6W+zOjSrYkGUUrJqvNjqsZ40=",
      "url": "bootstrap-icons/icons/emoji-smile-fill.svg"
    },
    {
      "hash": "sha256-SNKTHiLaOGelCzTFKxn5GgZwcrYgfM+jzlo0OUL/ME8=",
      "url": "bootstrap-icons/icons/emoji-smile-upside-down-fill.svg"
    },
    {
      "hash": "sha256-IIrQApYbhbLNVvVdFDPZOcyj+HowqzR3bZldDfOHntY=",
      "url": "bootstrap-icons/icons/emoji-smile-upside-down.svg"
    },
    {
      "hash": "sha256-tD+/3f7/iHJlgVQYCV3Q2eag5UkU4ffF3Y3PfRtHV9E=",
      "url": "bootstrap-icons/icons/emoji-smile.svg"
    },
    {
      "hash": "sha256-CXtTb24CV8Qk4jkFWs0bDnnQaQZHyuqgex3QHQMDsWE=",
      "url": "bootstrap-icons/icons/emoji-sunglasses-fill.svg"
    },
    {
      "hash": "sha256-RyvQ/khbd/oPNdbEDLhHOIv/jQdzBbYuidZ4oNH7Pew=",
      "url": "bootstrap-icons/icons/emoji-sunglasses.svg"
    },
    {
      "hash": "sha256-HzEUBGG6gCPJ7jXLXyb4IJYw2UK3WP8FcGMHbuAyjJ8=",
      "url": "bootstrap-icons/icons/emoji-surprise-fill.svg"
    },
    {
      "hash": "sha256-9bHtPpuJ45bI0/oWhZv1zR0AQylQz8Cxflg+KOYyWoM=",
      "url": "bootstrap-icons/icons/emoji-surprise.svg"
    },
    {
      "hash": "sha256-Lmkz0Fs+UNP4BFUgSCIKnbvN05+EJr3TrUiRTKaJUqU=",
      "url": "bootstrap-icons/icons/emoji-tear-fill.svg"
    },
    {
      "hash": "sha256-kGXQbeKfGC3+0l2KZkG7BccKDdWoV4t84AWcxN1metQ=",
      "url": "bootstrap-icons/icons/emoji-tear.svg"
    },
    {
      "hash": "sha256-9k0uW2srJP/TNuub19+PQsXKoQnjTPWYy7dwReTTiiM=",
      "url": "bootstrap-icons/icons/emoji-wink-fill.svg"
    },
    {
      "hash": "sha256-AJOsMpAu0YQCMouaXW1jb4KSPgAelM9eGPhgM+v4sS4=",
      "url": "bootstrap-icons/icons/emoji-wink.svg"
    },
    {
      "hash": "sha256-1qyfE0HFd3wbEGpodrJqMMqwKbnf23T/dNcbYa94gxg=",
      "url": "bootstrap-icons/icons/envelope-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-zCfI0Un3f+pYBX1FN/B4wQy4LSixCTx1M8uWGzUq9VI=",
      "url": "bootstrap-icons/icons/envelope-arrow-down.svg"
    },
    {
      "hash": "sha256-uf15k0/Gs/DkpJNhwpsIdtdgr5YO2hSLrrl/u5Jn/1w=",
      "url": "bootstrap-icons/icons/envelope-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-HjsV9SqxOW53/xWDeA9/deMd9HZ65TLaHNQyaKRUims=",
      "url": "bootstrap-icons/icons/envelope-arrow-up.svg"
    },
    {
      "hash": "sha256-9dFHlukrPGUnJ0ysQL73tGEjFaItUKJyn9zxMAPngm8=",
      "url": "bootstrap-icons/icons/envelope-at-fill.svg"
    },
    {
      "hash": "sha256-EgTiThm8MEum3b6b/foPU6u6QBaERHVIOQL4SAO4Npo=",
      "url": "bootstrap-icons/icons/envelope-at.svg"
    },
    {
      "hash": "sha256-CxbyIdfxJQBzIzDYlofZfTAjaiLcCikMCRS4I9mce3g=",
      "url": "bootstrap-icons/icons/envelope-check-fill.svg"
    },
    {
      "hash": "sha256-jJ/ATk+r7PJpunzzHsKwbTihnRt1dgD3uo47jA0Jw6k=",
      "url": "bootstrap-icons/icons/envelope-check.svg"
    },
    {
      "hash": "sha256-yvGO+cquu03f/4YHdg2+RkU0za8E1EOL3w6ECHYJcrI=",
      "url": "bootstrap-icons/icons/envelope-dash-fill.svg"
    },
    {
      "hash": "sha256-pBKQkS/yz71Lc2Ow2eIaLoHV+FuW+ua3GRHmh1t7iSs=",
      "url": "bootstrap-icons/icons/envelope-dash.svg"
    },
    {
      "hash": "sha256-IIxJokz6Dw2lblkQcuIsN7VH5nwHt0fbQFFHmqk09II=",
      "url": "bootstrap-icons/icons/envelope-exclamation-fill.svg"
    },
    {
      "hash": "sha256-5MkWysM2qeeqpL9DJBoi3gAUMdAhQwROLF/2/b55uqk=",
      "url": "bootstrap-icons/icons/envelope-exclamation.svg"
    },
    {
      "hash": "sha256-/ZXKd1Nawlnr6oL8hXBWlg6LzpuZu4ocD+Q+SDt/MPU=",
      "url": "bootstrap-icons/icons/envelope-fill.svg"
    },
    {
      "hash": "sha256-t7l+4jBtBbVXlgGtFzhS4ke+w+OzXjsQmBPbtc/S8Tc=",
      "url": "bootstrap-icons/icons/envelope-heart-fill.svg"
    },
    {
      "hash": "sha256-ZJkS+W2QuXvpKvs+eK5z19aT0fihtlhdjPOujnolYbI=",
      "url": "bootstrap-icons/icons/envelope-heart.svg"
    },
    {
      "hash": "sha256-1wX3EjprjqtM1fsi0QGCP23xTlx/bxUZWSYIRrGKtP0=",
      "url": "bootstrap-icons/icons/envelope-open-fill.svg"
    },
    {
      "hash": "sha256-A/zXHBBdwMW9qTEynMvwb7mctDJtpYiP/+tV2FnQc2M=",
      "url": "bootstrap-icons/icons/envelope-open-heart-fill.svg"
    },
    {
      "hash": "sha256-mJHZYrsl2ebO6HMykd16BBQdRHnkLcKQ/VuG9+IK7xY=",
      "url": "bootstrap-icons/icons/envelope-open-heart.svg"
    },
    {
      "hash": "sha256-XsZSqcpK/0F5uc8g6BhvKBYri7wQX7gD/OaZCezVGKo=",
      "url": "bootstrap-icons/icons/envelope-open.svg"
    },
    {
      "hash": "sha256-eLFAeM2YCe+EDiOA66P2R9LT6hVYp5VqBhqCqnIsIGA=",
      "url": "bootstrap-icons/icons/envelope-paper-fill.svg"
    },
    {
      "hash": "sha256-5X94/rdl+t3WalT/3E/K2/kPfTbde9sFewJw/d37m4s=",
      "url": "bootstrap-icons/icons/envelope-paper-heart-fill.svg"
    },
    {
      "hash": "sha256-57Tu7yMW8Qrnw80byugWDO/68CHQf3selYQYJEn+JqE=",
      "url": "bootstrap-icons/icons/envelope-paper-heart.svg"
    },
    {
      "hash": "sha256-RV0QN0rkMJvdNqj6HLx+uFQcYk28StIGyk84w45LWHo=",
      "url": "bootstrap-icons/icons/envelope-paper.svg"
    },
    {
      "hash": "sha256-BK38xme/3Yr7pVJbd3KzNnU+zSdgFcX4ocOIG3WO5ns=",
      "url": "bootstrap-icons/icons/envelope-plus-fill.svg"
    },
    {
      "hash": "sha256-AIbiOxg1jWJ4mgqRa2PaEPDOGyELDxEVv6ddBVvtns4=",
      "url": "bootstrap-icons/icons/envelope-plus.svg"
    },
    {
      "hash": "sha256-2JAgt0yIsLtBXijnWC2Av6NtzUBSa4PRXeLdUceaXus=",
      "url": "bootstrap-icons/icons/envelope-slash-fill.svg"
    },
    {
      "hash": "sha256-A9EYmCtYQIsArUzWtj2O1eVj/AYJsMCyce3XU3qdFQg=",
      "url": "bootstrap-icons/icons/envelope-slash.svg"
    },
    {
      "hash": "sha256-cG/Ukpp09iFXIRGBXVwqcHqBKIi+4vFEmOtAhdmOC/M=",
      "url": "bootstrap-icons/icons/envelope-x-fill.svg"
    },
    {
      "hash": "sha256-sYqGADhFqxeKoC8LE60eW8fnt5RcaX9icZZ1eGhAtaA=",
      "url": "bootstrap-icons/icons/envelope-x.svg"
    },
    {
      "hash": "sha256-RjVO3jTmrP/ZgoN3iEAHrjCQ2zuJLktKj7juw+EBfWM=",
      "url": "bootstrap-icons/icons/envelope.svg"
    },
    {
      "hash": "sha256-qMXn/F4LZrN8pMc/ardv/MuDpkSMaevOvzJg44NjXbc=",
      "url": "bootstrap-icons/icons/eraser-fill.svg"
    },
    {
      "hash": "sha256-RfZ/rFNrcCgrkO2UGwunv1tx7mvMHVS8pdX/td8wcUU=",
      "url": "bootstrap-icons/icons/eraser.svg"
    },
    {
      "hash": "sha256-CGO1NWrNzCOq7RFHfr/O0b981hGWejTaf1RJJ89zbo8=",
      "url": "bootstrap-icons/icons/escape.svg"
    },
    {
      "hash": "sha256-A9s+09Wgfq1u+J1ryOGThrMbF5fHuk2kaK/s/PiwvZE=",
      "url": "bootstrap-icons/icons/ethernet.svg"
    },
    {
      "hash": "sha256-XpUEGvWV4tOC2jhkzxGNioMuoYtvxgnbMYlLrDarqMQ=",
      "url": "bootstrap-icons/icons/ev-front-fill.svg"
    },
    {
      "hash": "sha256-0cQh2fBZnGO7A8JXSVtu7McfdbQB9fL9V5cueiapfJQ=",
      "url": "bootstrap-icons/icons/ev-front.svg"
    },
    {
      "hash": "sha256-hGRSYAbKvRp7Nk1sXNbtOeTj9VBjW6zsszPA+sTUAF4=",
      "url": "bootstrap-icons/icons/ev-station-fill.svg"
    },
    {
      "hash": "sha256-pyI6qHR8tM5U0w6HLr7QWxNy5sW9s0wdcs8QwVtCjLE=",
      "url": "bootstrap-icons/icons/ev-station.svg"
    },
    {
      "hash": "sha256-7QVm7lB7lA4zzseMNFFd+2ofDjiclEU1XbryLlRHb5A=",
      "url": "bootstrap-icons/icons/exclamation-circle-fill.svg"
    },
    {
      "hash": "sha256-vp0jT1Ai4YMveY9rc4dtnjrN9OBob2Rn/hBPwV2IOB8=",
      "url": "bootstrap-icons/icons/exclamation-circle.svg"
    },
    {
      "hash": "sha256-nl1YXpLHukMDkTyOvKPg7GKI3IGmz4kf6yXvEusjLWE=",
      "url": "bootstrap-icons/icons/exclamation-diamond-fill.svg"
    },
    {
      "hash": "sha256-QHi0+rHB5aJUb3O7ct8nloxvm4HjVo9X6gD9GaP7E9Y=",
      "url": "bootstrap-icons/icons/exclamation-diamond.svg"
    },
    {
      "hash": "sha256-ih4HqR+Z8VkrKY/6AG36QjY+t9inJ1znOhbxsoVDCng=",
      "url": "bootstrap-icons/icons/exclamation-lg.svg"
    },
    {
      "hash": "sha256-Jc+wBSOfbgAfOiB9F5kJr4AJs9XZlb0/l2KJYmFBYZA=",
      "url": "bootstrap-icons/icons/exclamation-octagon-fill.svg"
    },
    {
      "hash": "sha256-cXG57zgFlHjMNjdrUUQvjH3QLfwfb6ryO+PWX9cT4f0=",
      "url": "bootstrap-icons/icons/exclamation-octagon.svg"
    },
    {
      "hash": "sha256-aak4LibTMx9fMeH6oFG2S/ZBwA/C4Uv15E2wdUpr+Sg=",
      "url": "bootstrap-icons/icons/exclamation-square-fill.svg"
    },
    {
      "hash": "sha256-BNq3iaB1mwk0g1YYhEbZewzOkcUlsO24WaXQuJagHZg=",
      "url": "bootstrap-icons/icons/exclamation-square.svg"
    },
    {
      "hash": "sha256-NneunB+OL8PZX3E4S/QX2dw695AH42Pz4MzvIhj/8pA=",
      "url": "bootstrap-icons/icons/exclamation-triangle-fill.svg"
    },
    {
      "hash": "sha256-rPL4OAgTG5JjLm1XqtOcAs1uOt5U/P3q00bcevIqakc=",
      "url": "bootstrap-icons/icons/exclamation-triangle.svg"
    },
    {
      "hash": "sha256-ec8oa45AwufeQl5rdRFhahTtlg5A5qtlM5EQzOOlfbg=",
      "url": "bootstrap-icons/icons/exclamation.svg"
    },
    {
      "hash": "sha256-Uo7lJ4xl9887S5fpnAOzPKesh5RnE/fBP7Qhk9zo4Z4=",
      "url": "bootstrap-icons/icons/exclude.svg"
    },
    {
      "hash": "sha256-zZItmZUv/QC74D02kA83SW0BKv96RGj5NZFVYGY3jrA=",
      "url": "bootstrap-icons/icons/explicit-fill.svg"
    },
    {
      "hash": "sha256-OOGtnKu46ageEygtLQ51gcFvXWcSWSu2SKCnuy9QAMk=",
      "url": "bootstrap-icons/icons/explicit.svg"
    },
    {
      "hash": "sha256-eZP0BfDKpMvUcQB1itQzmlLWOBPROABbIxu9uLDJuPc=",
      "url": "bootstrap-icons/icons/exposure.svg"
    },
    {
      "hash": "sha256-TOD/cRQsERAppUETC7276I06G+IuRgLqx6sHv5nw108=",
      "url": "bootstrap-icons/icons/eye-fill.svg"
    },
    {
      "hash": "sha256-vAsRWb9MOND3ZxFLSNofitTyqYtB+eEgd0GJV9Js/98=",
      "url": "bootstrap-icons/icons/eye-slash-fill.svg"
    },
    {
      "hash": "sha256-41OU1dJ0J3M/s2UIiOwCnd1rhV7XfgNoAz3YZE2mOkI=",
      "url": "bootstrap-icons/icons/eye-slash.svg"
    },
    {
      "hash": "sha256-Lz85DRuzibdT+Rg8+sZT4zWPm0oRMTrg3+loqRf4K+I=",
      "url": "bootstrap-icons/icons/eye.svg"
    },
    {
      "hash": "sha256-1kue9uWLeK2/B7Hn0P4oNnYJ4EjlN5xHyts85rEkWDw=",
      "url": "bootstrap-icons/icons/eyedropper.svg"
    },
    {
      "hash": "sha256-O/fXwiD3XAfhM9B4ABOnkWzDhBr7AZ/esV7StCyt/qk=",
      "url": "bootstrap-icons/icons/eyeglasses.svg"
    },
    {
      "hash": "sha256-/M79284kt6zvlvzbdaqbw33B1ucl76izLsprYZ/xU/8=",
      "url": "bootstrap-icons/icons/facebook.svg"
    },
    {
      "hash": "sha256-Zxh2l0Ot2oI1iqKynGcpCRpEojIqIfrG74DrY5MB7yw=",
      "url": "bootstrap-icons/icons/fan.svg"
    },
    {
      "hash": "sha256-R4IPfROe+MkIGJlvjIIvGh6jXkH6aPYNczKmm7HZ72s=",
      "url": "bootstrap-icons/icons/fast-forward-btn-fill.svg"
    },
    {
      "hash": "sha256-rHUbbTbsvSTBAr/B7ipK4lq2FQko1jc+8PNrCc19RoA=",
      "url": "bootstrap-icons/icons/fast-forward-btn.svg"
    },
    {
      "hash": "sha256-HFGoi6pQiOL6kAgNENJnh8npopSwhXSkS4u9UpoiT/A=",
      "url": "bootstrap-icons/icons/fast-forward-circle-fill.svg"
    },
    {
      "hash": "sha256-vW7zCXZ4T7F0ATfOWywkP2i13peDFgqCM2VnpxvwExo=",
      "url": "bootstrap-icons/icons/fast-forward-circle.svg"
    },
    {
      "hash": "sha256-1Xp+B+ZPB8CVQeKZrTaLCvbrs9GjaAcGqo8H+8Ah3k8=",
      "url": "bootstrap-icons/icons/fast-forward-fill.svg"
    },
    {
      "hash": "sha256-8bxHUZpnL5twmPvgBXtWQdiPQ+BSzVuXX3lO8iN6GEA=",
      "url": "bootstrap-icons/icons/fast-forward.svg"
    },
    {
      "hash": "sha256-35A7danKAveH9TGZQgmbyKfV5AHw/9/bDRnyhOvud9c=",
      "url": "bootstrap-icons/icons/feather.svg"
    },
    {
      "hash": "sha256-8A18S/Fft8pcT9J7bRJs6Xzzc/YYGvD0XN6elQKjUxw=",
      "url": "bootstrap-icons/icons/feather2.svg"
    },
    {
      "hash": "sha256-jI9UBTgYMnrHt+ppI2U09H0yFK7hkjBa6H4hkP/3YXk=",
      "url": "bootstrap-icons/icons/file-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-lDlV92QygPTPFkqlJKgTXYQyKZGnWmnIQecTytNg5wg=",
      "url": "bootstrap-icons/icons/file-arrow-down.svg"
    },
    {
      "hash": "sha256-3nzBo3LkDxZ5AwnL2zPUlYZWbT+zQDv5ntf7J/PRqEU=",
      "url": "bootstrap-icons/icons/file-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-jofZvxBeoHiZyCF8JBUYEpiFaKPqq1BmcyFmer/sZ3w=",
      "url": "bootstrap-icons/icons/file-arrow-up.svg"
    },
    {
      "hash": "sha256-A8LldeWFX4NqByTyUMbGmoNdcccS9380CFAoVp5C86Y=",
      "url": "bootstrap-icons/icons/file-bar-graph-fill.svg"
    },
    {
      "hash": "sha256-fLXjBoMdKRC813kHAvWOzm06FfFxTNtut0pUbv1Gp+o=",
      "url": "bootstrap-icons/icons/file-bar-graph.svg"
    },
    {
      "hash": "sha256-K9GzCEnJgxvAhZ1MoATTS8R3EWJlAgbHsaXTgGD+/8E=",
      "url": "bootstrap-icons/icons/file-binary-fill.svg"
    },
    {
      "hash": "sha256-Q9YcyLMrpJMloJKWbvbpsUD3F7Fyv4t1PRxxuWA4/FY=",
      "url": "bootstrap-icons/icons/file-binary.svg"
    },
    {
      "hash": "sha256-bYtcI8FuYVZnzKs48DvNxBbNiWC5Slm1j8QGkh9JRo0=",
      "url": "bootstrap-icons/icons/file-break-fill.svg"
    },
    {
      "hash": "sha256-UP7YscK8JUmT0281zrmSrlt7QroRh/XQa0PFrLvNWFg=",
      "url": "bootstrap-icons/icons/file-break.svg"
    },
    {
      "hash": "sha256-F1RODq1ZzfJ7nzHAQ826mC0CtR59olRnbx0c6QStHE0=",
      "url": "bootstrap-icons/icons/file-check-fill.svg"
    },
    {
      "hash": "sha256-WKBurMIC3y3iaO+lfr0agFdFB5OymaPFxw8bmDJ9jYU=",
      "url": "bootstrap-icons/icons/file-check.svg"
    },
    {
      "hash": "sha256-HyJUw7X+A7vMUda/AYvQHNQXsd/5f5qwMK4gdoRrrF4=",
      "url": "bootstrap-icons/icons/file-code-fill.svg"
    },
    {
      "hash": "sha256-X1+5NDAaAzENXWLEOcIQSiynDj6xCDBNey4RQGLXycA=",
      "url": "bootstrap-icons/icons/file-code.svg"
    },
    {
      "hash": "sha256-yQk09os03QgbwLRusFH1CIwIs+ra5fkOibqjaapaMwQ=",
      "url": "bootstrap-icons/icons/file-diff-fill.svg"
    },
    {
      "hash": "sha256-U5gpeuuZnBk2xniU9LPO57SJvdfmV3qQ668rxgrOtT0=",
      "url": "bootstrap-icons/icons/file-diff.svg"
    },
    {
      "hash": "sha256-QmfodK2eLex5YthM7+s4yagJdarM/QuhlVfyyBjM5T8=",
      "url": "bootstrap-icons/icons/file-earmark-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-pvFQdzAlthb1nN7gQtI/Vi0prfzGVlDNuwQnVg+vT7o=",
      "url": "bootstrap-icons/icons/file-earmark-arrow-down.svg"
    },
    {
      "hash": "sha256-XPIPY3GewBV3ckZMQdRSOPYEpwvZoh4FHjhoNf2rTXs=",
      "url": "bootstrap-icons/icons/file-earmark-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-NWwoVopfYfzqayZNyl6Lzwxw0Y40svV30TrfYwYQRJw=",
      "url": "bootstrap-icons/icons/file-earmark-arrow-up.svg"
    },
    {
      "hash": "sha256-v7qr6Sztns7AW2tiCv6FsjwPqxmrJAz0ozbdQvfhZTI=",
      "url": "bootstrap-icons/icons/file-earmark-bar-graph-fill.svg"
    },
    {
      "hash": "sha256-O4tyK8MacF8/9QaOM3JXQbCMQm7L+LP0r/tD5Q1mqZs=",
      "url": "bootstrap-icons/icons/file-earmark-bar-graph.svg"
    },
    {
      "hash": "sha256-1eKf7URZwpM4DJ5NnDi6x9PPQ0GhrRB+YawPB+Ff16Q=",
      "url": "bootstrap-icons/icons/file-earmark-binary-fill.svg"
    },
    {
      "hash": "sha256-fAbYMIBvkS/mhw9xyMKi0K3GbDuuyuZOkxMwWKVOi+A=",
      "url": "bootstrap-icons/icons/file-earmark-binary.svg"
    },
    {
      "hash": "sha256-P4tNOzacRPeqMirk9pNqCX23SbGf+kQPQo9XGCfOZRo=",
      "url": "bootstrap-icons/icons/file-earmark-break-fill.svg"
    },
    {
      "hash": "sha256-9BVb9JasJeqkho/dnBaiYGYx7MEgSgfda0lXfFLNrvk=",
      "url": "bootstrap-icons/icons/file-earmark-break.svg"
    },
    {
      "hash": "sha256-TBVWL4xCDps8jK6dpZgYxgIjZr/B80K/fgjHycjIOeM=",
      "url": "bootstrap-icons/icons/file-earmark-check-fill.svg"
    },
    {
      "hash": "sha256-EDC4EVIcCEVbeO80Wvdb5Iop3rZ451gDlOT+V14Ak4A=",
      "url": "bootstrap-icons/icons/file-earmark-check.svg"
    },
    {
      "hash": "sha256-mA8dVwKZXP/+g+t06jhJmMNRBFBVOGT+9puOY3Lldq4=",
      "url": "bootstrap-icons/icons/file-earmark-code-fill.svg"
    },
    {
      "hash": "sha256-gLXUU7oscO1zOpmOCotGLrn/iVtI9UPdwYGUFRBrcZg=",
      "url": "bootstrap-icons/icons/file-earmark-code.svg"
    },
    {
      "hash": "sha256-j0CFkuPzisz7d8YX9ilQV+SyaUGof3egG6maXGtjO3Q=",
      "url": "bootstrap-icons/icons/file-earmark-diff-fill.svg"
    },
    {
      "hash": "sha256-1nsbMfikrzOYvy/H6NRKMON0QiG63bllfyqpq84PsnQ=",
      "url": "bootstrap-icons/icons/file-earmark-diff.svg"
    },
    {
      "hash": "sha256-GK6cRrRObZbW3rTX3+l5Kyffk69MWP56qOV7+/DT35A=",
      "url": "bootstrap-icons/icons/file-earmark-easel-fill.svg"
    },
    {
      "hash": "sha256-d1qmkLzvlNybtvbDEzAcokLHixupRA2MlgNDw5mz8yw=",
      "url": "bootstrap-icons/icons/file-earmark-easel.svg"
    },
    {
      "hash": "sha256-VOl5CR7JVd5Vsg7AIvvUKOAq0mZk7EtEuEk56gw0S30=",
      "url": "bootstrap-icons/icons/file-earmark-excel-fill.svg"
    },
    {
      "hash": "sha256-ljir2RUtUQ37cySUuwO6K/w3rCA2d7JepipeDr8L7pY=",
      "url": "bootstrap-icons/icons/file-earmark-excel.svg"
    },
    {
      "hash": "sha256-g6mcTs80avN0NvMRHRkOcirPv7T2Elfpgetbaxzu/CM=",
      "url": "bootstrap-icons/icons/file-earmark-fill.svg"
    },
    {
      "hash": "sha256-t6oEo+TfYcBNxNKMZEf9kvqyRq5BfT7eYbFcNM7ieRI=",
      "url": "bootstrap-icons/icons/file-earmark-font-fill.svg"
    },
    {
      "hash": "sha256-mJRg8ltw1pLYlPQByGg/Qu9/BvcViKxsrQE+zrJJ1Cw=",
      "url": "bootstrap-icons/icons/file-earmark-font.svg"
    },
    {
      "hash": "sha256-p8RpAdx8zwuxlEAxg071ECHrwDKwyVJGO5j1ZX18B+k=",
      "url": "bootstrap-icons/icons/file-earmark-image-fill.svg"
    },
    {
      "hash": "sha256-qylmdLPWlQzMa37JTLGOUIZ/Fne+umz/VfUjV12jp7U=",
      "url": "bootstrap-icons/icons/file-earmark-image.svg"
    },
    {
      "hash": "sha256-4vA4941LQOM+yejv/ByLgsgkdjYMd0mJMbAkWexku+0=",
      "url": "bootstrap-icons/icons/file-earmark-lock-fill.svg"
    },
    {
      "hash": "sha256-+ZAWzPeVD5Lrq5AZ6S0YzmgpQWuoeSO+bmQ7zeZDVNw=",
      "url": "bootstrap-icons/icons/file-earmark-lock.svg"
    },
    {
      "hash": "sha256-eL+uNlEs8lH4uvr5LR5wjxhv5duxY5EKlZpFWpka1UM=",
      "url": "bootstrap-icons/icons/file-earmark-lock2-fill.svg"
    },
    {
      "hash": "sha256-vqs6P29guvdK9Fp010TsA6sHcVPqvHudSWDf/r0eF9Y=",
      "url": "bootstrap-icons/icons/file-earmark-lock2.svg"
    },
    {
      "hash": "sha256-nuCjLdftP1g/CNWobXXLbVnxg/b3UlcCJv9lEEPhTTU=",
      "url": "bootstrap-icons/icons/file-earmark-medical-fill.svg"
    },
    {
      "hash": "sha256-w0uh0/mXhBou2KQSYDBShFDe0OomOkDRPfx3fFRBvO4=",
      "url": "bootstrap-icons/icons/file-earmark-medical.svg"
    },
    {
      "hash": "sha256-xxw73JIwqjbNvY0akP0pVLeWKjKHef1w+ty2BbhcoXo=",
      "url": "bootstrap-icons/icons/file-earmark-minus-fill.svg"
    },
    {
      "hash": "sha256-HFyzp6LyOy8NkU07SEuiuab/xKDDY/yaYvMerZs4JDA=",
      "url": "bootstrap-icons/icons/file-earmark-minus.svg"
    },
    {
      "hash": "sha256-o+TzL+7caR+T65YEaBWqkmED9c7SCYUSbP3mpQeJXPo=",
      "url": "bootstrap-icons/icons/file-earmark-music-fill.svg"
    },
    {
      "hash": "sha256-bNzjDUH6OzKBTXa0woZx/7xYHe9ccQZpsphrQRUZCFg=",
      "url": "bootstrap-icons/icons/file-earmark-music.svg"
    },
    {
      "hash": "sha256-xRG4ndeN9drwfa6su2lfVrzoRwFHMyyyfT/4YxvbVnI=",
      "url": "bootstrap-icons/icons/file-earmark-pdf-fill.svg"
    },
    {
      "hash": "sha256-z6qFNqpWqD3OiWTtzowrG3+fZG+h54avLPjxtNiFoKY=",
      "url": "bootstrap-icons/icons/file-earmark-pdf.svg"
    },
    {
      "hash": "sha256-klBRhRDUQ+rmBCkqIPYCmDBStzyy/5I96kq6dh3DxOI=",
      "url": "bootstrap-icons/icons/file-earmark-person-fill.svg"
    },
    {
      "hash": "sha256-yrZBuWM1aA9KFCyQ05QaSXunbjIOmlluZ1+Iu5Pou4s=",
      "url": "bootstrap-icons/icons/file-earmark-person.svg"
    },
    {
      "hash": "sha256-79AIXf79rFBnzPjIx4cViE+tASXoGuqyFAso8LToMak=",
      "url": "bootstrap-icons/icons/file-earmark-play-fill.svg"
    },
    {
      "hash": "sha256-V6gqWvDUTrxajeQJjY/Pnn1NirNCKos4rJ9MnZerOLU=",
      "url": "bootstrap-icons/icons/file-earmark-play.svg"
    },
    {
      "hash": "sha256-MCE+BFPbwsw49kql4YUQ8UrzoSt1+NnarcEC+LXz7Q8=",
      "url": "bootstrap-icons/icons/file-earmark-plus-fill.svg"
    },
    {
      "hash": "sha256-i7RXGhKeECEuF7fi91BtjE4772cG3lL4KZ+ok46Z/AA=",
      "url": "bootstrap-icons/icons/file-earmark-plus.svg"
    },
    {
      "hash": "sha256-JX2NRFl4zp7Xwfr+CJVNT6+nUX6C8Tahu3EY4TgfjGc=",
      "url": "bootstrap-icons/icons/file-earmark-post-fill.svg"
    },
    {
      "hash": "sha256-NZUC1KtwWmlvUtl+gLz4Fu6wZxnw7W/LSYRkbaUDWak=",
      "url": "bootstrap-icons/icons/file-earmark-post.svg"
    },
    {
      "hash": "sha256-K3gmsf5F3+JDP6B137e92CGbiAUVal8JQ4qsrT1/qKw=",
      "url": "bootstrap-icons/icons/file-earmark-ppt-fill.svg"
    },
    {
      "hash": "sha256-jbjFBkHQUj6hPqRuaHvZRYCghInkeXyAvjK0dLCx6vY=",
      "url": "bootstrap-icons/icons/file-earmark-ppt.svg"
    },
    {
      "hash": "sha256-ft6uMk8KueEXReyD2cZGC5FaY2lTQqmSNdtubGGKFnM=",
      "url": "bootstrap-icons/icons/file-earmark-richtext-fill.svg"
    },
    {
      "hash": "sha256-YhdTvwAkuiyoICbVYacwCmQ/Af/TfRLdeO1a9K9QPhQ=",
      "url": "bootstrap-icons/icons/file-earmark-richtext.svg"
    },
    {
      "hash": "sha256-wrmf7ZljifkKGXiYyNrYlfx9KhSWViYL8czgM11b2tg=",
      "url": "bootstrap-icons/icons/file-earmark-ruled-fill.svg"
    },
    {
      "hash": "sha256-yLmw0V/FQvOd7pCo2WCIBmTuEJL7hZU8Tu1CePo+ZKM=",
      "url": "bootstrap-icons/icons/file-earmark-ruled.svg"
    },
    {
      "hash": "sha256-ziRQAFwIrIryie7O25479Wl/Z47HDwme8G8LTUaYyRc=",
      "url": "bootstrap-icons/icons/file-earmark-slides-fill.svg"
    },
    {
      "hash": "sha256-rvnxeyIBQ32aUTPonpnZLk534+JFZXTSfHBXxBmEsHY=",
      "url": "bootstrap-icons/icons/file-earmark-slides.svg"
    },
    {
      "hash": "sha256-Z8IALkFv283X3im/fYj4WXIu+IZgdRSdNFDocQ20BLw=",
      "url": "bootstrap-icons/icons/file-earmark-spreadsheet-fill.svg"
    },
    {
      "hash": "sha256-l86a2SaUT7G83i9iNkpWr46slj99iumAjO5ZfcpKc5w=",
      "url": "bootstrap-icons/icons/file-earmark-spreadsheet.svg"
    },
    {
      "hash": "sha256-9GYGnwe7/w9g3w//K47gEdDiacLdzM9TxjbVX/22PPA=",
      "url": "bootstrap-icons/icons/file-earmark-text-fill.svg"
    },
    {
      "hash": "sha256-HGdFs8R4Kwr4UrSMitGAyfnGNZJtXEWNwzNom4w8SDE=",
      "url": "bootstrap-icons/icons/file-earmark-text.svg"
    },
    {
      "hash": "sha256-lD5gQU3dEWEAgjjAOQYTu0Uyq7r82BBE9uq8Dd69XpQ=",
      "url": "bootstrap-icons/icons/file-earmark-word-fill.svg"
    },
    {
      "hash": "sha256-Wze2noRdjJZdjlZUjRzw+8stab4hqT89RMu5ne0BpYQ=",
      "url": "bootstrap-icons/icons/file-earmark-word.svg"
    },
    {
      "hash": "sha256-EWH1iLExBLwjkazT05RdBbkQPCrPzvI5/TzfuPqk9xI=",
      "url": "bootstrap-icons/icons/file-earmark-x-fill.svg"
    },
    {
      "hash": "sha256-jzrEkMKBFFYCAbqk5Ifup7EQTxK3TRwQuplgZwnYEOE=",
      "url": "bootstrap-icons/icons/file-earmark-x.svg"
    },
    {
      "hash": "sha256-7glrPXZBl/SNQnfW8GDRn57xD7nPyYZj+vuhRhfmrDU=",
      "url": "bootstrap-icons/icons/file-earmark-zip-fill.svg"
    },
    {
      "hash": "sha256-6WVACJpkr4WKdEK4BwUKfzn3XeOQ/sK2zWv1Pzyy2Bk=",
      "url": "bootstrap-icons/icons/file-earmark-zip.svg"
    },
    {
      "hash": "sha256-AKopz2x+RyRaLRygbdqY2hCFg03GeABDkGdFtI49ASM=",
      "url": "bootstrap-icons/icons/file-earmark.svg"
    },
    {
      "hash": "sha256-WWkvA5un3S6vovcdSM6lMjbWVnHbVNB4rCkXqQLuLT4=",
      "url": "bootstrap-icons/icons/file-easel-fill.svg"
    },
    {
      "hash": "sha256-39J49ds6SVgoM63cZMGH2sQ6LFu/LD92Zzc2sK/e3sU=",
      "url": "bootstrap-icons/icons/file-easel.svg"
    },
    {
      "hash": "sha256-wtCL10CBWx9OXguOMaDXPfFLICc9oluka1KQHyusGN0=",
      "url": "bootstrap-icons/icons/file-excel-fill.svg"
    },
    {
      "hash": "sha256-M972DfwZNEGPIyCWeiMz74Jc0te1XIQQv7cZeyg3i+8=",
      "url": "bootstrap-icons/icons/file-excel.svg"
    },
    {
      "hash": "sha256-MW32k5/gQS0Sk+x+iLaAEc8eFDjhJ/rEpkmZujOMHjc=",
      "url": "bootstrap-icons/icons/file-fill.svg"
    },
    {
      "hash": "sha256-6v1bX1cYuFWRrNAAV5TB6LmZNO+Gx3ZPWCPekcCQLDw=",
      "url": "bootstrap-icons/icons/file-font-fill.svg"
    },
    {
      "hash": "sha256-mNaz4x1RNY7bgrttSNAEfs1HpHRgNh8yOWKC+MzwLjo=",
      "url": "bootstrap-icons/icons/file-font.svg"
    },
    {
      "hash": "sha256-AksFKaI83uFuIMo49qLsgajxwVDI8gWrjDei1lC5g68=",
      "url": "bootstrap-icons/icons/file-image-fill.svg"
    },
    {
      "hash": "sha256-0L6aC4mNXNhNi07vK3/A++/mSdClq8MeA+8NbUIhVLM=",
      "url": "bootstrap-icons/icons/file-image.svg"
    },
    {
      "hash": "sha256-06OQzQJ0uPm09T4x+7ynlp9zn658lUBVD+Uk/DAQgmc=",
      "url": "bootstrap-icons/icons/file-lock-fill.svg"
    },
    {
      "hash": "sha256-iAb1oRow6s1x1FLT41p3/MbKKMaIug5YurRTjCSk0Q4=",
      "url": "bootstrap-icons/icons/file-lock.svg"
    },
    {
      "hash": "sha256-sfWQjWpvkdehHzC7or+0g/dzhdrxoSJFhpgGFhRS8q8=",
      "url": "bootstrap-icons/icons/file-lock2-fill.svg"
    },
    {
      "hash": "sha256-Oakt/IT58A0TD2kFA7YKtMU8LaUlnUSf7XezLDW6+2Y=",
      "url": "bootstrap-icons/icons/file-lock2.svg"
    },
    {
      "hash": "sha256-aJkZSCZgoSobSumpSj/K6uWVY2edyZczTM8kJl5iEDs=",
      "url": "bootstrap-icons/icons/file-medical-fill.svg"
    },
    {
      "hash": "sha256-3muSjv10s50fIezyDfIQp7mpt9Au0JsGHnGlx6X5NPU=",
      "url": "bootstrap-icons/icons/file-medical.svg"
    },
    {
      "hash": "sha256-26KIQO6lA7zaPbZq8YOhYsb/ZKRqmZ8UMToYHbNnymc=",
      "url": "bootstrap-icons/icons/file-minus-fill.svg"
    },
    {
      "hash": "sha256-TchwXYxIIBLGswzqVN1dLJ8T/Bl+d6X3xctGAxPFnig=",
      "url": "bootstrap-icons/icons/file-minus.svg"
    },
    {
      "hash": "sha256-Byeq5cCppOTWbfEVTKh85DKS4ByFcs5ZBjLXuCX5KXU=",
      "url": "bootstrap-icons/icons/file-music-fill.svg"
    },
    {
      "hash": "sha256-+ueQnwpFz7s2zsAyAlXFxqPQnnzcev9wdtvrJ56DlHk=",
      "url": "bootstrap-icons/icons/file-music.svg"
    },
    {
      "hash": "sha256-t6hKdJs2r4Lau27ylsXw0KOPjeNEEm5/6zZc76DvXvE=",
      "url": "bootstrap-icons/icons/file-pdf-fill.svg"
    },
    {
      "hash": "sha256-eW70jJ5gwv0duXSpzSRC/8NtlQd5c/LVawy9OKYhSgs=",
      "url": "bootstrap-icons/icons/file-pdf.svg"
    },
    {
      "hash": "sha256-glkvJHw1T7RUbOBH2jLexUUn/cNBY78XryikkqwofW0=",
      "url": "bootstrap-icons/icons/file-person-fill.svg"
    },
    {
      "hash": "sha256-2En/jLc7MglY5Wi8vAO6i45ynmwzfzBj034aHTFCCAw=",
      "url": "bootstrap-icons/icons/file-person.svg"
    },
    {
      "hash": "sha256-tufmWUPwmZqQAw8lo3b+a58aZOju1p4pk18W3iuA15Q=",
      "url": "bootstrap-icons/icons/file-play-fill.svg"
    },
    {
      "hash": "sha256-JbTYyAR48ojH2sFpGpBL7lGnGYVFrrTvi25cw4n2Oio=",
      "url": "bootstrap-icons/icons/file-play.svg"
    },
    {
      "hash": "sha256-OxWBjQt/AyOz3ZcDioHGni/9cjPgc8/rBBnwrb/aQNU=",
      "url": "bootstrap-icons/icons/file-plus-fill.svg"
    },
    {
      "hash": "sha256-YsUCWGz/9mOL9c8esrZBG/fCJnxfbtG5O+fWX+wcR9k=",
      "url": "bootstrap-icons/icons/file-plus.svg"
    },
    {
      "hash": "sha256-62L9kFnmdHbGp0GfZXLZqI2s2MFz2p+yaqVXlcaTfqQ=",
      "url": "bootstrap-icons/icons/file-post-fill.svg"
    },
    {
      "hash": "sha256-rIJk8c2Qz6bZ3tjrr29t1JDBvc6au4W+MM1yZZlXTi8=",
      "url": "bootstrap-icons/icons/file-post.svg"
    },
    {
      "hash": "sha256-18/WO91xIct42VmUUrkIvSBdcuFW/E6KnBXhfBrx7Fc=",
      "url": "bootstrap-icons/icons/file-ppt-fill.svg"
    },
    {
      "hash": "sha256-3ENvy6LQmMfq88du8IWf8BqqOezrx/dVKlbX/xLidco=",
      "url": "bootstrap-icons/icons/file-ppt.svg"
    },
    {
      "hash": "sha256-x89JnZ7dIuMSUPK9z7NiG/KF6/4c27PNr/DtPL9Ha1E=",
      "url": "bootstrap-icons/icons/file-richtext-fill.svg"
    },
    {
      "hash": "sha256-0SINTrRAk3VvZJ2dIzH7fAEqFh1O45MDMV6KBm3fCqA=",
      "url": "bootstrap-icons/icons/file-richtext.svg"
    },
    {
      "hash": "sha256-CU00vhw85T4WC86sYVvoJbVUKDO8eHbIMEEPKMNkGFY=",
      "url": "bootstrap-icons/icons/file-ruled-fill.svg"
    },
    {
      "hash": "sha256-Z2pwlWq2Y3Oqvxkv9/jKoxyhCfGCmIkuLalc+ZHqq34=",
      "url": "bootstrap-icons/icons/file-ruled.svg"
    },
    {
      "hash": "sha256-ZJ4ZJzktRpdSFmdHrDESxD2P0nSflUOMTOkxCgJf47o=",
      "url": "bootstrap-icons/icons/file-slides-fill.svg"
    },
    {
      "hash": "sha256-wQifeMWPth59SXYq23eDrcwC4aH3Iw2HDIoAlAW+BSc=",
      "url": "bootstrap-icons/icons/file-slides.svg"
    },
    {
      "hash": "sha256-zy93GqpG8xfEWUbOWlfzpgykUfSfvS8usmuWyYbL5Wk=",
      "url": "bootstrap-icons/icons/file-spreadsheet-fill.svg"
    },
    {
      "hash": "sha256-k8Kw+K3EYuZiNhF5rbKFvxiqRoww1IG72gg6ZqbtYiM=",
      "url": "bootstrap-icons/icons/file-spreadsheet.svg"
    },
    {
      "hash": "sha256-7aHNfX7qyFWG0z1OJ+bZIgTpj4Og7YP6ntO2vj1f7KU=",
      "url": "bootstrap-icons/icons/file-text-fill.svg"
    },
    {
      "hash": "sha256-e86R5Q6pfpczb0f5XMmLA3MPa6jAgXk+M2TJfxSyQkk=",
      "url": "bootstrap-icons/icons/file-text.svg"
    },
    {
      "hash": "sha256-zoE5k0xh2LBT9kySTWU818GX/PraO47R7+g3qLFUzQY=",
      "url": "bootstrap-icons/icons/file-word-fill.svg"
    },
    {
      "hash": "sha256-cw2gZYFEivATCMAYhBVsBwrSOjIQS7ON8rLu+4HdqKw=",
      "url": "bootstrap-icons/icons/file-word.svg"
    },
    {
      "hash": "sha256-l/jQr2NFo92SeCqZvebFl7ymATuuJggT8Rtzf6/2rRA=",
      "url": "bootstrap-icons/icons/file-x-fill.svg"
    },
    {
      "hash": "sha256-bcAyiCpjUYexjDp7KIyKKbcgKfSBWQVVM4LcBRpENwc=",
      "url": "bootstrap-icons/icons/file-x.svg"
    },
    {
      "hash": "sha256-NdeJewoMRWJPcf3i6dZ6grCJlHF2Cns/6KrP/E4JF94=",
      "url": "bootstrap-icons/icons/file-zip-fill.svg"
    },
    {
      "hash": "sha256-MkzmUFHnUktF8dFm1ih1JIqSYXmyx8lHP9ujMXsEM5k=",
      "url": "bootstrap-icons/icons/file-zip.svg"
    },
    {
      "hash": "sha256-5uPafNK2PQl9CjAQmWrK8r0v2V/oJThHgkP8LOPxy5k=",
      "url": "bootstrap-icons/icons/file.svg"
    },
    {
      "hash": "sha256-Oih/rDRimVVTwv6+kmNk+fBze9DyTN59H62D4WNKsuY=",
      "url": "bootstrap-icons/icons/files-alt.svg"
    },
    {
      "hash": "sha256-1XuCww/qqnDrdAcy/ntr4z9JaQPo70kmfwM0TDv1DIk=",
      "url": "bootstrap-icons/icons/files.svg"
    },
    {
      "hash": "sha256-64XIAhZKt2yRxshUmw3CP397YqqUKHCMa1zWNwmCN3Y=",
      "url": "bootstrap-icons/icons/filetype-aac.svg"
    },
    {
      "hash": "sha256-/z6oVY4g1GhDt+D0/UzCYKtlKlQufXlzKSXH29g0upo=",
      "url": "bootstrap-icons/icons/filetype-ai.svg"
    },
    {
      "hash": "sha256-ETZbNyqw+d38IJNZFVl3eMyQ50/atMYwtQTWv4Aw3+c=",
      "url": "bootstrap-icons/icons/filetype-bmp.svg"
    },
    {
      "hash": "sha256-1L24ZqaMgksWnMzjoGY5x1M8kR9+MUIs9RrR/pqq8z8=",
      "url": "bootstrap-icons/icons/filetype-cs.svg"
    },
    {
      "hash": "sha256-fHE/DY7wGTAayxOblPD+xSPH/LDIdZo1eKCY4BFs0VI=",
      "url": "bootstrap-icons/icons/filetype-css.svg"
    },
    {
      "hash": "sha256-pYFkteuINeLcG+2h0gHg/uWRZBoLVqgN/pMjz9zCWgU=",
      "url": "bootstrap-icons/icons/filetype-csv.svg"
    },
    {
      "hash": "sha256-yqw0IQptirohAMEXi/r7G8FjXCml17YsFXuPJ8VYxmU=",
      "url": "bootstrap-icons/icons/filetype-doc.svg"
    },
    {
      "hash": "sha256-jbcUI9tK1rP4/q7rQZCEkMZqOExDo9JTkrk5d6PtmSU=",
      "url": "bootstrap-icons/icons/filetype-docx.svg"
    },
    {
      "hash": "sha256-o7kQJjiUyB2ifU1DYZuqn43x8TUAxHgJimywXk53x6Q=",
      "url": "bootstrap-icons/icons/filetype-exe.svg"
    },
    {
      "hash": "sha256-QpX20xe2CENnCYaGajzGgV6PNzNYEhGGIj4OdiPxyR8=",
      "url": "bootstrap-icons/icons/filetype-gif.svg"
    },
    {
      "hash": "sha256-WlWcl7YOOyubzBwaNt1IgdQwczty0i88pj5qlTIjPu8=",
      "url": "bootstrap-icons/icons/filetype-heic.svg"
    },
    {
      "hash": "sha256-WiFVIp4DGmX8lsRCsh651O18KYeQXAnsibN8h59Ohyg=",
      "url": "bootstrap-icons/icons/filetype-html.svg"
    },
    {
      "hash": "sha256-zu//1i2VsCokO2uC+g4mv2Y4rxsd7Ic6PM3fZ9iupuI=",
      "url": "bootstrap-icons/icons/filetype-java.svg"
    },
    {
      "hash": "sha256-9FKVGMF/iQRgFXnpnsNZjfI2c/QjxxIGdGg/02kWrKQ=",
      "url": "bootstrap-icons/icons/filetype-jpg.svg"
    },
    {
      "hash": "sha256-1v5+PPmZv4z5VP3TZq3DKPKXnOm9i6b28KBVjU0ZkC8=",
      "url": "bootstrap-icons/icons/filetype-js.svg"
    },
    {
      "hash": "sha256-ct32FXBPS224OTluHS4nu9nW8hqhcJj1J0kqRas/3lY=",
      "url": "bootstrap-icons/icons/filetype-json.svg"
    },
    {
      "hash": "sha256-wsl1y87RLpg+LJUHcaNhxUZub6dUd4gSnqUIGFR4REI=",
      "url": "bootstrap-icons/icons/filetype-jsx.svg"
    },
    {
      "hash": "sha256-B8XyOPjp38LrEwJEFDGyfQo21FhIEYr8yY8PTVlbF/s=",
      "url": "bootstrap-icons/icons/filetype-key.svg"
    },
    {
      "hash": "sha256-reBhqn4mCTo1XtGX/+/y7yf4SGEZcyvnLEDfQxzuSbo=",
      "url": "bootstrap-icons/icons/filetype-m4p.svg"
    },
    {
      "hash": "sha256-uDkKUZcQ18qX1G5SfWvRMs68aoV3k81C+Z227zgY8yU=",
      "url": "bootstrap-icons/icons/filetype-md.svg"
    },
    {
      "hash": "sha256-P3+LwC9oxJwmQj6r3Y+YUJJiB529aBcknjZ8yMmsCQs=",
      "url": "bootstrap-icons/icons/filetype-mdx.svg"
    },
    {
      "hash": "sha256-MiXZqvYyDJloPGAPKp+2Ld4j2FW3SnRObZAhTDZEoZs=",
      "url": "bootstrap-icons/icons/filetype-mov.svg"
    },
    {
      "hash": "sha256-xnrfj6zYPpJT9wYQw1V9v4bkn6zLor5jU4E0AGm6dYY=",
      "url": "bootstrap-icons/icons/filetype-mp3.svg"
    },
    {
      "hash": "sha256-x2GmWY8gtk6SMcC56pXy8FBeuc/+3YPXewHbhlfQmEM=",
      "url": "bootstrap-icons/icons/filetype-mp4.svg"
    },
    {
      "hash": "sha256-JX++v6tmoTI33D8WH5I7SqX17GdhEN8YPVaa43FGkpk=",
      "url": "bootstrap-icons/icons/filetype-otf.svg"
    },
    {
      "hash": "sha256-YWKC1qwjgO5bFeOTdD1vHoGLBSnKPucMV3UXGtxDR1k=",
      "url": "bootstrap-icons/icons/filetype-pdf.svg"
    },
    {
      "hash": "sha256-mK4VuB7YIxb4BuHTvo/53xLd64yknZ8Ifa+9hWcyeTM=",
      "url": "bootstrap-icons/icons/filetype-php.svg"
    },
    {
      "hash": "sha256-hRa3xddrkNG1EZJ7sWVIUCzL/1M4tx6yzvyOtfYat1w=",
      "url": "bootstrap-icons/icons/filetype-png.svg"
    },
    {
      "hash": "sha256-GxmGe7NRoVCwj+zPtgCOGtMiz9/SSgVCheLHv80vLns=",
      "url": "bootstrap-icons/icons/filetype-ppt.svg"
    },
    {
      "hash": "sha256-1Y+sPdPsFy/zosL97rvbyCJnUXIevMpbPU8Z1d0haaA=",
      "url": "bootstrap-icons/icons/filetype-pptx.svg"
    },
    {
      "hash": "sha256-s3A1IeoAAkti2mc0Vp/UWVyQwyKsye1ShJUYCAlw48E=",
      "url": "bootstrap-icons/icons/filetype-psd.svg"
    },
    {
      "hash": "sha256-ohIIITkESz4caK8XhVo5fnNYO4upp3WSJsOPeM6CFdE=",
      "url": "bootstrap-icons/icons/filetype-py.svg"
    },
    {
      "hash": "sha256-JvUpjxt/altRNfM8vsbjur4gKBmGaYWSQiqZrktAeeE=",
      "url": "bootstrap-icons/icons/filetype-raw.svg"
    },
    {
      "hash": "sha256-79JPzd90ybGk1ivVZvSwVeNDTuPT4a8RnUSy3xDCPb0=",
      "url": "bootstrap-icons/icons/filetype-rb.svg"
    },
    {
      "hash": "sha256-DrXG5mRG7nYckbzM8A10SjwPo7ZPzxeg6CFTQKcd3wQ=",
      "url": "bootstrap-icons/icons/filetype-sass.svg"
    },
    {
      "hash": "sha256-iU+aMG2p2x/mtOYNDN3o57wg6hAhuJ0mTTItP7D6xmQ=",
      "url": "bootstrap-icons/icons/filetype-scss.svg"
    },
    {
      "hash": "sha256-UvRzeVx397s+FNohX42B630ctjyKZAv8y4foWfHoeQI=",
      "url": "bootstrap-icons/icons/filetype-sh.svg"
    },
    {
      "hash": "sha256-96lev39x0aVIwRqm0XsgjXatXgU0js1vFkFkhFHUSHU=",
      "url": "bootstrap-icons/icons/filetype-sql.svg"
    },
    {
      "hash": "sha256-GKfRxOmOlN64mLdFfVR4SfJ6hT1xlNTJ9wrk8fe97Bs=",
      "url": "bootstrap-icons/icons/filetype-svg.svg"
    },
    {
      "hash": "sha256-arjQZT/e9L/a8MAl3Q6fe1cwubGknqV4K32ZSyYPxm4=",
      "url": "bootstrap-icons/icons/filetype-tiff.svg"
    },
    {
      "hash": "sha256-chJpmaAo6qboxFxGdDChCJm725AGC0NUvsgIfZN1yBU=",
      "url": "bootstrap-icons/icons/filetype-tsx.svg"
    },
    {
      "hash": "sha256-vsjJiDjNCv9qSxJ5pTCiooAmUl8z+G2wnn9vqf8ZjC8=",
      "url": "bootstrap-icons/icons/filetype-ttf.svg"
    },
    {
      "hash": "sha256-HYf/TjCuPrnU1gfGGf+qWyUZ8OksnoxgjTJyFEvE3Ho=",
      "url": "bootstrap-icons/icons/filetype-txt.svg"
    },
    {
      "hash": "sha256-piZ2uZH1ih4FDfbb99+6T5XToPNiMAun2zxFVtWKDak=",
      "url": "bootstrap-icons/icons/filetype-wav.svg"
    },
    {
      "hash": "sha256-smXMit8/lIuOB+oisSc6M0KvIcSzhCteMev+abqoK7c=",
      "url": "bootstrap-icons/icons/filetype-woff.svg"
    },
    {
      "hash": "sha256-OQp7oDQiHU3PZdvz27KmwAYs1HhhfTK87g1dHZQm3Cs=",
      "url": "bootstrap-icons/icons/filetype-xls.svg"
    },
    {
      "hash": "sha256-ORhh/RellZy+higJytOnTAokzt52oS+Ir9dYZXL1Z8w=",
      "url": "bootstrap-icons/icons/filetype-xlsx.svg"
    },
    {
      "hash": "sha256-i+mYeKRcw/KVW+1CiVAqgAPFRWq59XVLnUhaNNHlcgk=",
      "url": "bootstrap-icons/icons/filetype-xml.svg"
    },
    {
      "hash": "sha256-urdBPcYPJkEJzn0/PoFDoSvp5jiPbFlp1fYZw16HyaI=",
      "url": "bootstrap-icons/icons/filetype-yml.svg"
    },
    {
      "hash": "sha256-k0nlYEWT6V3BQwks15HeYqgoplaUWBpor2Cs6aFLeWI=",
      "url": "bootstrap-icons/icons/film.svg"
    },
    {
      "hash": "sha256-uIeTFFosRBzq6tQ5qG75sK9R43Uco5Hf5AtR9PJViDw=",
      "url": "bootstrap-icons/icons/filter-circle-fill.svg"
    },
    {
      "hash": "sha256-QT/q/nFhArUy7mSKSS6ZNb3xFaHgC8j8wxGAsque0fw=",
      "url": "bootstrap-icons/icons/filter-circle.svg"
    },
    {
      "hash": "sha256-2+LIDMuV1UvknusHh5jOQ4rCcqFpIIH3qhf54TbBIZ0=",
      "url": "bootstrap-icons/icons/filter-left.svg"
    },
    {
      "hash": "sha256-7G6xa9tVQA0PznynYsOL/kY9JZ+ZEMXzXErCPQQ7geo=",
      "url": "bootstrap-icons/icons/filter-right.svg"
    },
    {
      "hash": "sha256-MheMn9bSonTQj337sC3bIqAfT6Ks1BbH++SSXCOqohQ=",
      "url": "bootstrap-icons/icons/filter-square-fill.svg"
    },
    {
      "hash": "sha256-+6hPbdRUFDWTE5Os4bikO9QG2zvds7Zf7u+AdauIvUg=",
      "url": "bootstrap-icons/icons/filter-square.svg"
    },
    {
      "hash": "sha256-BUeR4Y6DL832WwM9bjir4qxlwaaE39aG/DmRiiMTWRc=",
      "url": "bootstrap-icons/icons/filter.svg"
    },
    {
      "hash": "sha256-jsChUkoGEyiQWw/9nCvC7yXK4g4rJxAT3Y3P3WSrABM=",
      "url": "bootstrap-icons/icons/fingerprint.svg"
    },
    {
      "hash": "sha256-v7CC3/KExyT/5OZYWAYeTqj7+3V9BnDqmcPra8HJjRs=",
      "url": "bootstrap-icons/icons/fire.svg"
    },
    {
      "hash": "sha256-MCLAxz3qzJAzxKS7vPMc2J3Movc0teHqOoLnehym8zc=",
      "url": "bootstrap-icons/icons/flag-fill.svg"
    },
    {
      "hash": "sha256-eR7XCiu3oSIBJWVU82nDX0GEMFvNUTu4GU/FGzwV8Bk=",
      "url": "bootstrap-icons/icons/flag.svg"
    },
    {
      "hash": "sha256-DSPORRSqsFspKFKn2EzrwYs65uhcFICsLM7nWMSsa8E=",
      "url": "bootstrap-icons/icons/flask-fill.svg"
    },
    {
      "hash": "sha256-5Rd8cH34f/1dld0A9LcJ3CCgA7JegbiwpQntnLJi+KM=",
      "url": "bootstrap-icons/icons/flask-florence-fill.svg"
    },
    {
      "hash": "sha256-d0NO2emabd5M1uE05kh3TZKGnKa0eocMltQKxMIxKFE=",
      "url": "bootstrap-icons/icons/flask-florence.svg"
    },
    {
      "hash": "sha256-8oW24afx1uVt/Nr2N1HDCkiJo/41Kn2vzhTI1TWv6m4=",
      "url": "bootstrap-icons/icons/flask.svg"
    },
    {
      "hash": "sha256-HYi8vIoqc+5B4YbN7KVzxKmm7JotWdc7prlvpU2Vu+o=",
      "url": "bootstrap-icons/icons/floppy-fill.svg"
    },
    {
      "hash": "sha256-7TZ5EdK2MY1UCqUed/sriPW4SabQFJCO9lEndmNhElg=",
      "url": "bootstrap-icons/icons/floppy.svg"
    },
    {
      "hash": "sha256-cUxC8jVFEO8Q/liXlPEOysgb8Yyfgu+ggLqw1RghuKQ=",
      "url": "bootstrap-icons/icons/floppy2-fill.svg"
    },
    {
      "hash": "sha256-6NyLvX75p9OEUh38tMNYK7eBYxLMzidtu/uwEldqOpw=",
      "url": "bootstrap-icons/icons/floppy2.svg"
    },
    {
      "hash": "sha256-lFrnCz5XrSffxusIj5vIZ0XZF9MWhAYQGZK3gXrmb10=",
      "url": "bootstrap-icons/icons/flower1.svg"
    },
    {
      "hash": "sha256-EswuBvnFL8iQN2BkYFr/GkYbF1FGKlT9rzb8GXsLcoU=",
      "url": "bootstrap-icons/icons/flower2.svg"
    },
    {
      "hash": "sha256-M7g9HR06sou0DOzV4mHTR2omuyMSWaHqMMZkGWfKIyE=",
      "url": "bootstrap-icons/icons/flower3.svg"
    },
    {
      "hash": "sha256-neIYjbOz/+7SKoaXTp0/nTrole64k/8u10kENWRW12I=",
      "url": "bootstrap-icons/icons/folder-check.svg"
    },
    {
      "hash": "sha256-IAT9mlEW4rWsNlKms0XT/3p5ee2rDF55QDuAA8ucAh0=",
      "url": "bootstrap-icons/icons/folder-fill.svg"
    },
    {
      "hash": "sha256-JyeRpyXLXepI8Ws4BVa7Ab/Z9biWFL5shtXNvRLQs/c=",
      "url": "bootstrap-icons/icons/folder-minus.svg"
    },
    {
      "hash": "sha256-vzObgzy0gPQlXIvSb1Hj9Llwk19VW4vJ97RogIeac/o=",
      "url": "bootstrap-icons/icons/folder-plus.svg"
    },
    {
      "hash": "sha256-W7DOXYlB3oF1wSPmihuDsJQgLRiu6PZT31ac/ClBYPk=",
      "url": "bootstrap-icons/icons/folder-symlink-fill.svg"
    },
    {
      "hash": "sha256-Qz/EXMtpWn9/0cHOQZaO2dt/8wTddQEY5ByA/zmXDLE=",
      "url": "bootstrap-icons/icons/folder-symlink.svg"
    },
    {
      "hash": "sha256-gcjoT7aDYz3S46z3PpMPk5mMyFNiX6oeJfYc9sLlWiM=",
      "url": "bootstrap-icons/icons/folder-x.svg"
    },
    {
      "hash": "sha256-L36t7KSR/XVjHeZRArMzL6V+/3kbFgWLQopTfrc29Qc=",
      "url": "bootstrap-icons/icons/folder.svg"
    },
    {
      "hash": "sha256-DMOLAZfLfzwejcCAJ1KMr+9BALXrK8UIrmllP/KDdVY=",
      "url": "bootstrap-icons/icons/folder2-open.svg"
    },
    {
      "hash": "sha256-9sq84oyI57fNC7ks2rJ00p0oPt1CI4hNnulCTbnTwv4=",
      "url": "bootstrap-icons/icons/folder2.svg"
    },
    {
      "hash": "sha256-yoTyHUNwmsE3oVEN4zc4HjY6HF5vxWbA+yG8Q6eGWBk=",
      "url": "bootstrap-icons/icons/fonts.svg"
    },
    {
      "hash": "sha256-8eM9i6xSpZ9aqny/G7xoyDfIyPcm6moy4yi6mKHwH10=",
      "url": "bootstrap-icons/icons/fork-knife.svg"
    },
    {
      "hash": "sha256-K1+ZALaUgSPByjR/njCVdO4/H8vrQWktgNeFYf+Nkas=",
      "url": "bootstrap-icons/icons/forward-fill.svg"
    },
    {
      "hash": "sha256-VKvxEFrK+NhgNgSjOFzNbrARpEexC8Q2D7d3Y249nwI=",
      "url": "bootstrap-icons/icons/forward.svg"
    },
    {
      "hash": "sha256-K4hD76uIiyR3DL1QIvdH2MxevHFfTKLmdRIvdrMkEaA=",
      "url": "bootstrap-icons/icons/front.svg"
    },
    {
      "hash": "sha256-3/cusPGMkBdwF8NsTkP4iwMIp/NvkC2mIMBEZR3xxoE=",
      "url": "bootstrap-icons/icons/fuel-pump-diesel-fill.svg"
    },
    {
      "hash": "sha256-U6CdnwW4BZ13gkpA7jw73MfgyTz5xCDq35lWiZVTBEM=",
      "url": "bootstrap-icons/icons/fuel-pump-diesel.svg"
    },
    {
      "hash": "sha256-NDTE98Pzu2XUSjxpg3/4Yi35HoOlc227oOgwZ/wUtoI=",
      "url": "bootstrap-icons/icons/fuel-pump-fill.svg"
    },
    {
      "hash": "sha256-bBnA3cGXHr/seI2gchkMlH9cEWjFPAKblYvjtdtxkbc=",
      "url": "bootstrap-icons/icons/fuel-pump.svg"
    },
    {
      "hash": "sha256-HPoeMQb/1SBOu7TSDSaSknmKgxgqz5Lt7Wk4izj/9Tg=",
      "url": "bootstrap-icons/icons/fullscreen-exit.svg"
    },
    {
      "hash": "sha256-w/+3Wma/rsPGoA4zLvlBrZhPEbzzmRII8sIiAtq99QE=",
      "url": "bootstrap-icons/icons/fullscreen.svg"
    },
    {
      "hash": "sha256-lc7T+Xz2FLFF7J2N7gU2gMRlObed2eJAEBzDANI3ZQ4=",
      "url": "bootstrap-icons/icons/funnel-fill.svg"
    },
    {
      "hash": "sha256-M3IZlKcvFrT7RCESPb190QSAEkRg997m0e05H73zHKY=",
      "url": "bootstrap-icons/icons/funnel.svg"
    },
    {
      "hash": "sha256-3KfOaO8+T/WSFzk9p8iUasi+GSXT5Nat6h0mOPq4Xbg=",
      "url": "bootstrap-icons/icons/gear-fill.svg"
    },
    {
      "hash": "sha256-YWkgp08JGazPKYqwxV7ooM+Q2kgxCPCDmHEps/S3RRo=",
      "url": "bootstrap-icons/icons/gear-wide-connected.svg"
    },
    {
      "hash": "sha256-fmqk4MKw4aEWBAeUbGEPedk+ipPRew3+5e7sq0GoarA=",
      "url": "bootstrap-icons/icons/gear-wide.svg"
    },
    {
      "hash": "sha256-D0gPyxQAwF/j60QAbj7/1dTGw1QCsEX4+lUpr8Aztio=",
      "url": "bootstrap-icons/icons/gear.svg"
    },
    {
      "hash": "sha256-2NgAC4uRjS7i2nuj/LFFb21xRiCeD01ZJwz4FF0VHOw=",
      "url": "bootstrap-icons/icons/gem.svg"
    },
    {
      "hash": "sha256-lB7vgXsi2fVoXrs8Pb4IFmTelqb6reR+bNIVwZ2Rlmw=",
      "url": "bootstrap-icons/icons/gender-ambiguous.svg"
    },
    {
      "hash": "sha256-myJyi1hPCIY7VDf0xaK997cPGdusBBKB7Fw3mUsyJqQ=",
      "url": "bootstrap-icons/icons/gender-female.svg"
    },
    {
      "hash": "sha256-mBv4VWh7NsBwymWyKymku7KyNRqri1WTaLSFl8KypY4=",
      "url": "bootstrap-icons/icons/gender-male.svg"
    },
    {
      "hash": "sha256-cuMXPGo84qF3gvOHRoWmX9sxGU4CIVZ57u9D0zqmvvE=",
      "url": "bootstrap-icons/icons/gender-neuter.svg"
    },
    {
      "hash": "sha256-anJ2Hm5vWU/2SpMqgISaRbKen+xjO1IR8+JuneLK3zA=",
      "url": "bootstrap-icons/icons/gender-trans.svg"
    },
    {
      "hash": "sha256-vKheKNFddZ/pmEEHRXLKoaMM3DsFMTWYZicXmrULiPk=",
      "url": "bootstrap-icons/icons/geo-alt-fill.svg"
    },
    {
      "hash": "sha256-BOpKnz3xd3AYJqlBx3EZ7tzgPhAvD3aX13rhD/RTywg=",
      "url": "bootstrap-icons/icons/geo-alt.svg"
    },
    {
      "hash": "sha256-wqgeJgGrxGnuNj7SP05NzTtbjwU4XMaMf3Z/qG+52Fs=",
      "url": "bootstrap-icons/icons/geo-fill.svg"
    },
    {
      "hash": "sha256-tyBsl0WWGQissd+CQ4PEyLAtBV77Xsg48NHG9oiRWE8=",
      "url": "bootstrap-icons/icons/geo.svg"
    },
    {
      "hash": "sha256-pPzqza8vt5+DQKmSNugFy49SKS4LzoddriPQ1GjtT8U=",
      "url": "bootstrap-icons/icons/gift-fill.svg"
    },
    {
      "hash": "sha256-cjxUHs+OXJLjMHgPCuM2ef9fOCsyKd1KXGVUGkkLJbU=",
      "url": "bootstrap-icons/icons/gift.svg"
    },
    {
      "hash": "sha256-R+qCeZHrgifa1gUITYrOlu/UFnvdDoLeXphNr0XKzKA=",
      "url": "bootstrap-icons/icons/git.svg"
    },
    {
      "hash": "sha256-QZxd5Y9L/rBu0uFeR1llvTnPsEDRyGJ+7QC8ul9ZrpY=",
      "url": "bootstrap-icons/icons/github.svg"
    },
    {
      "hash": "sha256-MjCpDZUAG6UMGuLok+imZlrXdmiLt6rgS4vl1BejdM4=",
      "url": "bootstrap-icons/icons/gitlab.svg"
    },
    {
      "hash": "sha256-xAbxQGifaVJQR5DMvBm/p6UH9wz1co0NgvUQDLvl5ng=",
      "url": "bootstrap-icons/icons/globe-americas-fill.svg"
    },
    {
      "hash": "sha256-lb2i40mGzY9WD2fAG1A0+cSbt5rscySnZiWmJ1rAXMU=",
      "url": "bootstrap-icons/icons/globe-americas.svg"
    },
    {
      "hash": "sha256-9KDwAwNyYSTxMeqebFWat0h1ywss7rA3KVZXh0BULx8=",
      "url": "bootstrap-icons/icons/globe-asia-australia-fill.svg"
    },
    {
      "hash": "sha256-qq78AhntW9gMT6ZCh8bufUmz9gbGwN/SdNkxNKGXlPI=",
      "url": "bootstrap-icons/icons/globe-asia-australia.svg"
    },
    {
      "hash": "sha256-XLEgQZ/CBi3WP9GnVlqpMA3CAUXAYJwGKFAxL/JDr+8=",
      "url": "bootstrap-icons/icons/globe-central-south-asia-fill.svg"
    },
    {
      "hash": "sha256-Dn7q3klgwUCRTxdwqRUei7x58dSORSqczUBz4VRM21c=",
      "url": "bootstrap-icons/icons/globe-central-south-asia.svg"
    },
    {
      "hash": "sha256-gpv1PVxjowLyaMe8vkESKdyHPT3fQuym9quSSQXATTI=",
      "url": "bootstrap-icons/icons/globe-europe-africa-fill.svg"
    },
    {
      "hash": "sha256-poUYgPGQaM8WrqqxSWQsdl/G4g70Kn6pN5c+HZaQYBA=",
      "url": "bootstrap-icons/icons/globe-europe-africa.svg"
    },
    {
      "hash": "sha256-7GnMfBoRwSwqUWVQjrDtVNgInYtrOSH6s1FT0qTfTo8=",
      "url": "bootstrap-icons/icons/globe.svg"
    },
    {
      "hash": "sha256-Q2XyBEuug7H8gcrjgWl3f2ITEQN4LtdCNrjiiYIsrVg=",
      "url": "bootstrap-icons/icons/globe2.svg"
    },
    {
      "hash": "sha256-iMNhJNhmkbJO8bdSNevK3ruQwAIChwjmoAKWN8+bkqw=",
      "url": "bootstrap-icons/icons/google-play.svg"
    },
    {
      "hash": "sha256-tgw40lO1vR7tE2LDmVZ3Zaj+XaoJe/ptjkS/dB8y7ug=",
      "url": "bootstrap-icons/icons/google.svg"
    },
    {
      "hash": "sha256-bFutQK+ASU6wR0MjYcODfVnHe8/OP2lQJKrXQ1nnWeU=",
      "url": "bootstrap-icons/icons/gpu-card.svg"
    },
    {
      "hash": "sha256-Aivrrcl9pHp6Nn3B8qGTYlUrEY7qlHTtpYp6ABdZKrc=",
      "url": "bootstrap-icons/icons/graph-down-arrow.svg"
    },
    {
      "hash": "sha256-DJ7JPLNDzi1db9Liqhu/LzidNCtqEq/pwsZmq/l0Sxs=",
      "url": "bootstrap-icons/icons/graph-down.svg"
    },
    {
      "hash": "sha256-x/tZsRPEpNBuLZS+L8ymMipGxm5uk7RSL9X8d4W9QD4=",
      "url": "bootstrap-icons/icons/graph-up-arrow.svg"
    },
    {
      "hash": "sha256-uM84jwm6MlFRvB8ncUaCs4hCtH9hvoChGzYrG2HRJUk=",
      "url": "bootstrap-icons/icons/graph-up.svg"
    },
    {
      "hash": "sha256-spxTUvntJhPJD8WrYE8JRy4x9BH1VD2lL1hpR8HTDEY=",
      "url": "bootstrap-icons/icons/grid-1x2-fill.svg"
    },
    {
      "hash": "sha256-WrNxxX0/ydf9sGYvSeOb0GDcZvjlxNpN5gQ7dCJt1HI=",
      "url": "bootstrap-icons/icons/grid-1x2.svg"
    },
    {
      "hash": "sha256-uy7fIf+3QvrZ51nTPKaJjaySs1GtKLpEmO7wBeWYBGs=",
      "url": "bootstrap-icons/icons/grid-3x2-gap-fill.svg"
    },
    {
      "hash": "sha256-oytIHPnSlGhycAskI3Y1Oq6XOdRhAH+12E8WUUg7M+U=",
      "url": "bootstrap-icons/icons/grid-3x2-gap.svg"
    },
    {
      "hash": "sha256-Sd+Oce3hWRETZMRG0aBFFqPG6KMs+jPhbwwHD7k8QK4=",
      "url": "bootstrap-icons/icons/grid-3x2.svg"
    },
    {
      "hash": "sha256-0EEWWFbJkg992ijFRNmcPJySoTkLJ2vu2D0i/4qaIoM=",
      "url": "bootstrap-icons/icons/grid-3x3-gap-fill.svg"
    },
    {
      "hash": "sha256-1tr4DXvv02X44U9y1MOcWayEajjOKSgWznJ2Q9V5+6I=",
      "url": "bootstrap-icons/icons/grid-3x3-gap.svg"
    },
    {
      "hash": "sha256-vOM4ae16aJMnqoQ0LPGiKqM14BHmkCvt4wlDTyR3NKU=",
      "url": "bootstrap-icons/icons/grid-3x3.svg"
    },
    {
      "hash": "sha256-hdr9ogaknoKyouFOCofy5umcP64vKy55xvxty2juhk8=",
      "url": "bootstrap-icons/icons/grid-fill.svg"
    },
    {
      "hash": "sha256-s3+53EwFeBWH/ColKBzd5QJGczKtovqruNXxVh4MH0Q=",
      "url": "bootstrap-icons/icons/grid.svg"
    },
    {
      "hash": "sha256-85S570R1l7XxeQxo4QaQrivmYaEemDKGu96xWSyQMJc=",
      "url": "bootstrap-icons/icons/grip-horizontal.svg"
    },
    {
      "hash": "sha256-uUqxnstcdxXoSg0gu316w5FMkQ18juBw2h9sQ75PTqc=",
      "url": "bootstrap-icons/icons/grip-vertical.svg"
    },
    {
      "hash": "sha256-ipGglWY+9PLLiT6VaAGEGsoO894xP3nneeIQl4h2J40=",
      "url": "bootstrap-icons/icons/h-circle-fill.svg"
    },
    {
      "hash": "sha256-aQSbvVcjyXc6KQT8Uxvr7ueaA/6KTQbNMhB4We5nUc0=",
      "url": "bootstrap-icons/icons/h-circle.svg"
    },
    {
      "hash": "sha256-t0JGduAC8trVJvirbnoYe9hmA2EdTIBF9XmodxBwakE=",
      "url": "bootstrap-icons/icons/h-square-fill.svg"
    },
    {
      "hash": "sha256-me9Eip+jNadGx0DABw2NcSK9gIjKFb7j+RE3DcxdLsA=",
      "url": "bootstrap-icons/icons/h-square.svg"
    },
    {
      "hash": "sha256-gzTQpLWltT32k3S8kWLSe4Q1XvhiEKCQ1kSI8vOMFZY=",
      "url": "bootstrap-icons/icons/hammer.svg"
    },
    {
      "hash": "sha256-9f33+cElxHg88aGhqzcX5XcKZ/O0v2wgNutOMBAcWKA=",
      "url": "bootstrap-icons/icons/hand-index-fill.svg"
    },
    {
      "hash": "sha256-WIQiltKO4bUstxlWB7X51AMbslmsZ0lFB5+AhnV9wWA=",
      "url": "bootstrap-icons/icons/hand-index-thumb-fill.svg"
    },
    {
      "hash": "sha256-G4PnLs9PQO9hIRmnpkRHlGjU151BMkLsaBMogbgJrsU=",
      "url": "bootstrap-icons/icons/hand-index-thumb.svg"
    },
    {
      "hash": "sha256-C92LnJF6y/byHpZSm4jXo+Za3uEJG7/g+7f7wuiQARI=",
      "url": "bootstrap-icons/icons/hand-index.svg"
    },
    {
      "hash": "sha256-YEzotvdcqdC2PLMgP8Ws30qWgtQuoD9k8/W6gdXJ1z4=",
      "url": "bootstrap-icons/icons/hand-thumbs-down-fill.svg"
    },
    {
      "hash": "sha256-o2Ce3a1Sp39c35m5UikfPvV+dXvk025UbuZYkiMlnII=",
      "url": "bootstrap-icons/icons/hand-thumbs-down.svg"
    },
    {
      "hash": "sha256-FqSuvFA+9NweaeaTf1bHxvJ9wS9W3AKXzvwUwu1MTPQ=",
      "url": "bootstrap-icons/icons/hand-thumbs-up-fill.svg"
    },
    {
      "hash": "sha256-iFKQVsvn7DymtAEQYyAPbn4zz+BSCxWekD5HX8/Fjgw=",
      "url": "bootstrap-icons/icons/hand-thumbs-up.svg"
    },
    {
      "hash": "sha256-wjdFFj9d845PNQCEeBxx83Q0TrV9ee9f8sNAQvLZM7o=",
      "url": "bootstrap-icons/icons/handbag-fill.svg"
    },
    {
      "hash": "sha256-6YMd93hp5e/nU+xXixOdxH8ZnnbWujiFlJp3QxtvxnI=",
      "url": "bootstrap-icons/icons/handbag.svg"
    },
    {
      "hash": "sha256-NXw5phP+KS2yV7e7KBVlPblQhKU2tOwwtWXjYafTJDE=",
      "url": "bootstrap-icons/icons/hash.svg"
    },
    {
      "hash": "sha256-pqfct+qXQhXrUU6dTxHlM7VPb+r3p2MJRSmhJOWIXEw=",
      "url": "bootstrap-icons/icons/hdd-fill.svg"
    },
    {
      "hash": "sha256-8dYhDgfqQP0JJ+ab8HvWe5wOhH+Uqr03lxwFCk+KN9k=",
      "url": "bootstrap-icons/icons/hdd-network-fill.svg"
    },
    {
      "hash": "sha256-bF6icjdSatUekz6kr3f1GILce/Uu+qhXyC0KGRovC+I=",
      "url": "bootstrap-icons/icons/hdd-network.svg"
    },
    {
      "hash": "sha256-PsLEM3hZS6mzHtvyVHZd0hUFMtsQEOcSyl/ktgoAcK8=",
      "url": "bootstrap-icons/icons/hdd-rack-fill.svg"
    },
    {
      "hash": "sha256-WH/6cLhJx0Hs6MCskXHjbcbPebcjN44UzmhopkOdi2I=",
      "url": "bootstrap-icons/icons/hdd-rack.svg"
    },
    {
      "hash": "sha256-m/rilA3letLQ0/qhS3uK0EsWkPIaUxtnFUMGWeUdgwM=",
      "url": "bootstrap-icons/icons/hdd-stack-fill.svg"
    },
    {
      "hash": "sha256-hcvMqcZv98TNQX8p/lNo4mJRlvfnzceXs8R/p4424cw=",
      "url": "bootstrap-icons/icons/hdd-stack.svg"
    },
    {
      "hash": "sha256-t0p+1pVFybOXEgwaQCsDLBYH4jtdhsK7Rcy+l1/SAc0=",
      "url": "bootstrap-icons/icons/hdd.svg"
    },
    {
      "hash": "sha256-3LBnCobFSQaAcnADTAwCsxffJn0bG+OMgPetvBKi7fg=",
      "url": "bootstrap-icons/icons/hdmi-fill.svg"
    },
    {
      "hash": "sha256-8yaJBFCpg9WOnSUcTOv1nWwHwZeJsvd3LvnbDga4w9I=",
      "url": "bootstrap-icons/icons/hdmi.svg"
    },
    {
      "hash": "sha256-MVrVkrkImfuupcjVXBAhvBu2h/DUu7TKpRE8FRMokOo=",
      "url": "bootstrap-icons/icons/headphones.svg"
    },
    {
      "hash": "sha256-4Qlr/4FX8vEDAmqsGrGK1tZS4jPhT6p6bKgMVJLZWQE=",
      "url": "bootstrap-icons/icons/headset-vr.svg"
    },
    {
      "hash": "sha256-gES5VE6jUXnEepBMt+Af0v9EcupmDm70fG1AZt9zMvo=",
      "url": "bootstrap-icons/icons/headset.svg"
    },
    {
      "hash": "sha256-YwUOVvz9CGQTsdQC/dByxcfG7mRF57FJkRLsSGrtwGE=",
      "url": "bootstrap-icons/icons/heart-arrow.svg"
    },
    {
      "hash": "sha256-KQOWawsaMU1hSFZY7HAP6prEuZZiH7vAgRfaHzWJa2k=",
      "url": "bootstrap-icons/icons/heart-fill.svg"
    },
    {
      "hash": "sha256-WeH4BvLcpPun/3meAAy/jFaegH+P48rVSe32e2kLWWk=",
      "url": "bootstrap-icons/icons/heart-half.svg"
    },
    {
      "hash": "sha256-vFzr6keCCQkyKYdguqwDW27zduwoe98yP1s/+tgTLS4=",
      "url": "bootstrap-icons/icons/heart-pulse-fill.svg"
    },
    {
      "hash": "sha256-PK5MC9xtkiDhEKmZX8Flf5H7f7lf240lyoyShyp7rl8=",
      "url": "bootstrap-icons/icons/heart-pulse.svg"
    },
    {
      "hash": "sha256-oFtzf7RKUkzM8+vbau9PUhotKHQb9sgsTQUlFG4zQcA=",
      "url": "bootstrap-icons/icons/heart.svg"
    },
    {
      "hash": "sha256-qmi3DIvpb77AJ8VD1pEwDU8er9d8KqUKZ4IwO0JTfH8=",
      "url": "bootstrap-icons/icons/heartbreak-fill.svg"
    },
    {
      "hash": "sha256-+kco+Ncf/8dFq3fWZmIWCDdIkVmxrWcodLIIBcATd9g=",
      "url": "bootstrap-icons/icons/heartbreak.svg"
    },
    {
      "hash": "sha256-q0CXr1L+ihTO4S7pFFEDWUWRWuWnoGR4SgSKZIrvly8=",
      "url": "bootstrap-icons/icons/hearts.svg"
    },
    {
      "hash": "sha256-zLhhZgmt1B/6NXGJM4bswQJdzIqchQ4aAsi/s7XZRPs=",
      "url": "bootstrap-icons/icons/heptagon-fill.svg"
    },
    {
      "hash": "sha256-jXJQPWIzt6SdD9PHd6j+x/CGuARaMS6uAoiodpWBK+w=",
      "url": "bootstrap-icons/icons/heptagon-half.svg"
    },
    {
      "hash": "sha256-SB7nqWTJnlQj4VjdrUbG0iq4YgWmZTSfHnyqSUDAHeA=",
      "url": "bootstrap-icons/icons/heptagon.svg"
    },
    {
      "hash": "sha256-528qR+penKvOiX88NCeoXzixg1dSieoHTkaVSC6Ub1Q=",
      "url": "bootstrap-icons/icons/hexagon-fill.svg"
    },
    {
      "hash": "sha256-vvskjis+f/tf/vjDyznSfBnv9LGSuO7UZ8n9TuQpChA=",
      "url": "bootstrap-icons/icons/hexagon-half.svg"
    },
    {
      "hash": "sha256-/V8EP5rwYBaAsza6if8sQfRNz5BAH92Rmg28adxLJYc=",
      "url": "bootstrap-icons/icons/hexagon.svg"
    },
    {
      "hash": "sha256-4acvSbpUluLdIF+f9333JMPqApgWVGnXZG8QV31NGx0=",
      "url": "bootstrap-icons/icons/highlighter.svg"
    },
    {
      "hash": "sha256-mLfbB2ENKkVKHoxB1eJfyUbOyNxCcwIf05yMq3i8o6M=",
      "url": "bootstrap-icons/icons/highlights.svg"
    },
    {
      "hash": "sha256-D5K5wDTpSu84JAQdVafXYFjzxVYSUB7YCrKiWgDrOvk=",
      "url": "bootstrap-icons/icons/hospital-fill.svg"
    },
    {
      "hash": "sha256-OYGEorOaYjk6sHqr43culSbhRX2tyMtnKQjZNAnfoGs=",
      "url": "bootstrap-icons/icons/hospital.svg"
    },
    {
      "hash": "sha256-Ny1VzBqME+1ATypd7h/FA66pKmtIngrEhFm5H+KSQkU=",
      "url": "bootstrap-icons/icons/hourglass-bottom.svg"
    },
    {
      "hash": "sha256-fCxeQEcEzEaJzvL2m7NTvEjVXKKQGjRhbpCOGjeMX88=",
      "url": "bootstrap-icons/icons/hourglass-split.svg"
    },
    {
      "hash": "sha256-+cs77mosGZLfvFV8KEQAGGciwNKifEDP2pSy+ETglQo=",
      "url": "bootstrap-icons/icons/hourglass-top.svg"
    },
    {
      "hash": "sha256-jQ/M6yCuaROmVyvJ3u/yAl4dYJoKF3Lamg5QRr1B8xI=",
      "url": "bootstrap-icons/icons/hourglass.svg"
    },
    {
      "hash": "sha256-yXOdG7SBbsMzw1wMtAAaZ2y2nYQEVeDDj8x0m5WHXPc=",
      "url": "bootstrap-icons/icons/house-add-fill.svg"
    },
    {
      "hash": "sha256-jPNk3yIbtBhdEjMpgzHGWYJlGTyz+/hInhF6MdxxoNU=",
      "url": "bootstrap-icons/icons/house-add.svg"
    },
    {
      "hash": "sha256-F3iolZid+NM+28q+RF0sdRbm1STYv+Xruo9/aZ1+uwM=",
      "url": "bootstrap-icons/icons/house-check-fill.svg"
    },
    {
      "hash": "sha256-pTYyqeIuVqJi4NdgTlcn/URBZ3DCtdCB/sYe/7ivCuA=",
      "url": "bootstrap-icons/icons/house-check.svg"
    },
    {
      "hash": "sha256-JOHovBqSB/Myq857YNCcnK/5DPY8tKdeawPvJQxpN4M=",
      "url": "bootstrap-icons/icons/house-dash-fill.svg"
    },
    {
      "hash": "sha256-5ppYelxgsyG248Y9E/lZLsIkgKj7rgZBGyyAhYQmOCw=",
      "url": "bootstrap-icons/icons/house-dash.svg"
    },
    {
      "hash": "sha256-h2ohepn1Z6jfdh5QH5VLQE2nhHB+HrxJssbjlhMThDs=",
      "url": "bootstrap-icons/icons/house-door-fill.svg"
    },
    {
      "hash": "sha256-Ti+5DpH6WMZHAusrt8uMFzmg60la1F7TcOMKSrBbxsM=",
      "url": "bootstrap-icons/icons/house-door.svg"
    },
    {
      "hash": "sha256-DLKRTPHBSCKRovCKY4cG21PTSVfKV5jdeOREosLll/k=",
      "url": "bootstrap-icons/icons/house-down-fill.svg"
    },
    {
      "hash": "sha256-7SAI2cGMQroEyJQBck1YHeIiL8Ku8yypGgWovPVGEQI=",
      "url": "bootstrap-icons/icons/house-down.svg"
    },
    {
      "hash": "sha256-GtlBraE11zEuqM11BEduePsnteL3ekAt9+iL3nl51LQ=",
      "url": "bootstrap-icons/icons/house-exclamation-fill.svg"
    },
    {
      "hash": "sha256-K2RAnwTV3rWLbfx9pkqdHpB3rmDwuZhbaLkIQoBY1L8=",
      "url": "bootstrap-icons/icons/house-exclamation.svg"
    },
    {
      "hash": "sha256-8sOupcw/jtzYjtwaxVw2iVOI/Bz9XRQQSHe9iDnK/Bg=",
      "url": "bootstrap-icons/icons/house-fill.svg"
    },
    {
      "hash": "sha256-SeZwZxGZRoEImn8DPY24wOXTzvaGb/xxHsxPwftGeKg=",
      "url": "bootstrap-icons/icons/house-gear-fill.svg"
    },
    {
      "hash": "sha256-jXv84CXKRHIDXucSn0R7sS9S7cBGpr2Xi8FFFHQYlTw=",
      "url": "bootstrap-icons/icons/house-gear.svg"
    },
    {
      "hash": "sha256-/ysJISVTVdlZ1wxkDvLeCVDHu+1zZ+UlHi5M2ArWrEo=",
      "url": "bootstrap-icons/icons/house-heart-fill.svg"
    },
    {
      "hash": "sha256-b7cqq23YIZoWUiAl5z335eTfDhngMVm+wdkrGq5ZGdA=",
      "url": "bootstrap-icons/icons/house-heart.svg"
    },
    {
      "hash": "sha256-XYP0PVXF1FB9v7x2LcrKt79pq7B3CEaXd7ZcXCml97o=",
      "url": "bootstrap-icons/icons/house-lock-fill.svg"
    },
    {
      "hash": "sha256-yMbLTv1B56FU9C+5LfK9ruPWRD7Vll10muhtUWShulc=",
      "url": "bootstrap-icons/icons/house-lock.svg"
    },
    {
      "hash": "sha256-GcKzkYC/5J2lkqpXfmPr6WEY2ZKvQjKo0C6XgPxNFcY=",
      "url": "bootstrap-icons/icons/house-slash-fill.svg"
    },
    {
      "hash": "sha256-icFJg9IJ9pAIxDBcyZ8N31acYDFN7NLHRTKpW1O7gLs=",
      "url": "bootstrap-icons/icons/house-slash.svg"
    },
    {
      "hash": "sha256-VtaE5/GS64Tadrdbf394xCgmQGtXBKzhknxRJHdutTI=",
      "url": "bootstrap-icons/icons/house-up-fill.svg"
    },
    {
      "hash": "sha256-XcOFyP1PqQatDOb8ekPSH7WAMt6NOwrvaZ0rZ+gNbiQ=",
      "url": "bootstrap-icons/icons/house-up.svg"
    },
    {
      "hash": "sha256-U1eDukSJEGEnLaetvGZ/j7GkiZ4M0r9gDlE2RgF2D6s=",
      "url": "bootstrap-icons/icons/house-x-fill.svg"
    },
    {
      "hash": "sha256-bpOQBSosS0GkrCyxEDWKPM91R5PCdAbQ3iVR1eeqKi8=",
      "url": "bootstrap-icons/icons/house-x.svg"
    },
    {
      "hash": "sha256-gaaJs/Gwci9RaOlwQdvpt9qMthAkx7hQ38nwaDgg/Bk=",
      "url": "bootstrap-icons/icons/house.svg"
    },
    {
      "hash": "sha256-dmdhNHb8PPnhawK02quq9uriw/+TuQZ5q1whBg480CE=",
      "url": "bootstrap-icons/icons/houses-fill.svg"
    },
    {
      "hash": "sha256-cBHaV3TY1Wg9qeRj/l5LUqG8j6AgdxmXCqa+xjBmg+Y=",
      "url": "bootstrap-icons/icons/houses.svg"
    },
    {
      "hash": "sha256-+lYXIOS/H08bVcAIRfXfr9DnfMKV0BpwphYZJy9/lIU=",
      "url": "bootstrap-icons/icons/hr.svg"
    },
    {
      "hash": "sha256-P9MYScUb3rDAROcrOXdXRrrM5IvgUUPfgfeyRBATSUY=",
      "url": "bootstrap-icons/icons/hurricane.svg"
    },
    {
      "hash": "sha256-K8rx7pCf2R+6IO2M43So8QN3xWn9b8Y7udtTjsDCbHw=",
      "url": "bootstrap-icons/icons/hypnotize.svg"
    },
    {
      "hash": "sha256-23+iMepfkojSbTPBYX6cx8FmC+LjtBg1VDgpzE3jBrw=",
      "url": "bootstrap-icons/icons/image-alt.svg"
    },
    {
      "hash": "sha256-LEvXiwXA4hC2U9py4CyrZFqS9GUKSF2my39b1/cQKbE=",
      "url": "bootstrap-icons/icons/image-fill.svg"
    },
    {
      "hash": "sha256-ZAcQowku9qvaH4YGEoO1svKQ/n/08e0rAFMW/hNFccc=",
      "url": "bootstrap-icons/icons/image.svg"
    },
    {
      "hash": "sha256-NArxxxHC0uuI+cVk55xh3X4vh7yVRtaxszkChoN4JgM=",
      "url": "bootstrap-icons/icons/images.svg"
    },
    {
      "hash": "sha256-VrEQcJa8Ikp2XaeyDH/LrAIVdNH9iNn6CDG80JHOH8w=",
      "url": "bootstrap-icons/icons/inbox-fill.svg"
    },
    {
      "hash": "sha256-aw26ADVMjLlQ8Yek96WAfnSbMVrLqcyjhPZQRIwnElM=",
      "url": "bootstrap-icons/icons/inbox.svg"
    },
    {
      "hash": "sha256-gVsK1MSNQnGDy+7uzr7yUJLcXAeXBAv0hr3258qCDPk=",
      "url": "bootstrap-icons/icons/inboxes-fill.svg"
    },
    {
      "hash": "sha256-p2xdScNaaYxyRBENeoGhWwjU5KJySxv391Lu6303zD4=",
      "url": "bootstrap-icons/icons/inboxes.svg"
    },
    {
      "hash": "sha256-ydsHWfziSmtyCcEjsVIFcuvMwzAFRHSJAva5Y8MKuyU=",
      "url": "bootstrap-icons/icons/incognito.svg"
    },
    {
      "hash": "sha256-mIAAx3dwQJOFKjwAsL/3Q7+FQoFGdRcQ//AsSVNtaJg=",
      "url": "bootstrap-icons/icons/indent.svg"
    },
    {
      "hash": "sha256-njr7Um59NSJVJA7yd/miuqfs8UWAvfqQuMo59e3zDCs=",
      "url": "bootstrap-icons/icons/infinity.svg"
    },
    {
      "hash": "sha256-iWkjuhuyAM5S58YuoISV6qinmkIzmdgMWoq9nd7WsAk=",
      "url": "bootstrap-icons/icons/info-circle-fill.svg"
    },
    {
      "hash": "sha256-lINkWL9jQx/zfEHe3GgYJw/X7HKp+y2pF+8tAJaPl8o=",
      "url": "bootstrap-icons/icons/info-circle.svg"
    },
    {
      "hash": "sha256-G9NKeGzx8wmVVEUlwehs972Y3KpQ5ISsVatWv72sTSg=",
      "url": "bootstrap-icons/icons/info-lg.svg"
    },
    {
      "hash": "sha256-TRbWtsthI+5amtsKdQNpCkZPwL+utjx0P8f3nybemoY=",
      "url": "bootstrap-icons/icons/info-square-fill.svg"
    },
    {
      "hash": "sha256-/hZu9uiUPLffGuWzTiHWRg1d6AqHqckWCy1lzgtvw5M=",
      "url": "bootstrap-icons/icons/info-square.svg"
    },
    {
      "hash": "sha256-5yaV7yduogIblz5hZvzRsanYhRihiWrWLdvpMfPtuZo=",
      "url": "bootstrap-icons/icons/info.svg"
    },
    {
      "hash": "sha256-arLnWQjgauL7PyzdMGvhG/ynm+MURkI67cYhgD/7GeI=",
      "url": "bootstrap-icons/icons/input-cursor-text.svg"
    },
    {
      "hash": "sha256-RxWzDNsed8JdRT2F8a4YNWGrhbESBLCrf2ceG2aMd5A=",
      "url": "bootstrap-icons/icons/input-cursor.svg"
    },
    {
      "hash": "sha256-GeU7EH0ZuBzJIhfpOJtdHPmKdjftllpdB9boTo0gDLA=",
      "url": "bootstrap-icons/icons/instagram.svg"
    },
    {
      "hash": "sha256-cTAVWt0tctO2wq4nWL3md4+uhrSlWIQwaFLEAhQ+r6g=",
      "url": "bootstrap-icons/icons/intersect.svg"
    },
    {
      "hash": "sha256-YJhy8L7ZhFrijjgAbfO1FXVeJlzx4m02bQsFrQciFYQ=",
      "url": "bootstrap-icons/icons/javascript.svg"
    },
    {
      "hash": "sha256-Gz8K2BXUN6df4n0/aINJu+jxWXxdBEPZTIYasPkg4kY=",
      "url": "bootstrap-icons/icons/journal-album.svg"
    },
    {
      "hash": "sha256-64gV64irZguGurqnbH5LIWa2JzNOxGBWnuSKgR/vvZI=",
      "url": "bootstrap-icons/icons/journal-arrow-down.svg"
    },
    {
      "hash": "sha256-C8aioBWjxyQNrintpb4whk6dStGmwX3plaVN3qJk2qk=",
      "url": "bootstrap-icons/icons/journal-arrow-up.svg"
    },
    {
      "hash": "sha256-KRFDwp4lkXcfZFsUb0B2bx1WauifiMhgTaWoZEg/MtQ=",
      "url": "bootstrap-icons/icons/journal-bookmark-fill.svg"
    },
    {
      "hash": "sha256-NruYeZABgBVNXViGiU/v/g+txFThkRPkUXqxVSEByuY=",
      "url": "bootstrap-icons/icons/journal-bookmark.svg"
    },
    {
      "hash": "sha256-LWk562QOgnovr+tRVGMtKaYLUKv03EB4YG/VqCcTy9k=",
      "url": "bootstrap-icons/icons/journal-check.svg"
    },
    {
      "hash": "sha256-6sWBoziUTK7rjxNY4MiveV7YgM0tX6RyVWiFnsG7lLk=",
      "url": "bootstrap-icons/icons/journal-code.svg"
    },
    {
      "hash": "sha256-oaXXN4fmMWSo3MqGAa3a3FzHvCISI1vKmjAnpCxOdDs=",
      "url": "bootstrap-icons/icons/journal-medical.svg"
    },
    {
      "hash": "sha256-EnCkYuPs+QKCCWgCdkRhFTtvyUJhibPhYvlOOroWles=",
      "url": "bootstrap-icons/icons/journal-minus.svg"
    },
    {
      "hash": "sha256-YX/Kr7Zy5Cd+0rQ4jgGB8xYuWL+bHvQR6DTORsl7fTk=",
      "url": "bootstrap-icons/icons/journal-plus.svg"
    },
    {
      "hash": "sha256-SNYDxLkOpPPBGAXEkI00eHumPZ/XI5/4KAm3Z4olTmY=",
      "url": "bootstrap-icons/icons/journal-richtext.svg"
    },
    {
      "hash": "sha256-cjEfuCnCSZGWeXvEISvDbMAw4auaQuMnzHlHU4OovMA=",
      "url": "bootstrap-icons/icons/journal-text.svg"
    },
    {
      "hash": "sha256-q2sdxCY5GxRLijuQHjZH/w7SrXsWwBjpj6612FI2Nss=",
      "url": "bootstrap-icons/icons/journal-x.svg"
    },
    {
      "hash": "sha256-XOdXA01BP66RW1ml6iqbrxuWveOUuPTdHNCEtTXc5A0=",
      "url": "bootstrap-icons/icons/journal.svg"
    },
    {
      "hash": "sha256-7GmSZ/8btXuGUjUmF7FjIHK5XJCLNt353sO5eL4c6zc=",
      "url": "bootstrap-icons/icons/journals.svg"
    },
    {
      "hash": "sha256-dPxVG3vykSguSYZIH06f0/sZkILlBa2+p77WmYLmusQ=",
      "url": "bootstrap-icons/icons/joystick.svg"
    },
    {
      "hash": "sha256-ndPGBs7DxWIeeUVaHlj0aeRGDk+MXD5PJJ9wgIY6J18=",
      "url": "bootstrap-icons/icons/justify-left.svg"
    },
    {
      "hash": "sha256-Uhlz/VLVK+RrV0OUkRqGp3a2d1oy/pey8KRlli2rChY=",
      "url": "bootstrap-icons/icons/justify-right.svg"
    },
    {
      "hash": "sha256-tUjHDoFWZs/f64OY8zTcxLXzWnnYwKolwHMvKVZKpnk=",
      "url": "bootstrap-icons/icons/justify.svg"
    },
    {
      "hash": "sha256-sYEeuE/gn3jFtZr02xZ9glx9NijqMzQ60brWLthOhdc=",
      "url": "bootstrap-icons/icons/kanban-fill.svg"
    },
    {
      "hash": "sha256-88bmvowrC4Zw+thL9Vu0mIWG1CVVpkVwj9/3HMOWo9M=",
      "url": "bootstrap-icons/icons/kanban.svg"
    },
    {
      "hash": "sha256-Po2ipdyqBvkK+oWcU54a8cmMk/kvd5rFqDLdKpIOZV0=",
      "url": "bootstrap-icons/icons/key-fill.svg"
    },
    {
      "hash": "sha256-5YaLL+Uc1/Zz7/1SSONvibB7a20tEW9sl7ejbnXf694=",
      "url": "bootstrap-icons/icons/key.svg"
    },
    {
      "hash": "sha256-mX2jpnM3uPMkkRFikRzIQhERwLsxvtBvklr/dVOf5z0=",
      "url": "bootstrap-icons/icons/keyboard-fill.svg"
    },
    {
      "hash": "sha256-jQmfVTkl/XJycxV+jhtNEbXjmtnfad1wiz6NfQ4rQrM=",
      "url": "bootstrap-icons/icons/keyboard.svg"
    },
    {
      "hash": "sha256-e+VrMwZndisdmju8b/VudMPZbe8kfMnTaa7Zm72rQPY=",
      "url": "bootstrap-icons/icons/ladder.svg"
    },
    {
      "hash": "sha256-VFuHCaAKrsFkfjiCnyHxzTzwVo75hHGYyYtZBJYUCU0=",
      "url": "bootstrap-icons/icons/lamp-fill.svg"
    },
    {
      "hash": "sha256-wCle1RoiWWH2wu/GKaFIDgY//9//y/0S2gOBLza+1WA=",
      "url": "bootstrap-icons/icons/lamp.svg"
    },
    {
      "hash": "sha256-tb6BioWShrpY/ZTnYjX5Sk8ZHYBcIirHX7j00Ia4jK8=",
      "url": "bootstrap-icons/icons/laptop-fill.svg"
    },
    {
      "hash": "sha256-KowEp1NMxyA5NLGG+5V/RdT0cDHNHbgX6Yh9+xB2KTk=",
      "url": "bootstrap-icons/icons/laptop.svg"
    },
    {
      "hash": "sha256-ZReUqHhzHdffc0V5DhOK3QgoUScuRnj/KopP6UShxa4=",
      "url": "bootstrap-icons/icons/layer-backward.svg"
    },
    {
      "hash": "sha256-Vfu4NnAK4RvAUVB6EiozusQiThwclhMINxUrog8R114=",
      "url": "bootstrap-icons/icons/layer-forward.svg"
    },
    {
      "hash": "sha256-he0hQS+jBUNEfgWsqwjelwENHH7TvaNP5/+ExzAIAUA=",
      "url": "bootstrap-icons/icons/layers-fill.svg"
    },
    {
      "hash": "sha256-VQHdY/gH6gNF1H/nx82tEzL2abmag9fz4m0K5JHDv14=",
      "url": "bootstrap-icons/icons/layers-half.svg"
    },
    {
      "hash": "sha256-pCb7/MbOR37XpWj1LT9cpseEl/D5ZE8osH3e4DWrYh4=",
      "url": "bootstrap-icons/icons/layers.svg"
    },
    {
      "hash": "sha256-hODfo/As99ywM1fGnJXF9BsChhDzf1/gnxKtZmJX6v4=",
      "url": "bootstrap-icons/icons/layout-sidebar-inset-reverse.svg"
    },
    {
      "hash": "sha256-WNaAgPU+K5kon0WCNMEzXXThNqBGMcChp3ctho/ezG8=",
      "url": "bootstrap-icons/icons/layout-sidebar-inset.svg"
    },
    {
      "hash": "sha256-OhDq/IJSWxYSO2I46gLceiFB62Ov06Y4433af2JSHHg=",
      "url": "bootstrap-icons/icons/layout-sidebar-reverse.svg"
    },
    {
      "hash": "sha256-m4Cx0+R2CSuHbQsj1tfyPrnKoBBlO/CgzDvgFp+cMXg=",
      "url": "bootstrap-icons/icons/layout-sidebar.svg"
    },
    {
      "hash": "sha256-b7oV/kZ8NWO2KqZdRdbjChdywOR3saCT779mtNDK4cw=",
      "url": "bootstrap-icons/icons/layout-split.svg"
    },
    {
      "hash": "sha256-hkT89g0CxdbWQQYpjCjxi5HwP5GZADgC8fN6sG5tI3Q=",
      "url": "bootstrap-icons/icons/layout-text-sidebar-reverse.svg"
    },
    {
      "hash": "sha256-y6MEgB+qavUTV55uTvbYO9lXROAdeBRVuv/UfPoRGaU=",
      "url": "bootstrap-icons/icons/layout-text-sidebar.svg"
    },
    {
      "hash": "sha256-HvIoYaonkj80lNXQZTVJRSpP9e6j4b3QpaVMiyDAQQk=",
      "url": "bootstrap-icons/icons/layout-text-window-reverse.svg"
    },
    {
      "hash": "sha256-c1qhhOEKZYczdXi52ZvR/Mgj4iW1lCqOC25x3a+3owo=",
      "url": "bootstrap-icons/icons/layout-text-window.svg"
    },
    {
      "hash": "sha256-kHmLj/SaK9ppEKyOqr8TfeM4VR5RISw3mkqnGf+7h8c=",
      "url": "bootstrap-icons/icons/layout-three-columns.svg"
    },
    {
      "hash": "sha256-ZLQw838jAM5BLYNIwdyYOi2TZRDhLuDMS0cHJ8v3f5w=",
      "url": "bootstrap-icons/icons/layout-wtf.svg"
    },
    {
      "hash": "sha256-mGiTxAvLrKWmx2olbgBbrgMXcVWW5vUnCuHIsN8prdc=",
      "url": "bootstrap-icons/icons/leaf-fill.svg"
    },
    {
      "hash": "sha256-jtVmUzUrtowmHD9u2YvBimb23m/c2g3JOJnpTl/VUmQ=",
      "url": "bootstrap-icons/icons/leaf.svg"
    },
    {
      "hash": "sha256-OMR5eXDckauGqyxULBBuZAkmAOKr6dOOEXMNk/qG3wk=",
      "url": "bootstrap-icons/icons/life-preserver.svg"
    },
    {
      "hash": "sha256-U0sjqtDZRlrCzRTrPvDGWjURGMxbGle5P0e8o6Y6Zx0=",
      "url": "bootstrap-icons/icons/lightbulb-fill.svg"
    },
    {
      "hash": "sha256-QcdrcKZjdmGSTWdHaz1f1yegKbRxL69IvnV7k4Mhwbs=",
      "url": "bootstrap-icons/icons/lightbulb-off-fill.svg"
    },
    {
      "hash": "sha256-Gk0zn/ISgjHV057mjLwXwvNh0sg/LB8KWCO20JQmgCs=",
      "url": "bootstrap-icons/icons/lightbulb-off.svg"
    },
    {
      "hash": "sha256-3lMfkJpuav4ltKkJum5zuXCSncVFGuhjzOU5q7EaGV8=",
      "url": "bootstrap-icons/icons/lightbulb.svg"
    },
    {
      "hash": "sha256-VNf+/WQEbYyVuxv8wpsdjA2flUddEI/7i3WeXpTCBIs=",
      "url": "bootstrap-icons/icons/lightning-charge-fill.svg"
    },
    {
      "hash": "sha256-x2+C8gsxrT7RgSEhdQLzYYxbF+cIza/nuXtcrHp03DE=",
      "url": "bootstrap-icons/icons/lightning-charge.svg"
    },
    {
      "hash": "sha256-75hRvh5KrI6iMvF+OiVO/2qxtIzTCFlmIngcmxpyPwc=",
      "url": "bootstrap-icons/icons/lightning-fill.svg"
    },
    {
      "hash": "sha256-Q8PrEYKwCzwVW1hLhZCGkm55981I4IQvtZRCBhOrpPE=",
      "url": "bootstrap-icons/icons/lightning.svg"
    },
    {
      "hash": "sha256-0lYbYO7TSuv1ODS0bSWsCp74OTKdG3GPJ32gp332JSc=",
      "url": "bootstrap-icons/icons/line.svg"
    },
    {
      "hash": "sha256-Oli4mVOebpaoonnE3MYDpWJifnM0hKpy9yHNoGtgwfg=",
      "url": "bootstrap-icons/icons/link-45deg.svg"
    },
    {
      "hash": "sha256-la50VGtop+wgt853VTK7+ucIcpOfNtkm/DqUDkl2ffk=",
      "url": "bootstrap-icons/icons/link.svg"
    },
    {
      "hash": "sha256-3cuyc17qEvCQ6g7jcdG5o0YlMdwR79DpRK3C04xx4t8=",
      "url": "bootstrap-icons/icons/linkedin.svg"
    },
    {
      "hash": "sha256-y1iDMxhF1fyadak91Im1GeLsLZB3oE4hUNc9edLW7SI=",
      "url": "bootstrap-icons/icons/list-check.svg"
    },
    {
      "hash": "sha256-hU029LcYKgESqpmGwkehDjpKiYXiIkb4kDRNh02qlAI=",
      "url": "bootstrap-icons/icons/list-columns-reverse.svg"
    },
    {
      "hash": "sha256-HR4MEHJdZOqbvUIjIC4+hCuqeI/xQVUAw59zuvghxsU=",
      "url": "bootstrap-icons/icons/list-columns.svg"
    },
    {
      "hash": "sha256-BYz99DK48IZg6nJ9xDbSVSvHTJmSsS6vyGXqbPI8VpE=",
      "url": "bootstrap-icons/icons/list-nested.svg"
    },
    {
      "hash": "sha256-stSJVc18m8UKGIuMeI9JzHweUvuP7Azbs0f9FOcAbUQ=",
      "url": "bootstrap-icons/icons/list-ol.svg"
    },
    {
      "hash": "sha256-FiMQgwqkFoD46uGQQ9KRitc9JSOshDtdInhn69HTdpM=",
      "url": "bootstrap-icons/icons/list-stars.svg"
    },
    {
      "hash": "sha256-kZOrhZ5rY27fXkI8erI1Jh35daQBaUD14dpTfndUEe8=",
      "url": "bootstrap-icons/icons/list-task.svg"
    },
    {
      "hash": "sha256-mTTL1cxj7OS2U2y4Dg3fjH52h4ek8faUi55jaQDpuGU=",
      "url": "bootstrap-icons/icons/list-ul.svg"
    },
    {
      "hash": "sha256-yjLp6JeI0HIUEJad9P4OAyfbiG7nRg8BjmFahUM9mH4=",
      "url": "bootstrap-icons/icons/list.svg"
    },
    {
      "hash": "sha256-j71A/2Hp/ELfRPE50LQJtQG0LRy96fQ/XNXqJc8HswQ=",
      "url": "bootstrap-icons/icons/lock-fill.svg"
    },
    {
      "hash": "sha256-/cKLklC3Igs2vCZ8ZcSdPL2+54uHWAUsIDeXQhec/lA=",
      "url": "bootstrap-icons/icons/lock.svg"
    },
    {
      "hash": "sha256-T7ciz848sDqIJznRD4fpxussSObvkzTd6NvXm94usP8=",
      "url": "bootstrap-icons/icons/luggage-fill.svg"
    },
    {
      "hash": "sha256-oyIS2GOGj7dVGY9dsvtbfy9ymYl/9df2rC7EzSb44Ac=",
      "url": "bootstrap-icons/icons/luggage.svg"
    },
    {
      "hash": "sha256-AgG/W5qlr24zhy1B8S7eYiJNxE2zn+UVrFSN7LVYCVA=",
      "url": "bootstrap-icons/icons/lungs-fill.svg"
    },
    {
      "hash": "sha256-JE5kLQ6w4E0nE2Uf9Y/onn8YN446WkShFfGEjzE4+Zc=",
      "url": "bootstrap-icons/icons/lungs.svg"
    },
    {
      "hash": "sha256-XjITrXqBWG7J3TqUa5D+Olt3NE6preizmqJt8v5LjII=",
      "url": "bootstrap-icons/icons/magic.svg"
    },
    {
      "hash": "sha256-OPZ0U7h6yjxBnpO4FxDOjUm29WYhM2KD709A1oiyj/M=",
      "url": "bootstrap-icons/icons/magnet-fill.svg"
    },
    {
      "hash": "sha256-cqdQ4DGg4fB3Cxvvo+yaPo6QGGuOBMmfrO0uLIc6Rg8=",
      "url": "bootstrap-icons/icons/magnet.svg"
    },
    {
      "hash": "sha256-PdaDTksROIbNqs76fIxf2fOQEgxurZlM3t/cTbOL1x8=",
      "url": "bootstrap-icons/icons/mailbox-flag.svg"
    },
    {
      "hash": "sha256-8o4cy9EvJgnh4pZfCqshssb+o69KK45YTTbo9VkbVMQ=",
      "url": "bootstrap-icons/icons/mailbox.svg"
    },
    {
      "hash": "sha256-WGxiJc1s5Wqt49q7kzxi0d8NsvP8qKHbgyLm889nAlU=",
      "url": "bootstrap-icons/icons/mailbox2-flag.svg"
    },
    {
      "hash": "sha256-xRCMeiok+wwOR5M8PcDtI8ygA2G7ZKo+rYgGrcPtMAA=",
      "url": "bootstrap-icons/icons/mailbox2.svg"
    },
    {
      "hash": "sha256-NSLQyug9ZCUzRR/dlzWTxJ/BRXFArdyEarwoWUoqGvk=",
      "url": "bootstrap-icons/icons/map-fill.svg"
    },
    {
      "hash": "sha256-Z6bhd9J4jr9vXVn2zUhMcMbjpTfcXt3uj6MIcoVD4FY=",
      "url": "bootstrap-icons/icons/map.svg"
    },
    {
      "hash": "sha256-lyrD/58iM9bngQ5/gjPJ77R0ECkMYGiUZlB7NrZAVVg=",
      "url": "bootstrap-icons/icons/markdown-fill.svg"
    },
    {
      "hash": "sha256-tc0CXVSPsceIZj9FHO6Nm4C6Uajpg3SqWu6NRmJwhww=",
      "url": "bootstrap-icons/icons/markdown.svg"
    },
    {
      "hash": "sha256-treylpg6dqy1xfSrpV0uJW32u4SHmgilht/Fi4NwsmA=",
      "url": "bootstrap-icons/icons/marker-tip.svg"
    },
    {
      "hash": "sha256-WmT0M/DPTXDObz9D8gAbbKpD+QYtkgE7vehwodMbs6A=",
      "url": "bootstrap-icons/icons/mask.svg"
    },
    {
      "hash": "sha256-QCs23scgA+aZT1FOmhwMa/30Ll5UtyGa6yYxpWwEUfU=",
      "url": "bootstrap-icons/icons/mastodon.svg"
    },
    {
      "hash": "sha256-QXVMfCgRctosMH7tvEtdREvq3ZBpjDnrkLV3qBmHtqI=",
      "url": "bootstrap-icons/icons/measuring-cup-fill.svg"
    },
    {
      "hash": "sha256-VZe32d7fGTFBb1JJbJmxAYzKwBBL36DiRTsJhIN73rM=",
      "url": "bootstrap-icons/icons/measuring-cup.svg"
    },
    {
      "hash": "sha256-wFXHkuZOd/pLODb/1wXa5iXMTP255YwPg+jz5BBrd24=",
      "url": "bootstrap-icons/icons/medium.svg"
    },
    {
      "hash": "sha256-v32bIG6MNVfOe3FuyNymESNjtcpwxL80usPZ94xvHjo=",
      "url": "bootstrap-icons/icons/megaphone-fill.svg"
    },
    {
      "hash": "sha256-UAwk8cJeHTk/d8jbwHY4Q4llvYLVB2qNHQx1tIXLqvA=",
      "url": "bootstrap-icons/icons/megaphone.svg"
    },
    {
      "hash": "sha256-hqajKd94CmazMGEddO1KD9EWe8Vm1pX4IdlpEqO52c0=",
      "url": "bootstrap-icons/icons/memory.svg"
    },
    {
      "hash": "sha256-cJz+K9C6sJGgdvyiUnjbXZOBWvNZfzg6F2n2jQ6Zh8c=",
      "url": "bootstrap-icons/icons/menu-app-fill.svg"
    },
    {
      "hash": "sha256-eV720aYgsLE5NMUVJtQ9E2DOWv4K2yPgWz7AAHpl3T8=",
      "url": "bootstrap-icons/icons/menu-app.svg"
    },
    {
      "hash": "sha256-2uZG2H3XyfZzXWz8Rx1EnRBxIgRKe4Fhzt3apLJAr9k=",
      "url": "bootstrap-icons/icons/menu-button-fill.svg"
    },
    {
      "hash": "sha256-hvKbP0uV1lHzLrJZgcDj6s3IvhA8OlUNVu7GNubev1U=",
      "url": "bootstrap-icons/icons/menu-button-wide-fill.svg"
    },
    {
      "hash": "sha256-Vk5yubFbYvt7R6PXalj6tfGQdu3pSqLp/LJbwFeP0ro=",
      "url": "bootstrap-icons/icons/menu-button-wide.svg"
    },
    {
      "hash": "sha256-zqyCAgpqiKldr7eN/pzxUGTJkZiHvy7XOdSvHXsJfoQ=",
      "url": "bootstrap-icons/icons/menu-button.svg"
    },
    {
      "hash": "sha256-wFPLi6ClYmxOfF0aM0j1njh1VMOxUEH1P9Eg0WTDda8=",
      "url": "bootstrap-icons/icons/menu-down.svg"
    },
    {
      "hash": "sha256-nWEym4TAgIXFK9IG8+2VnN/ukwREsPzzJXtwS2F1Ywg=",
      "url": "bootstrap-icons/icons/menu-up.svg"
    },
    {
      "hash": "sha256-XVz7Zc1Ki2Enkqk8tlNT5Q/Z2vNs17qFp9MJG4HwbD8=",
      "url": "bootstrap-icons/icons/messenger.svg"
    },
    {
      "hash": "sha256-MAn1QueYYqniMDEHdE9bVQJbAJTGlsA51aOKjmNqOuQ=",
      "url": "bootstrap-icons/icons/meta.svg"
    },
    {
      "hash": "sha256-q3RcbmRwYzizDQcHwUJbW/bOuQJu0HU0QzDcarWXDHs=",
      "url": "bootstrap-icons/icons/mic-fill.svg"
    },
    {
      "hash": "sha256-F29yhdEoGg4dQx734gT62wukoYwGQo6b7HkgomGJYvk=",
      "url": "bootstrap-icons/icons/mic-mute-fill.svg"
    },
    {
      "hash": "sha256-ZdTNW2xdHJRyVVVebi8MIq/2pdlnqsuVZq7tnGQmkE0=",
      "url": "bootstrap-icons/icons/mic-mute.svg"
    },
    {
      "hash": "sha256-nKD9MKVYkwPqSQh1xhn77ngckry8hPjkR8pd22QTeRQ=",
      "url": "bootstrap-icons/icons/mic.svg"
    },
    {
      "hash": "sha256-L+rkwQvNuqd9yXNZ7I7IX91Wp/pR5tOPcTPR8JOzybg=",
      "url": "bootstrap-icons/icons/microsoft-teams.svg"
    },
    {
      "hash": "sha256-B81ghRzDfgfQQ4PYK4RI+ye48+15RrHypkjW9yjElaY=",
      "url": "bootstrap-icons/icons/microsoft.svg"
    },
    {
      "hash": "sha256-iDPmf4Pvf2Y9P3vXDXbMsMPla4DIUWTvXiMmpfTP6+c=",
      "url": "bootstrap-icons/icons/minecart-loaded.svg"
    },
    {
      "hash": "sha256-zh446trEe6MW0LFF9BbRqsCs2U9qG3kGHhL0Y61QfRU=",
      "url": "bootstrap-icons/icons/minecart.svg"
    },
    {
      "hash": "sha256-0HAutc09bcliEMCKudV/Y8oA1tRkZAGAtbAD7mHLqF4=",
      "url": "bootstrap-icons/icons/modem-fill.svg"
    },
    {
      "hash": "sha256-9bmpzbDBOHE/S2c2lhnRRlgNR1lWfoejs7nwRARpYWE=",
      "url": "bootstrap-icons/icons/modem.svg"
    },
    {
      "hash": "sha256-Q0cNN+yj4pbYr2hUmUVgb3HHE2cfwquuMl8VVFIY5pY=",
      "url": "bootstrap-icons/icons/moisture.svg"
    },
    {
      "hash": "sha256-k+2iB0IUWVXh7E2JSmk+mMbjWlxgKKVp6x8dNqcrcuk=",
      "url": "bootstrap-icons/icons/moon-fill.svg"
    },
    {
      "hash": "sha256-skvoo+KRt5serFUZscrEPutGW45hz5+muvwAbIuf8dQ=",
      "url": "bootstrap-icons/icons/moon-stars-fill.svg"
    },
    {
      "hash": "sha256-oPC25P8KhMQ3VxavwJdb+KUYlWZ27qvEhbUJL5PiuFg=",
      "url": "bootstrap-icons/icons/moon-stars.svg"
    },
    {
      "hash": "sha256-xo40D4vuwtnQeP02xYB3j8DAH5hMIH8KgEkZh2xAbQo=",
      "url": "bootstrap-icons/icons/moon.svg"
    },
    {
      "hash": "sha256-xx4DlXvS9LWIxHg6ChHVqkMjNiU4FT8XS095g5YsQno=",
      "url": "bootstrap-icons/icons/mortarboard-fill.svg"
    },
    {
      "hash": "sha256-v8+c4WthYM7+7uylrFkWUJO8BxNnhLpKEQ79sgPr1Vk=",
      "url": "bootstrap-icons/icons/mortarboard.svg"
    },
    {
      "hash": "sha256-oENL/HmDV6phIz8O+3+cMXXkuiXHd1bucceJeN6eMY4=",
      "url": "bootstrap-icons/icons/motherboard-fill.svg"
    },
    {
      "hash": "sha256-ASDczs7ONqxcs4XOF1QwLcnU5GkDNy89FTNdhvcyIxI=",
      "url": "bootstrap-icons/icons/motherboard.svg"
    },
    {
      "hash": "sha256-k9FCWbJqCxA7iHzN5F3gU+vNzukCxwTernP3PVmxUMw=",
      "url": "bootstrap-icons/icons/mouse-fill.svg"
    },
    {
      "hash": "sha256-GzhUDD3GGDn3oH5JvGQZDz6aSDRi8d8vbHbBpiUPHyA=",
      "url": "bootstrap-icons/icons/mouse.svg"
    },
    {
      "hash": "sha256-SdCK7829EVhbgnw78uqNlbjxEdZbPZl5Bau+0vL1It8=",
      "url": "bootstrap-icons/icons/mouse2-fill.svg"
    },
    {
      "hash": "sha256-5eWNu3kAQm6pyutgOnGG52lszgDqXM2rfenTrS0cxrQ=",
      "url": "bootstrap-icons/icons/mouse2.svg"
    },
    {
      "hash": "sha256-l/kQZdnwFbviel1YuiWYSn68Z2g15eC2HfL0Av93u9c=",
      "url": "bootstrap-icons/icons/mouse3-fill.svg"
    },
    {
      "hash": "sha256-nYDTxT1QPn2uosrc4En6GtugRWmIFlgVmtHhcNoLmvk=",
      "url": "bootstrap-icons/icons/mouse3.svg"
    },
    {
      "hash": "sha256-+m3JwO22Tt6LJRPcp1iBH44BtSpd4Iy4vU6w6n4CX1Q=",
      "url": "bootstrap-icons/icons/music-note-beamed.svg"
    },
    {
      "hash": "sha256-SCTDuyF2OhZBfKThzhJL9mEVUdlfxFBEtUB7lPw294s=",
      "url": "bootstrap-icons/icons/music-note-list.svg"
    },
    {
      "hash": "sha256-2s0HXCj7dI5HOM629Qwq7vi6DLV2u7N2LR0vtjpyN1g=",
      "url": "bootstrap-icons/icons/music-note.svg"
    },
    {
      "hash": "sha256-BZTy+xDL0K7ptZMWgNjpk1LjoWDbB4TYXgyeDrzf6yA=",
      "url": "bootstrap-icons/icons/music-player-fill.svg"
    },
    {
      "hash": "sha256-7ni30cDHL0bIcQRDSKQ2KtMR42NWPB5Z6lU4WMELCHc=",
      "url": "bootstrap-icons/icons/music-player.svg"
    },
    {
      "hash": "sha256-M0FIvTDyv9fQrXeYJQTDbByUHHODmSAaK8UnRaiVtc8=",
      "url": "bootstrap-icons/icons/newspaper.svg"
    },
    {
      "hash": "sha256-gTUivwzlbsmpgqiPfAVX1qCe3sCc74rJvQh9a/aYo1M=",
      "url": "bootstrap-icons/icons/nintendo-switch.svg"
    },
    {
      "hash": "sha256-6WwroU8VcuAlDKBg1AhrLy9/B21UL7ZdqJXzNV0/zIQ=",
      "url": "bootstrap-icons/icons/node-minus-fill.svg"
    },
    {
      "hash": "sha256-ATaiZ/NBbHlyZ0kJbF3omHMbhMKthwaF0PecTOtAE2s=",
      "url": "bootstrap-icons/icons/node-minus.svg"
    },
    {
      "hash": "sha256-fIMDDo+yuRQLc2r35mUroz4inuhopZiuW5Ri2JkSbPE=",
      "url": "bootstrap-icons/icons/node-plus-fill.svg"
    },
    {
      "hash": "sha256-/vHB4ECQxiSJAP/WMqwPCnI9+g0ZYbTxCEsuR9ngEo8=",
      "url": "bootstrap-icons/icons/node-plus.svg"
    },
    {
      "hash": "sha256-ZQQiMv+y3ld6GQWTJ3TsM/kZ+pVh1DMVGSfOpD6/RR0=",
      "url": "bootstrap-icons/icons/noise-reduction.svg"
    },
    {
      "hash": "sha256-me9tIIgenvAISHnNqwXdbm0gnOxawtrP+gnzrZDRgFM=",
      "url": "bootstrap-icons/icons/nut-fill.svg"
    },
    {
      "hash": "sha256-0HJuFTERc6SpsRnj2Z2Eo/yjtcjzcLgvCKggLeoFqS0=",
      "url": "bootstrap-icons/icons/nut.svg"
    },
    {
      "hash": "sha256-PhAnBw99uUNH1jHr9imcwBo+gTYQr3Q1BvWswSV674E=",
      "url": "bootstrap-icons/icons/nvidia.svg"
    },
    {
      "hash": "sha256-5oVFUsNmV27Pwil3E9ZU9U6J76uV0EVDx55Jmuf8FlA=",
      "url": "bootstrap-icons/icons/nvme-fill.svg"
    },
    {
      "hash": "sha256-F5x7EKg/9M809mH46MGzJEKgNtmGYJ76cJkI7AgCmk0=",
      "url": "bootstrap-icons/icons/nvme.svg"
    },
    {
      "hash": "sha256-5i1gn3nPksay4V+NUg0guMhXZ2huKLLyEX2xgg+a974=",
      "url": "bootstrap-icons/icons/octagon-fill.svg"
    },
    {
      "hash": "sha256-SGuj+PPLSF4xabDfdWUx8wdA4TCJxmxMOOqzr8HB5RM=",
      "url": "bootstrap-icons/icons/octagon-half.svg"
    },
    {
      "hash": "sha256-qncZgMifZrc2nVClcwGuhQ5R2CA1WQ5/OhP9n3TCU/U=",
      "url": "bootstrap-icons/icons/octagon.svg"
    },
    {
      "hash": "sha256-jp7w4Q4DkT9EZypJw/yJyVqk33qI41S7q7Z4Qlzu8JI=",
      "url": "bootstrap-icons/icons/openai.svg"
    },
    {
      "hash": "sha256-FSiBnsKQdu4QQkEuS+AKUlEhFw7663fhYfmbjrWL+Po=",
      "url": "bootstrap-icons/icons/opencollective.svg"
    },
    {
      "hash": "sha256-vcyRK/x3fznJsXZmtmpAx1gpZzbqsmPa/QSMrRXwJvg=",
      "url": "bootstrap-icons/icons/optical-audio-fill.svg"
    },
    {
      "hash": "sha256-0/TYkfAoOWwEOGKhszqgC7rdJIHtCWNmem5eKkxo4lQ=",
      "url": "bootstrap-icons/icons/optical-audio.svg"
    },
    {
      "hash": "sha256-ECzY4l+TTqcRNIn0UJGLox64KfZcmb7MlWwCUEJp9q0=",
      "url": "bootstrap-icons/icons/option.svg"
    },
    {
      "hash": "sha256-fwejxDpfsPAdTGD5b6PPjP19SHo+JFrrG5uReKjAbf8=",
      "url": "bootstrap-icons/icons/outlet.svg"
    },
    {
      "hash": "sha256-rxW2HRU2j86lj0sxaG53LMS4haNiWzQlrU3SmXu1JgE=",
      "url": "bootstrap-icons/icons/p-circle-fill.svg"
    },
    {
      "hash": "sha256-0ZS2wzBUAVPsDw3Lt1ap1xs35iM5PL/q6baC2vmTBJ4=",
      "url": "bootstrap-icons/icons/p-circle.svg"
    },
    {
      "hash": "sha256-9tnWIX8Ewv4IC7DULecXJ70WJjXjfTlQfAmGI6Z5MFI=",
      "url": "bootstrap-icons/icons/p-square-fill.svg"
    },
    {
      "hash": "sha256-Beny2C/eR2eI8liZadxVpduW5wvzDOLWi6gQqz5whVc=",
      "url": "bootstrap-icons/icons/p-square.svg"
    },
    {
      "hash": "sha256-QrMzX+lrc4SbF0Xek+guSTiuHvNpzgFYJtNAJhj9LM4=",
      "url": "bootstrap-icons/icons/paint-bucket.svg"
    },
    {
      "hash": "sha256-TygmsyiS1jh3q7gIyK6qFxLMSehaAR3UX/cHEHbuSg8=",
      "url": "bootstrap-icons/icons/palette-fill.svg"
    },
    {
      "hash": "sha256-ip+othGHQaMyLHG/rJ/50bveg43B6+TQKb1zReaG1Zw=",
      "url": "bootstrap-icons/icons/palette.svg"
    },
    {
      "hash": "sha256-9V1j4tWt5cJVgHsmBY4eT/vAG/abZNlNRUUqpkABJYg=",
      "url": "bootstrap-icons/icons/palette2.svg"
    },
    {
      "hash": "sha256-MJEmELBOsE20jiH3WW8tQD+r4eTIqcJEdZd7iroftbg=",
      "url": "bootstrap-icons/icons/paperclip.svg"
    },
    {
      "hash": "sha256-A6t0gS2mdLNDO9fqbJvMYeEPeauVExky5UeFbzCF23o=",
      "url": "bootstrap-icons/icons/paragraph.svg"
    },
    {
      "hash": "sha256-3BJ2q/Fz1EJzX3Q+QvSKB6EeeJhhGKcq4kJ3jAKuZZ4=",
      "url": "bootstrap-icons/icons/pass-fill.svg"
    },
    {
      "hash": "sha256-i4s9zwAdXcU8dXdaK+qCy+Dj5k2EH057QJ11bUoj+co=",
      "url": "bootstrap-icons/icons/pass.svg"
    },
    {
      "hash": "sha256-zyRdl9sTbMpCRRvjQ35Fh1eCPcwUPkTnbG64+FPbtAM=",
      "url": "bootstrap-icons/icons/passport-fill.svg"
    },
    {
      "hash": "sha256-Y80Wr8JCWE6Wbz2uU30whkgvmtaV7Vu3F4DJNDAdRIc=",
      "url": "bootstrap-icons/icons/passport.svg"
    },
    {
      "hash": "sha256-wddAlKGgMwHzuAJoB0lwYkM5QPoeXejgTwL+irf6gb4=",
      "url": "bootstrap-icons/icons/patch-check-fill.svg"
    },
    {
      "hash": "sha256-dFHIHCp2hu9jAbQQTz7p8D/xokiphfYfgjRK0h0svSY=",
      "url": "bootstrap-icons/icons/patch-check.svg"
    },
    {
      "hash": "sha256-hb523k9AjXZN4fGpCr5PhkOzI9fg8xU56p8mD30KhRs=",
      "url": "bootstrap-icons/icons/patch-exclamation-fill.svg"
    },
    {
      "hash": "sha256-1k1w6dcjSmCWIJpckC2cfFsspA0xXDQwF4TYdLaapGM=",
      "url": "bootstrap-icons/icons/patch-exclamation.svg"
    },
    {
      "hash": "sha256-uQFmYJspXg0Zdfwyd8tdto//TY0/UdEdBJ9WVJ3xB+4=",
      "url": "bootstrap-icons/icons/patch-minus-fill.svg"
    },
    {
      "hash": "sha256-eKM5EquANdraYMV2UecM5XunnXqVZmcGIFr5quUdJog=",
      "url": "bootstrap-icons/icons/patch-minus.svg"
    },
    {
      "hash": "sha256-uizae39Tz94ShvtIhUice4IiWW3IY8FWeswL8RW+zlM=",
      "url": "bootstrap-icons/icons/patch-plus-fill.svg"
    },
    {
      "hash": "sha256-sxNVz0LgtNFypv1BRpJ3cFn7DbLxzV3fNBfL9O9l1V0=",
      "url": "bootstrap-icons/icons/patch-plus.svg"
    },
    {
      "hash": "sha256-eQHPRLnm7t2GGkA3WV8V3mk1XWXVK832iUApft2Hsdo=",
      "url": "bootstrap-icons/icons/patch-question-fill.svg"
    },
    {
      "hash": "sha256-Ahv4Ikx/F2f4q0TFRkfAaZ3+IA78aqrxuCnEOKSehAg=",
      "url": "bootstrap-icons/icons/patch-question.svg"
    },
    {
      "hash": "sha256-YHAGNmvFqtWM4NElbjpoiV2KjOdcDQU9rOIfmNxQEjc=",
      "url": "bootstrap-icons/icons/pause-btn-fill.svg"
    },
    {
      "hash": "sha256-Vx/HoI66UBE1ibKezphBfcEB8SJxm6ynwbj8LRKXjMw=",
      "url": "bootstrap-icons/icons/pause-btn.svg"
    },
    {
      "hash": "sha256-hrbry2dc1vH0DCuxfjikiPBgYldH0opcFAizSWWKhJY=",
      "url": "bootstrap-icons/icons/pause-circle-fill.svg"
    },
    {
      "hash": "sha256-wkChb7nutr9B8kczldUc11vIkjMild0D7cxo99Ew8Vg=",
      "url": "bootstrap-icons/icons/pause-circle.svg"
    },
    {
      "hash": "sha256-smioyacgAGfKhgesyn/sVmlOPYlSqX+3rpkqeqdJG0Q=",
      "url": "bootstrap-icons/icons/pause-fill.svg"
    },
    {
      "hash": "sha256-EBZcZXa11NJ04TxmdWBwbvL+kvfn3Z6k3zDnHJJCnH0=",
      "url": "bootstrap-icons/icons/pause.svg"
    },
    {
      "hash": "sha256-Ajr3vl+VZvt5OyQfHGMg38UOEdbKm+wPQjZ2Nha24Oc=",
      "url": "bootstrap-icons/icons/paypal.svg"
    },
    {
      "hash": "sha256-L8+4+CKPASf+42FYnAqKS4FR60g8+HV/BBR9YFDDjOQ=",
      "url": "bootstrap-icons/icons/pc-display-horizontal.svg"
    },
    {
      "hash": "sha256-DzULoWC5wjrRs6Etxksm50nXAEQagew+/IlwKHaqXa4=",
      "url": "bootstrap-icons/icons/pc-display.svg"
    },
    {
      "hash": "sha256-YrslxLp2UEEK3sIZmfcYvqUwHbECjWb/q0J9wiulFiM=",
      "url": "bootstrap-icons/icons/pc-horizontal.svg"
    },
    {
      "hash": "sha256-+qwfn89O8SZAKyCUlhwCa97/sMbgGDK+8K2gejzDMAo=",
      "url": "bootstrap-icons/icons/pc.svg"
    },
    {
      "hash": "sha256-hD7zWH3TIIuS4hxQ/lLFVD1spICr9h1P8qCXr1s7kr4=",
      "url": "bootstrap-icons/icons/pci-card-network.svg"
    },
    {
      "hash": "sha256-ioLnZu2fgKOraOrKy6FO4sn3tfJcQxC/1gWTpEqZ5+g=",
      "url": "bootstrap-icons/icons/pci-card-sound.svg"
    },
    {
      "hash": "sha256-s5lFQVNC7UynkANf3Dg92B9VloEy1noD2qt7bgTBZ2M=",
      "url": "bootstrap-icons/icons/pci-card.svg"
    },
    {
      "hash": "sha256-XjzOS67vi25WpkZK4C/mQCUQDtWOx+Ho4JmbWE2d/RI=",
      "url": "bootstrap-icons/icons/peace-fill.svg"
    },
    {
      "hash": "sha256-lQOaMCAcieN6yj/gDB6xPJLrpoio4rgDAwlg+xmx9DY=",
      "url": "bootstrap-icons/icons/peace.svg"
    },
    {
      "hash": "sha256-ktfbERpBywwZXQmiefIGyXPRwoNBw5zdoLJyHiHhjhY=",
      "url": "bootstrap-icons/icons/pen-fill.svg"
    },
    {
      "hash": "sha256-f5fORbBz19VoYkEEw66ZfQGk/UYpJFq+38qV2LxC8RQ=",
      "url": "bootstrap-icons/icons/pen.svg"
    },
    {
      "hash": "sha256-aaR0UkGtQ9rBlL5ZIxT/PWPjy7GzneC9Ys0MXj3rV5s=",
      "url": "bootstrap-icons/icons/pencil-fill.svg"
    },
    {
      "hash": "sha256-df9IJpWnIUxQIvkNFlGq3oBLkir081U6QZL8go1Z3ZI=",
      "url": "bootstrap-icons/icons/pencil-square.svg"
    },
    {
      "hash": "sha256-iQ0K1KbUpB7y5zZVlqrGkQs9GfdypNqF/4kSkwOnl5w=",
      "url": "bootstrap-icons/icons/pencil.svg"
    },
    {
      "hash": "sha256-U2or2bxAa2igYQ9eOWULOSqk6oz+B1COIYESw5SOqms=",
      "url": "bootstrap-icons/icons/pentagon-fill.svg"
    },
    {
      "hash": "sha256-u7hmzPaaPiOsRdhQEwRzbnrkBJVKwsAvQCM9ka1l/HE=",
      "url": "bootstrap-icons/icons/pentagon-half.svg"
    },
    {
      "hash": "sha256-ILdcYJMB3yKdZn2evEoWQG3PWDxummaQNDUIpBp3vRY=",
      "url": "bootstrap-icons/icons/pentagon.svg"
    },
    {
      "hash": "sha256-kMP+oT9AUB4O+QPPhxoiJgKcvXyN3r2SH2sSfMDvM5w=",
      "url": "bootstrap-icons/icons/people-fill.svg"
    },
    {
      "hash": "sha256-8iB/5XwRTQ2AtOtbSYbdziEfvoBrJrialaWXI6ydm50=",
      "url": "bootstrap-icons/icons/people.svg"
    },
    {
      "hash": "sha256-uqR9VuLQRtXyH3B9DFtBRtcKiFo9i9LUIRa7v+7EUeY=",
      "url": "bootstrap-icons/icons/percent.svg"
    },
    {
      "hash": "sha256-GJgdk6J8RavfmUwP1BxQftq1UDEYo4vEI+6XM5kS/rw=",
      "url": "bootstrap-icons/icons/perplexity.svg"
    },
    {
      "hash": "sha256-gJDrgw5wK4bjIlHp6GppR1GNusnCGB9m9sk/e5qUg8U=",
      "url": "bootstrap-icons/icons/person-add.svg"
    },
    {
      "hash": "sha256-qFa1ZYIRaWSQV74PAeP1PJg+QNffNecRB/C6l3z5EOA=",
      "url": "bootstrap-icons/icons/person-arms-up.svg"
    },
    {
      "hash": "sha256-WU13WwsjLDOjFConxumYlLhPQTxRbfpphVb4fd3pmKM=",
      "url": "bootstrap-icons/icons/person-badge-fill.svg"
    },
    {
      "hash": "sha256-l7oWPQpKv0A/PPCKMv7SS8Eq5MBaQHEKmNu7okiyaR4=",
      "url": "bootstrap-icons/icons/person-badge.svg"
    },
    {
      "hash": "sha256-ZJxClrgkSLOc8OntAtCyeoGljkBT3cUzpRS9L0qNOaE=",
      "url": "bootstrap-icons/icons/person-bounding-box.svg"
    },
    {
      "hash": "sha256-Qge58nyFgfOPcJHiG2QNzaDFCQw+u7CjmyIkoqZ2kAc=",
      "url": "bootstrap-icons/icons/person-check-fill.svg"
    },
    {
      "hash": "sha256-MYFw3ebx3FhJfiSr6H3C+XWW0JEJayAXGr7pj4dvovo=",
      "url": "bootstrap-icons/icons/person-check.svg"
    },
    {
      "hash": "sha256-pIUYEWOoyRzRw4fVrnP+j9P4TZyMX0PCkYR/MbuJ7lM=",
      "url": "bootstrap-icons/icons/person-circle.svg"
    },
    {
      "hash": "sha256-SWTkZPwNnwpS0AxqxgbkUr5+3gpAzJfYsm2qqXikIPQ=",
      "url": "bootstrap-icons/icons/person-dash-fill.svg"
    },
    {
      "hash": "sha256-+CoKIs47w2eFJwFRyd7x4GpkGJRIuUaFkmI9bl64gcw=",
      "url": "bootstrap-icons/icons/person-dash.svg"
    },
    {
      "hash": "sha256-fxauRik+xPMij0sJ4dzTg0rO4NSDWvjAkJmsyW+v2ME=",
      "url": "bootstrap-icons/icons/person-down.svg"
    },
    {
      "hash": "sha256-VpV/pwAHs0BcXHOghBZIGlIbp4diCFSnjHtaoeKEkCk=",
      "url": "bootstrap-icons/icons/person-exclamation.svg"
    },
    {
      "hash": "sha256-e0Dw3a0K25KEdy/v79LzGwYs7k2aFM+dWBZBecIoZCc=",
      "url": "bootstrap-icons/icons/person-fill-add.svg"
    },
    {
      "hash": "sha256-/vqjR6rX2SQ8w3o9w9bx2twDSwZtWbTFgjaJ1bJYcz8=",
      "url": "bootstrap-icons/icons/person-fill-check.svg"
    },
    {
      "hash": "sha256-Xt6os84dquKYjivHbZfaxrO6GaU5NHzNFYNz0ANI+go=",
      "url": "bootstrap-icons/icons/person-fill-dash.svg"
    },
    {
      "hash": "sha256-uKWhi44FdP51WfCU9XX3UVGyRZgZAerZjq57kYHX+Xg=",
      "url": "bootstrap-icons/icons/person-fill-down.svg"
    },
    {
      "hash": "sha256-tuWzOoXkeRXLWT8B8O2oe4O/JYNP2cfyRnfPgGJcOSs=",
      "url": "bootstrap-icons/icons/person-fill-exclamation.svg"
    },
    {
      "hash": "sha256-tSGDUKkzn2armDCNq1dL2qMMmd6LTQ4Y5+pLyBYPoxg=",
      "url": "bootstrap-icons/icons/person-fill-gear.svg"
    },
    {
      "hash": "sha256-AcBjUVrtvLJAx63CW6XINkqn55jwc6TiSgg99gmo+7M=",
      "url": "bootstrap-icons/icons/person-fill-lock.svg"
    },
    {
      "hash": "sha256-K0t8SomnlPWI53mOdzivHSiAtKh2ZraX0aenv4pwY50=",
      "url": "bootstrap-icons/icons/person-fill-slash.svg"
    },
    {
      "hash": "sha256-t/fUpTze8bX9O4dz5DIvTmLWQReM7hn/a2XS+ncQ9cg=",
      "url": "bootstrap-icons/icons/person-fill-up.svg"
    },
    {
      "hash": "sha256-LC//PcM9MKBqdSL74Z4GnjMyH/5267leku1R7EwUJIk=",
      "url": "bootstrap-icons/icons/person-fill-x.svg"
    },
    {
      "hash": "sha256-EidQ1no4fVzAiXYdKsQMJhfeaqrvqyWyvQ6N7SN5A5E=",
      "url": "bootstrap-icons/icons/person-fill.svg"
    },
    {
      "hash": "sha256-svpL3DBBH89qh8oLJan4Fp4kip3jw3kiPt6Q/fFkKec=",
      "url": "bootstrap-icons/icons/person-gear.svg"
    },
    {
      "hash": "sha256-cUjZ3ms+DJSE0aRSrTUWqvWguXbLXW++dxxOasfZLy0=",
      "url": "bootstrap-icons/icons/person-heart.svg"
    },
    {
      "hash": "sha256-W6JEZQFowiwKg6zQ2eNC7WeI30Mdw5teC7/d3wsG9dY=",
      "url": "bootstrap-icons/icons/person-hearts.svg"
    },
    {
      "hash": "sha256-Pk7VBpqy+FIwOo6pLkozyDhU443AwKBHgzN3ioGGw8k=",
      "url": "bootstrap-icons/icons/person-lines-fill.svg"
    },
    {
      "hash": "sha256-2uc6VqkebTEx7maSsYaNBHzrAjAWTxcK34o3ZnaPZJc=",
      "url": "bootstrap-icons/icons/person-lock.svg"
    },
    {
      "hash": "sha256-/9mYgtYzSrjIbfpMfKRsCJmAjwfD44Ox7P05czR8Rbo=",
      "url": "bootstrap-icons/icons/person-plus-fill.svg"
    },
    {
      "hash": "sha256-p5t+s6jD6ixWlYTxNC95X9e42ISZiA6MZ9I67rAPNKU=",
      "url": "bootstrap-icons/icons/person-plus.svg"
    },
    {
      "hash": "sha256-8DgeCEMv6kvw3Iq+hYWIMeEa5rpEHcln3HFiABSxo2s=",
      "url": "bootstrap-icons/icons/person-raised-hand.svg"
    },
    {
      "hash": "sha256-7d1shdMbwNUVBw7asz6pQxXI1j9MxjlkBgZXt41bn0U=",
      "url": "bootstrap-icons/icons/person-rolodex.svg"
    },
    {
      "hash": "sha256-jtLVP/JzWi75xHs9BtVrJEiNwMeUl62cw8rfOjcQsnE=",
      "url": "bootstrap-icons/icons/person-slash.svg"
    },
    {
      "hash": "sha256-1a0Y3Fl7b314frfC1QJenc5EUN59UCjpMhALaQ3oMSk=",
      "url": "bootstrap-icons/icons/person-square.svg"
    },
    {
      "hash": "sha256-P4Iqq4yR1ELshBGIkKl6/CJzohSW4BU097kyEKypqIA=",
      "url": "bootstrap-icons/icons/person-standing-dress.svg"
    },
    {
      "hash": "sha256-PufvqAkTLL19h6eR/m/OKXlzg2H8FtAdgyh+iZbsekM=",
      "url": "bootstrap-icons/icons/person-standing.svg"
    },
    {
      "hash": "sha256-+3HlDPHgCya3Ug1ZO0UmSKh7ImkX5dm+KviLW4YLaAM=",
      "url": "bootstrap-icons/icons/person-up.svg"
    },
    {
      "hash": "sha256-Z9w4QsFNUz+ErLnDh/i3QZpcYsf6Ngic0sJSE5mbGV0=",
      "url": "bootstrap-icons/icons/person-vcard-fill.svg"
    },
    {
      "hash": "sha256-HFIr5rlfpY7udKYswCdJkPJLxLUwWhvbThnl/tp3h3U=",
      "url": "bootstrap-icons/icons/person-vcard.svg"
    },
    {
      "hash": "sha256-+fU/SUiPQ5wWVTwAU6cp2uXXmHxrLPR6SVSCWeC6Va4=",
      "url": "bootstrap-icons/icons/person-video.svg"
    },
    {
      "hash": "sha256-oKk+8oaFA2i6lNKK5u7KkDNa9M4+99HJURMOxPL+Ft4=",
      "url": "bootstrap-icons/icons/person-video2.svg"
    },
    {
      "hash": "sha256-epPf3rDFGBqP4QMoLOnmuPHSlx2pk41rBdufsWFvJU8=",
      "url": "bootstrap-icons/icons/person-video3.svg"
    },
    {
      "hash": "sha256-1K6lHZ2Wps+FXjnr10AM+x7xjEPGR9e4CAztfPkny/4=",
      "url": "bootstrap-icons/icons/person-walking.svg"
    },
    {
      "hash": "sha256-Cq08cpb59a1CaGc6ucb60k/oA6dgzCUH1sR06gwMMPA=",
      "url": "bootstrap-icons/icons/person-wheelchair.svg"
    },
    {
      "hash": "sha256-gNxvOYOQpA9uiGQcgcFW+qzRFhRL0aYmDw2r36Nqy8k=",
      "url": "bootstrap-icons/icons/person-workspace.svg"
    },
    {
      "hash": "sha256-UJVdFk+yjBGkhNjXwQ6Kx3PWBl/DK/SiB55u+LpYRBc=",
      "url": "bootstrap-icons/icons/person-x-fill.svg"
    },
    {
      "hash": "sha256-tgGkIK3HQZA46jBO31VYQEqucP6Jv5/zgIxGWij3CFs=",
      "url": "bootstrap-icons/icons/person-x.svg"
    },
    {
      "hash": "sha256-4HHbG/yQvTC8Yh0U6bHJtdGVuTLXAn1l4eMPvZ/79sk=",
      "url": "bootstrap-icons/icons/person.svg"
    },
    {
      "hash": "sha256-E9fKraijdwUBdkQjVc2adwHc1cTYH5bLrCW/JLuFcfo=",
      "url": "bootstrap-icons/icons/phone-fill.svg"
    },
    {
      "hash": "sha256-l8McEG6ypV7voZ6i6reOz/fUXe3PlxJg5thsr9vQ9QQ=",
      "url": "bootstrap-icons/icons/phone-flip.svg"
    },
    {
      "hash": "sha256-x79ady17GZXT3zBl42u5s8CIkg6O5hakpRpHvURxG2Q=",
      "url": "bootstrap-icons/icons/phone-landscape-fill.svg"
    },
    {
      "hash": "sha256-LZEUv31G75sNANV8MM3x6tCVgCvbE27jbT3M42K8SnM=",
      "url": "bootstrap-icons/icons/phone-landscape.svg"
    },
    {
      "hash": "sha256-QUMoVooDuJXCkR/6+RjYIwNCF28JWCbZv+Ub0cxKVAk=",
      "url": "bootstrap-icons/icons/phone-vibrate-fill.svg"
    },
    {
      "hash": "sha256-w31wGtXIbQzHGrdink2uSYpXpLg1HFhDGO4sZBTdFc8=",
      "url": "bootstrap-icons/icons/phone-vibrate.svg"
    },
    {
      "hash": "sha256-a5T4HJdEAA+hOUZYO7DDGqj8BSWrBGUcvOjgOaeVHgs=",
      "url": "bootstrap-icons/icons/phone.svg"
    },
    {
      "hash": "sha256-6ikTLz+CJ5TY1u3kCu/Ql/MlM1EGft/8vofoz/0e9mQ=",
      "url": "bootstrap-icons/icons/pie-chart-fill.svg"
    },
    {
      "hash": "sha256-BwPLzmYSKwQG2KTmetSDuJZDWVZ8GXUADzmPdmL4av8=",
      "url": "bootstrap-icons/icons/pie-chart.svg"
    },
    {
      "hash": "sha256-DcMsydFvl7UiTWdJTkBOooFKWWazDsJfHk/EJp0Bluo=",
      "url": "bootstrap-icons/icons/piggy-bank-fill.svg"
    },
    {
      "hash": "sha256-6cMrFVVJ0Tbto3oZQ6ndxyFpNtZIzcKUIaXLlaw49/g=",
      "url": "bootstrap-icons/icons/piggy-bank.svg"
    },
    {
      "hash": "sha256-is9KJ1m/ImH7d/ZS25a8LyvHuzN1WC6emusBJ5l1UTc=",
      "url": "bootstrap-icons/icons/pin-angle-fill.svg"
    },
    {
      "hash": "sha256-/geSM0IR/NfDvtJ65s/+Leu6esJO1KaEEk8hqy73W94=",
      "url": "bootstrap-icons/icons/pin-angle.svg"
    },
    {
      "hash": "sha256-fHU17Dv2+nInTepb5UFUqUXyFHsrqIsQyPWwZeO/l6I=",
      "url": "bootstrap-icons/icons/pin-fill.svg"
    },
    {
      "hash": "sha256-5l3GV9Taxw4cCr10XmDUpWAMns6r+zL0RaoQ3+IeMSo=",
      "url": "bootstrap-icons/icons/pin-map-fill.svg"
    },
    {
      "hash": "sha256-SYe3PFZBHTCimQ49VK59cC6fCOATNJKeE4gsBzZX7eo=",
      "url": "bootstrap-icons/icons/pin-map.svg"
    },
    {
      "hash": "sha256-CzI1IoMQ1RwdGS1OuauBQ6HNuopatY9s7mslYCnTkIA=",
      "url": "bootstrap-icons/icons/pin.svg"
    },
    {
      "hash": "sha256-CD8Sci7T4H9WDhVv1rg2mF7m3tkERpmNd1SsLgke7Tw=",
      "url": "bootstrap-icons/icons/pinterest.svg"
    },
    {
      "hash": "sha256-8QpKXfftOs76nnCXLpKsLVSJkx0mDYSXFVNGCasII5o=",
      "url": "bootstrap-icons/icons/pip-fill.svg"
    },
    {
      "hash": "sha256-AxwcMIpkfArV0yHLlb968lQJbLwVxSxmg5R+pg4l5R8=",
      "url": "bootstrap-icons/icons/pip.svg"
    },
    {
      "hash": "sha256-wmn/Kc/Z0x+y1Xhtrq9vHVtdk3vFTCUslhqeCCFOHrg=",
      "url": "bootstrap-icons/icons/play-btn-fill.svg"
    },
    {
      "hash": "sha256-9LC5UTiuH7/lPiWBzkKpa7IIo+aeNtLRLRt0ZDxQCrA=",
      "url": "bootstrap-icons/icons/play-btn.svg"
    },
    {
      "hash": "sha256-QosrHTsXNqgEjXbR0bKopufL7iXmrPHnvRcHn+Msw+g=",
      "url": "bootstrap-icons/icons/play-circle-fill.svg"
    },
    {
      "hash": "sha256-bBa0mIUusDGnkyIaXI4vrcS5bu3PaQe6EeKMsoV0SpM=",
      "url": "bootstrap-icons/icons/play-circle.svg"
    },
    {
      "hash": "sha256-rouqgVyKoR7tYNQb645iuaUcq2INMmRweXnhGMpXZJg=",
      "url": "bootstrap-icons/icons/play-fill.svg"
    },
    {
      "hash": "sha256-JtJ7LCSii7dMqWcZWIKgkfSnyJ2LbVbrzkRrXYaMmFE=",
      "url": "bootstrap-icons/icons/play.svg"
    },
    {
      "hash": "sha256-45WzUs3KDrjSjE9fCj+7Uc1CX4RHVUC2ZumbQPCj+ho=",
      "url": "bootstrap-icons/icons/playstation.svg"
    },
    {
      "hash": "sha256-XYeFzAmtgNlIK9s8T/UWxb39hs1ToZNdeKom37ICNeM=",
      "url": "bootstrap-icons/icons/plug-fill.svg"
    },
    {
      "hash": "sha256-ciW3cR3vPpjF9HoWO9GBZX4apEZkGKgB59ImHU2q4V4=",
      "url": "bootstrap-icons/icons/plug.svg"
    },
    {
      "hash": "sha256-0q4+nv/N9ArLKpyef9eIUpGvYAumPaIqJk70Ny5j+eA=",
      "url": "bootstrap-icons/icons/plugin.svg"
    },
    {
      "hash": "sha256-mp1sZ1A59gVyF61VoYRWIuWLpBi4SWhFT3VgWQBuG8Y=",
      "url": "bootstrap-icons/icons/plus-circle-dotted.svg"
    },
    {
      "hash": "sha256-PIckzjZ2bCd6UOJ9W03kA97MtbRUR9t0DG8p40XrFpQ=",
      "url": "bootstrap-icons/icons/plus-circle-fill.svg"
    },
    {
      "hash": "sha256-VKwLEtF9TwyH37O+rVRa1BJjveTPjZYCY7/TqcZBmO4=",
      "url": "bootstrap-icons/icons/plus-circle.svg"
    },
    {
      "hash": "sha256-jCrjlulRDI7ALc0NP64wHm6pPt34fXV2v3fBuYJbg0A=",
      "url": "bootstrap-icons/icons/plus-lg.svg"
    },
    {
      "hash": "sha256-cuPdPbopmb9lzP25XonFWk3kyWW6sV1+lGH65DyIFqw=",
      "url": "bootstrap-icons/icons/plus-slash-minus.svg"
    },
    {
      "hash": "sha256-0FGMZ6JVYZkgq2RCIYj0urbBFC0nVlNWN3JMilZ8eo4=",
      "url": "bootstrap-icons/icons/plus-square-dotted.svg"
    },
    {
      "hash": "sha256-QNY6yu7J3v+6kRJFxuZgeuv6dohuP5pe15xWP83eXzs=",
      "url": "bootstrap-icons/icons/plus-square-fill.svg"
    },
    {
      "hash": "sha256-Ubg67PvfHrkiAwpE55kQxgJX4TfrllxCFjCKRFKdtq4=",
      "url": "bootstrap-icons/icons/plus-square.svg"
    },
    {
      "hash": "sha256-LJh0Ceqc3tT1nmf8hzpy/j6xuswXFgoH8lDAmXA2RjA=",
      "url": "bootstrap-icons/icons/plus.svg"
    },
    {
      "hash": "sha256-iWQpVhzedjin/wOY5nh7xjscapEDVeRRRhKW35dX6Po=",
      "url": "bootstrap-icons/icons/postage-fill.svg"
    },
    {
      "hash": "sha256-DNmSLD7daFYR1aSDxnrRlguQV2PqVxxRO1vmSdLqpo4=",
      "url": "bootstrap-icons/icons/postage-heart-fill.svg"
    },
    {
      "hash": "sha256-Gb6HtWuQUfRbesDq6CZg7XY+UZp9bDlr4l9MbDxIEeM=",
      "url": "bootstrap-icons/icons/postage-heart.svg"
    },
    {
      "hash": "sha256-JkcypPkp5r7oDcCZQpX/JmL7Iv0SIQ5l4M1Gwb37grs=",
      "url": "bootstrap-icons/icons/postage.svg"
    },
    {
      "hash": "sha256-uoWijaDGKbN8KC5UTuC7ursYuudPO8YrZLwCEuWpzXQ=",
      "url": "bootstrap-icons/icons/postcard-fill.svg"
    },
    {
      "hash": "sha256-5jBCb2eqHirC3YnlQINz135wgVJ0DAiINrUmy9+8Xkc=",
      "url": "bootstrap-icons/icons/postcard-heart-fill.svg"
    },
    {
      "hash": "sha256-aiIL+kqJB3Ab2/uYZDjFKlWx1nHOvENG1seV3h66vs0=",
      "url": "bootstrap-icons/icons/postcard-heart.svg"
    },
    {
      "hash": "sha256-mKw1PkMOlY5/vZCN7otuqgGhrlPZDUxDT0B9uCcdzFo=",
      "url": "bootstrap-icons/icons/postcard.svg"
    },
    {
      "hash": "sha256-q5MzMKfQGgu+L5SLXXt6rfwAJY/Bc/f20tsJHYj4bis=",
      "url": "bootstrap-icons/icons/power.svg"
    },
    {
      "hash": "sha256-3PCbKaXdVniSIfqHUvWTU96TI74lFVxhHgJ4GS/jJfg=",
      "url": "bootstrap-icons/icons/prescription.svg"
    },
    {
      "hash": "sha256-9bDiEUaJFs+WLlp0YaV3SWWkLDKOEWPuG+pFsSE/jak=",
      "url": "bootstrap-icons/icons/prescription2.svg"
    },
    {
      "hash": "sha256-VwU5ICKfV2eLKhtJBLUJDXfthyMzoDfdshlsH0cGCrk=",
      "url": "bootstrap-icons/icons/printer-fill.svg"
    },
    {
      "hash": "sha256-aWzqo4kyW4ZoT3IsNKU+u9NjGvKkwJ+FvlRCQYHxFPs=",
      "url": "bootstrap-icons/icons/printer.svg"
    },
    {
      "hash": "sha256-mzmcK89Puy2IhPLqDhArkNy+FlDVJA+uPtuwuzKg2gg=",
      "url": "bootstrap-icons/icons/projector-fill.svg"
    },
    {
      "hash": "sha256-7/VEXqUB7C0Vcaoc3UW39MH0Wa8aEXQ7fck2AvI/MeQ=",
      "url": "bootstrap-icons/icons/projector.svg"
    },
    {
      "hash": "sha256-C8Z/lCk5iKVsZyQ+BJo3qllc2ENIob3rRcfYjws29g4=",
      "url": "bootstrap-icons/icons/puzzle-fill.svg"
    },
    {
      "hash": "sha256-6Nm1Ju6tPsVbsUerolb6adEzulOjP2SbA7D0KSOEFD0=",
      "url": "bootstrap-icons/icons/puzzle.svg"
    },
    {
      "hash": "sha256-WB+ss8Mb9nC3m76aMgoA/Fgeau28wE0+PQ1mHFH8YpA=",
      "url": "bootstrap-icons/icons/qr-code-scan.svg"
    },
    {
      "hash": "sha256-lFCjBoi+zWuMNRpYs79SGWqvfJnfuqUGBCiP+0tdy9g=",
      "url": "bootstrap-icons/icons/qr-code.svg"
    },
    {
      "hash": "sha256-IqPWYCM6sBrO8oufe9pr47K8PIjSmabKvGTz2aqRZLI=",
      "url": "bootstrap-icons/icons/question-circle-fill.svg"
    },
    {
      "hash": "sha256-bsAJUTno5vNeR9TeGWiEbVfzAGoNMHRlFjfgvMgMjJw=",
      "url": "bootstrap-icons/icons/question-circle.svg"
    },
    {
      "hash": "sha256-VhD8KtmfaBT6d2DtuVSYQnoAvX4j5vokz63M2t2Uyr4=",
      "url": "bootstrap-icons/icons/question-diamond-fill.svg"
    },
    {
      "hash": "sha256-idxZimDSLcBOlHRh0jRRwpIfxZu+nhC9kDteYSkHvks=",
      "url": "bootstrap-icons/icons/question-diamond.svg"
    },
    {
      "hash": "sha256-LicMc+y/i/rLzB2iVuAgLRMOKI2sVuwe6w0JUwv+A9M=",
      "url": "bootstrap-icons/icons/question-lg.svg"
    },
    {
      "hash": "sha256-lRCxpFnrL8A9s2fzp2/LBfUDY0d6ErSr1+ppAl4dU1w=",
      "url": "bootstrap-icons/icons/question-octagon-fill.svg"
    },
    {
      "hash": "sha256-hNyHZd9/CIgmCDmZUsorYEtQs6ygcUtt+Vfhua5YniQ=",
      "url": "bootstrap-icons/icons/question-octagon.svg"
    },
    {
      "hash": "sha256-DUyNd1Z55C/5T2Xlf2cuR0VW2IFRACngS/wxE/dsXA8=",
      "url": "bootstrap-icons/icons/question-square-fill.svg"
    },
    {
      "hash": "sha256-RodtNo1dtTxObK+a+FTxovwfMa8xNv4up61ZDWobCnA=",
      "url": "bootstrap-icons/icons/question-square.svg"
    },
    {
      "hash": "sha256-hADOgPPV7ktF+GA75SxXrX9pNigSy/7racVBElW0yLw=",
      "url": "bootstrap-icons/icons/question.svg"
    },
    {
      "hash": "sha256-oDeLVNgqB1TUiQOTcJJph1yn8+5vEZjXXjThCWJ97fg=",
      "url": "bootstrap-icons/icons/quora.svg"
    },
    {
      "hash": "sha256-nP02RX/2BHzt9RAw6tz7ghg/MkD2JnZk/mtsJRF4guI=",
      "url": "bootstrap-icons/icons/quote.svg"
    },
    {
      "hash": "sha256-SJ+hgqnayrlKFPv2RlffV5teJWgAbRVxi0QB1HlpEIY=",
      "url": "bootstrap-icons/icons/r-circle-fill.svg"
    },
    {
      "hash": "sha256-+kFfOYXG5y9TOPmYCWBxjkUBTHlzEE4DwxE9xaoAI/M=",
      "url": "bootstrap-icons/icons/r-circle.svg"
    },
    {
      "hash": "sha256-0sXi2reyi68xTLYSdOESnOE7dietr8Q6S6tu4IYy/yc=",
      "url": "bootstrap-icons/icons/r-square-fill.svg"
    },
    {
      "hash": "sha256-nP8NPK8MgjLNQovCtJ1tbWsns6uGebxLS9CW41Vkst4=",
      "url": "bootstrap-icons/icons/r-square.svg"
    },
    {
      "hash": "sha256-NR4qWqUGqCop3FnPC+5RT7ZtGIChbG0trqRy3OVZWOc=",
      "url": "bootstrap-icons/icons/radar.svg"
    },
    {
      "hash": "sha256-iiZUmZib7oco/jHD1yqO6KI7B6Wnp4uEoO7d05LnQiI=",
      "url": "bootstrap-icons/icons/radioactive.svg"
    },
    {
      "hash": "sha256-+Z4DhohAkGEdhiadLVUmEnnesRhbtLIwjbaDHVEhU7Y=",
      "url": "bootstrap-icons/icons/rainbow.svg"
    },
    {
      "hash": "sha256-VItOhc6Ot5HSlCAYzV6cQoe1oL2i1g6X6RovLOv4Ffs=",
      "url": "bootstrap-icons/icons/receipt-cutoff.svg"
    },
    {
      "hash": "sha256-JT0wKmgpMsehyy7zLSnTNfyd+LlcgVTyuor8RbkQ95A=",
      "url": "bootstrap-icons/icons/receipt.svg"
    },
    {
      "hash": "sha256-1lcev7IQCghTRQGTz8uXkWAhw1v/5txOBmoWjUCiNj0=",
      "url": "bootstrap-icons/icons/reception-0.svg"
    },
    {
      "hash": "sha256-gdcwKoAw0IqmwDwfegfmHX+PHiikoIzzq2a6EPrfu5o=",
      "url": "bootstrap-icons/icons/reception-1.svg"
    },
    {
      "hash": "sha256-Npx4OP/dJ2J39NDgrbKHomUi9V1hZX6Ee7/3RBcDFe8=",
      "url": "bootstrap-icons/icons/reception-2.svg"
    },
    {
      "hash": "sha256-VdNZt8y127oWnQVDC8io8ZDSooybHF7be9wfK7kQsX0=",
      "url": "bootstrap-icons/icons/reception-3.svg"
    },
    {
      "hash": "sha256-LUBDjh9HwDnAATwK/NK8Qf0rAhbh2B5Hzp8oYTi8HT8=",
      "url": "bootstrap-icons/icons/reception-4.svg"
    },
    {
      "hash": "sha256-opNQCX3OZQylmzQUdBUXjI49rGLrU3KZDB+8+SQFQ6Y=",
      "url": "bootstrap-icons/icons/record-btn-fill.svg"
    },
    {
      "hash": "sha256-9NXo1b1zkaw9X+F6pcFKdzX1gN77WkKNkYqA6tcrhEs=",
      "url": "bootstrap-icons/icons/record-btn.svg"
    },
    {
      "hash": "sha256-NVI8EwcZVC8kll6M07mOsjzfO7VmTGb0mjLzcltxfVY=",
      "url": "bootstrap-icons/icons/record-circle-fill.svg"
    },
    {
      "hash": "sha256-oXrWaaSoAo0fZgY5gE39Sy+slN9+2LU1K8UElKaZfio=",
      "url": "bootstrap-icons/icons/record-circle.svg"
    },
    {
      "hash": "sha256-/lgbVLcIVPBpPgIZrcO4TtSokPoUZBopDOLVE9L+woI=",
      "url": "bootstrap-icons/icons/record-fill.svg"
    },
    {
      "hash": "sha256-9UQoc7sjmA4FfrzQdYbDwBhFWoLg0Q7nnzJjySp4wwU=",
      "url": "bootstrap-icons/icons/record.svg"
    },
    {
      "hash": "sha256-ZZX+eZ0IAOnv4rVM7m2OI8SbksOpDfOw2tXhl6xXMpA=",
      "url": "bootstrap-icons/icons/record2-fill.svg"
    },
    {
      "hash": "sha256-K6aGWXQhxwhS4pioxzlfZSrrng1wl3mOzO3+2Rncy54=",
      "url": "bootstrap-icons/icons/record2.svg"
    },
    {
      "hash": "sha256-mt+xbrSXPjI0vZFrXBx1X0JWpeDjHWbPCwdtMWYrYCQ=",
      "url": "bootstrap-icons/icons/recycle.svg"
    },
    {
      "hash": "sha256-+oZ8ToWH6OJ0pChx8WhiUlCqersebvu5zsUXi3uuOj4=",
      "url": "bootstrap-icons/icons/reddit.svg"
    },
    {
      "hash": "sha256-IIkKgG3S0zFltBJms82cNzBcl+Syq6Oq/mtX9ZwjYTw=",
      "url": "bootstrap-icons/icons/regex.svg"
    },
    {
      "hash": "sha256-FuOctThvYtA2f0W7US8pYbp1pVyj6cUBhmEjOFIAkug=",
      "url": "bootstrap-icons/icons/repeat-1.svg"
    },
    {
      "hash": "sha256-j12NIOnVLJUwWLgEO5F3HY+82ZeHUVR5mB1oZNfqujg=",
      "url": "bootstrap-icons/icons/repeat.svg"
    },
    {
      "hash": "sha256-1qgMkPaGz5B2oRfcRO1q6Fo/VKcgfA9iCtot5wXIzW0=",
      "url": "bootstrap-icons/icons/reply-all-fill.svg"
    },
    {
      "hash": "sha256-V9LFDLr5/Br7F9+fTfy0+l9TNt6Ur/dJeHuqBHAygCo=",
      "url": "bootstrap-icons/icons/reply-all.svg"
    },
    {
      "hash": "sha256-GQEqNUQPb36PE2fUOtLWZslvyhFQdAFo93X3wYtSo0o=",
      "url": "bootstrap-icons/icons/reply-fill.svg"
    },
    {
      "hash": "sha256-IEgcJ5kOiQGglBwrH7z/PBM46ov/70H4QLC4grezgKM=",
      "url": "bootstrap-icons/icons/reply.svg"
    },
    {
      "hash": "sha256-4wwu7UO4EQm7lx8QjimysyykoSWCkNbqhCdcng3pRoE=",
      "url": "bootstrap-icons/icons/rewind-btn-fill.svg"
    },
    {
      "hash": "sha256-KBMOBgA2dNR3XLLRIU682g1jTi85eUGiJr3mKBsCP/k=",
      "url": "bootstrap-icons/icons/rewind-btn.svg"
    },
    {
      "hash": "sha256-xrnSePpXwH5PF46rGpbQzR/YFirI/2q9AmXgbzMWCAE=",
      "url": "bootstrap-icons/icons/rewind-circle-fill.svg"
    },
    {
      "hash": "sha256-SkW5qdNSBVeJvTfGfWmYH/7B6BIS6cI7u1z4Vo/t/Ho=",
      "url": "bootstrap-icons/icons/rewind-circle.svg"
    },
    {
      "hash": "sha256-0K//6tXuByv73SN8kLPwXoL4KnPXSaJsEOoAT+pcFUE=",
      "url": "bootstrap-icons/icons/rewind-fill.svg"
    },
    {
      "hash": "sha256-HHu4bWPLx8Z4nSp77kj8FTm3hu9fQJk0hXIW08Q82zw=",
      "url": "bootstrap-icons/icons/rewind.svg"
    },
    {
      "hash": "sha256-xJ6AZD9IEZ352TY9Tjwh94weSQ+yYp1gsrJxcWQQ7GQ=",
      "url": "bootstrap-icons/icons/robot.svg"
    },
    {
      "hash": "sha256-zM02KWYmGG7nO2o+vNQ2+A9L2syzGGGwYWX6rnk/xRE=",
      "url": "bootstrap-icons/icons/rocket-fill.svg"
    },
    {
      "hash": "sha256-Gu9c2wQheFbUwCSRlg0472B5bis9hyrmOeJZGmub2xs=",
      "url": "bootstrap-icons/icons/rocket-takeoff-fill.svg"
    },
    {
      "hash": "sha256-JWoFyywkEf/ZK7xgDNy+q1FKmoD+qIhz5apKONUtrMY=",
      "url": "bootstrap-icons/icons/rocket-takeoff.svg"
    },
    {
      "hash": "sha256-CQaWPvuOoI4Omarbn1RrYTAe/8M1xJsT8y4ZdmI6Qhk=",
      "url": "bootstrap-icons/icons/rocket.svg"
    },
    {
      "hash": "sha256-FvmTqNT+Pks5z4egbeGpLdVGysi6OlUbmSh5ZdjXUkU=",
      "url": "bootstrap-icons/icons/router-fill.svg"
    },
    {
      "hash": "sha256-W8fXxqi1M05YqAAsydWzGPHfy6HMiys9Fm1r+5EFTyY=",
      "url": "bootstrap-icons/icons/router.svg"
    },
    {
      "hash": "sha256-qzANUt8tT0Fnz1xK82XHImRB6Q2KrjvlHnO7QM+DEfc=",
      "url": "bootstrap-icons/icons/rss-fill.svg"
    },
    {
      "hash": "sha256-4agzkAizULa2HHFiMgXgLW6JMYSXSX65GLg1sH7HRtk=",
      "url": "bootstrap-icons/icons/rss.svg"
    },
    {
      "hash": "sha256-i4MLNy8KBIhO9fgNuhkJkVbZfgyGWTkAKILmMXN+rQI=",
      "url": "bootstrap-icons/icons/rulers.svg"
    },
    {
      "hash": "sha256-y1ltNasbgN6rE8nlLrIJf+yVe5Owk8aPe01zHT47Po4=",
      "url": "bootstrap-icons/icons/safe-fill.svg"
    },
    {
      "hash": "sha256-uRcCSeXDkPw4BETS2L4RdLOlZAazjhziY/73RlR7KUQ=",
      "url": "bootstrap-icons/icons/safe.svg"
    },
    {
      "hash": "sha256-KHAtC5GpJ7YlHkrMap6o/bk8fM71gysoHyWv8dtcPms=",
      "url": "bootstrap-icons/icons/safe2-fill.svg"
    },
    {
      "hash": "sha256-TarlPgC2cKQICb2EKR/mL878Cg8x8NUzOBIojGWWhPs=",
      "url": "bootstrap-icons/icons/safe2.svg"
    },
    {
      "hash": "sha256-vS9fT8AqK6wM5Kl1Y53Dt42KTwlvgOwrwLc+LstXNcY=",
      "url": "bootstrap-icons/icons/save-fill.svg"
    },
    {
      "hash": "sha256-37KA52TLuRoxCtLFBLRMO3Oez4DITL4pNW97Lu8bEAE=",
      "url": "bootstrap-icons/icons/save.svg"
    },
    {
      "hash": "sha256-hVjmw2lXXDSOIzKi18sRBXOJxuGWp8YLbyGrEnQwczk=",
      "url": "bootstrap-icons/icons/save2-fill.svg"
    },
    {
      "hash": "sha256-GrMfc4JY6HKKwJLXKcJ3KqBltWMYXbee7w4TF6ymJrU=",
      "url": "bootstrap-icons/icons/save2.svg"
    },
    {
      "hash": "sha256-dxlZPD2XDWEGP8Jekd1jfpTyvSoRpl1gxB9d0jx+SCo=",
      "url": "bootstrap-icons/icons/scissors.svg"
    },
    {
      "hash": "sha256-0uCaJZwQw/4SQ8BJoNjMmYSviBMbZOYSln/IGZ3B6dE=",
      "url": "bootstrap-icons/icons/scooter.svg"
    },
    {
      "hash": "sha256-Ik/hlIDqG9Q0829r3FM/UABhZu3oUF068JOL2q7t/0k=",
      "url": "bootstrap-icons/icons/screwdriver.svg"
    },
    {
      "hash": "sha256-80/wQf4LkIQSNNQ26eC/G03QtG4ZL095c1ocT+YIjug=",
      "url": "bootstrap-icons/icons/sd-card-fill.svg"
    },
    {
      "hash": "sha256-Rc/BWr27rXyRdo4pGt3Fl7SjDCkXtIBY3ryjhjY43kg=",
      "url": "bootstrap-icons/icons/sd-card.svg"
    },
    {
      "hash": "sha256-Li8fqZab3spBajAAVfxXy4VjF6uTDmzYFwxgS5VsFTU=",
      "url": "bootstrap-icons/icons/search-heart-fill.svg"
    },
    {
      "hash": "sha256-urS4t0TI006dgcklbXdGGW1Z8lbsrY7LswnHrnEdXLA=",
      "url": "bootstrap-icons/icons/search-heart.svg"
    },
    {
      "hash": "sha256-3W9HH0hyQiff3nLWJTqYAj1Lc00GuQo9kyz2mOOqock=",
      "url": "bootstrap-icons/icons/search.svg"
    },
    {
      "hash": "sha256-qJJIHl/8PQwJZBJKl4m08IahBEORq2YPPLUwEhVUs8A=",
      "url": "bootstrap-icons/icons/segmented-nav.svg"
    },
    {
      "hash": "sha256-kSGskze2mAFpb4pdnO7MrpIfZE9gPox1i/TJKP29FNk=",
      "url": "bootstrap-icons/icons/send-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-vsYB5vyAvEiFiyX75qKJbZlXEUAQ58tVBhBh5fC3hzw=",
      "url": "bootstrap-icons/icons/send-arrow-down.svg"
    },
    {
      "hash": "sha256-aH0Fqd3NqFtUn6HSZQ4v60Y5XWhajd3JWSXcqv5Zjw4=",
      "url": "bootstrap-icons/icons/send-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-cY+E1MB9s0Qgh3mzmndpa2o59xsg8pOmZRV453qV924=",
      "url": "bootstrap-icons/icons/send-arrow-up.svg"
    },
    {
      "hash": "sha256-YtZKDIgtCM8drQQ7h68My+/7kKxz/RAjtjc+xRxlIGc=",
      "url": "bootstrap-icons/icons/send-check-fill.svg"
    },
    {
      "hash": "sha256-eep9ZYTa1wJRtuo8NeyrJ1PVeGiPL7w4yDUUtJcLjXA=",
      "url": "bootstrap-icons/icons/send-check.svg"
    },
    {
      "hash": "sha256-Hz42yyuVOhzi3/zznVDWWGbwKO68zkPJIT+oAyZ9cH0=",
      "url": "bootstrap-icons/icons/send-dash-fill.svg"
    },
    {
      "hash": "sha256-PjrPpTLrkcN87aNJSymnMGobSr3VPBeulAoq05l/b/U=",
      "url": "bootstrap-icons/icons/send-dash.svg"
    },
    {
      "hash": "sha256-LcIObk7oJK3n3EgzLXLqGlLCUL6mG9Cr2jzgFm6psw0=",
      "url": "bootstrap-icons/icons/send-exclamation-fill.svg"
    },
    {
      "hash": "sha256-GMwLm1v1R+mpiPg2sc+5NLVB86NWBQqxG5ruNqi1Yr0=",
      "url": "bootstrap-icons/icons/send-exclamation.svg"
    },
    {
      "hash": "sha256-LQOm9pRpn3B23BMg8P/FJr/TuroRS5NKphmwdVl2N5E=",
      "url": "bootstrap-icons/icons/send-fill.svg"
    },
    {
      "hash": "sha256-Q+hsL+z4wlMoyUJ9vhA8QYEio8DLhsBriNGjzG5aqXE=",
      "url": "bootstrap-icons/icons/send-plus-fill.svg"
    },
    {
      "hash": "sha256-ADc3vWDsT9y5fbPOd/7rfesy9rbXXAzouwfXwc7uoV8=",
      "url": "bootstrap-icons/icons/send-plus.svg"
    },
    {
      "hash": "sha256-MaSzLatcdowPeXvIuiyh1oDbMygTwNfEREkaJ5DDF/s=",
      "url": "bootstrap-icons/icons/send-slash-fill.svg"
    },
    {
      "hash": "sha256-5kH/Yok9fUMgZn657xWxdkUjy2+qUCoN189I80ErH+I=",
      "url": "bootstrap-icons/icons/send-slash.svg"
    },
    {
      "hash": "sha256-JQ1ldUNtsiwzipppaLURXK7Q9HXXn+XuFdOdie/T6xc=",
      "url": "bootstrap-icons/icons/send-x-fill.svg"
    },
    {
      "hash": "sha256-BxxZqxryMrC5TRv3FB73rguoc5i2cvsQul/2Gr03hug=",
      "url": "bootstrap-icons/icons/send-x.svg"
    },
    {
      "hash": "sha256-NSKSEGo/9jxNCq6bUApYdCBpRN3RdkhUzZONptW5HV4=",
      "url": "bootstrap-icons/icons/send.svg"
    },
    {
      "hash": "sha256-atDLEARNziZzvrAuAV/cxnzQWrYvRrAqxkiu/ryjAzs=",
      "url": "bootstrap-icons/icons/server.svg"
    },
    {
      "hash": "sha256-15eu4AoFHks5H+/wlccmMSKIzYz7KXUYNmzhgLFK9SU=",
      "url": "bootstrap-icons/icons/shadows.svg"
    },
    {
      "hash": "sha256-xxtYRGJ3eH+CowrkQFjvka7ImC0U+VazOQNkphRiWmI=",
      "url": "bootstrap-icons/icons/share-fill.svg"
    },
    {
      "hash": "sha256-M4n5V7Go6Nq+ibG3bF19yvmbyiK9PSvbukmuicM56jM=",
      "url": "bootstrap-icons/icons/share.svg"
    },
    {
      "hash": "sha256-Qv+MP0pN8qZZPFPdvAywE3yGWuYjifVbIZ2ogebZXA4=",
      "url": "bootstrap-icons/icons/shield-check.svg"
    },
    {
      "hash": "sha256-CvFb0F79cmM6ruTKaMlfZSRuU52oe7xs0gZ9Ea1yS3o=",
      "url": "bootstrap-icons/icons/shield-exclamation.svg"
    },
    {
      "hash": "sha256-P8+mmobu2zewYhn4YRkKpxCwibDVCw5vIHE4v0yU0aE=",
      "url": "bootstrap-icons/icons/shield-fill-check.svg"
    },
    {
      "hash": "sha256-xwU98voO0F2y5Lka9dY1yhpwwd6bzW4m/G4EICTMTCE=",
      "url": "bootstrap-icons/icons/shield-fill-exclamation.svg"
    },
    {
      "hash": "sha256-fSg+rs+BPXAVy8OUpEYOxc/WRlRS/HUQ1BUjmbgEt5A=",
      "url": "bootstrap-icons/icons/shield-fill-minus.svg"
    },
    {
      "hash": "sha256-a+rWzGYGHB9nNY5iZ+ygyJpPzaJexOyOXsIxA/G8/QM=",
      "url": "bootstrap-icons/icons/shield-fill-plus.svg"
    },
    {
      "hash": "sha256-9ugNdl6r8GBj1j0/As/YGLoScnGNa3+i8sQu79dFPGA=",
      "url": "bootstrap-icons/icons/shield-fill-x.svg"
    },
    {
      "hash": "sha256-TeNwa6IyZw54C7PLUP0reCp9wz9vSYAqC03buoaZlf4=",
      "url": "bootstrap-icons/icons/shield-fill.svg"
    },
    {
      "hash": "sha256-zU7I+/vGvwVr452p3rK+GU27SvuK11+r8TdWaGXMBiA=",
      "url": "bootstrap-icons/icons/shield-lock-fill.svg"
    },
    {
      "hash": "sha256-MkFHsA3/ZVBfe2W2caMWViFhWPcRHx1Z/q808t2bSJ0=",
      "url": "bootstrap-icons/icons/shield-lock.svg"
    },
    {
      "hash": "sha256-T/jOMnPS/riLM7M6XvHMIemNTByfk3xB71z6nB0K7Xs=",
      "url": "bootstrap-icons/icons/shield-minus.svg"
    },
    {
      "hash": "sha256-AiPlojkUfhT/iPX8FdQ+rbsBQ3EPLYOSqpKUK3+Jif8=",
      "url": "bootstrap-icons/icons/shield-plus.svg"
    },
    {
      "hash": "sha256-VbOu5VdUpTpDpt3L/PW61dPhPJFNGF0UICpN2nM8CgE=",
      "url": "bootstrap-icons/icons/shield-shaded.svg"
    },
    {
      "hash": "sha256-/ypE4t6zMRfSQoLH3O+kxKiKMRMF03jECNsRl3ciH3c=",
      "url": "bootstrap-icons/icons/shield-slash-fill.svg"
    },
    {
      "hash": "sha256-NUPc0PzppyuTvRgiDftfXjiPXrzUMXwTTzog1hYA9ow=",
      "url": "bootstrap-icons/icons/shield-slash.svg"
    },
    {
      "hash": "sha256-oPckUsf88jM+nsM5nlBYROwC+VE5X4VWvt3PUFT1wEE=",
      "url": "bootstrap-icons/icons/shield-x.svg"
    },
    {
      "hash": "sha256-DzFgqgq81NSxljrREkRnoZyiqStp3nvI7AuxlyyIQQw=",
      "url": "bootstrap-icons/icons/shield.svg"
    },
    {
      "hash": "sha256-+AcGpqofeLeZqLQ5idvErRMrBmkk9zELCqKq7O5fMMs=",
      "url": "bootstrap-icons/icons/shift-fill.svg"
    },
    {
      "hash": "sha256-lRmf1A3XmmZky32GueKJwYNn1lMnYnK7CBb9ZgB72a0=",
      "url": "bootstrap-icons/icons/shift.svg"
    },
    {
      "hash": "sha256-j0uqnpvOexHnssgXlF8qB7Y+IxpqO9P1VDCyhB9f31o=",
      "url": "bootstrap-icons/icons/shop-window.svg"
    },
    {
      "hash": "sha256-ZXzpfh6XHRkC08nN3RUXQBRUwSTIsXzhlwllNmkC/OA=",
      "url": "bootstrap-icons/icons/shop.svg"
    },
    {
      "hash": "sha256-8QDvlPuNauQBKCgaDj3yN3abd++m/+823uHHXCXdm/Q=",
      "url": "bootstrap-icons/icons/shuffle.svg"
    },
    {
      "hash": "sha256-iYprZXK2ZBkb8aN80T3pvcOybKM2lLdek5XramVeK1c=",
      "url": "bootstrap-icons/icons/sign-dead-end-fill.svg"
    },
    {
      "hash": "sha256-vzVQ+qsvHKrZw9n6SMYUm/ttpFKKNSWk1yDzKvz4k3Q=",
      "url": "bootstrap-icons/icons/sign-dead-end.svg"
    },
    {
      "hash": "sha256-kgsguiwbzjOO/hDxq0yxKXTSXky+IZcKnL7Knx57Utg=",
      "url": "bootstrap-icons/icons/sign-do-not-enter-fill.svg"
    },
    {
      "hash": "sha256-tCs07btMsEdp/hzCFVwcq0apnu/rH5wOx54Y+LIJZNo=",
      "url": "bootstrap-icons/icons/sign-do-not-enter.svg"
    },
    {
      "hash": "sha256-B0AOcuoFETNs/vWHCP8VEHE2ajwa9WRb4DdyrDD2avI=",
      "url": "bootstrap-icons/icons/sign-intersection-fill.svg"
    },
    {
      "hash": "sha256-VWIh/zP8nDdYjcvYoUkNRok7Iy9z5pN0o09LTHWlU0A=",
      "url": "bootstrap-icons/icons/sign-intersection-side-fill.svg"
    },
    {
      "hash": "sha256-A5/NAY/jl6eEkAM/o0w/hN0QpssUyLhaTVkt8jmoWJ0=",
      "url": "bootstrap-icons/icons/sign-intersection-side.svg"
    },
    {
      "hash": "sha256-XeI60WSWuifgYnB8j0QtPGAAemiml9UsLhTW7/GHrWQ=",
      "url": "bootstrap-icons/icons/sign-intersection-t-fill.svg"
    },
    {
      "hash": "sha256-WjWnI2WgbnXdlP8Y7p/A0r10QgCDH5cfk7kcFJPjbz4=",
      "url": "bootstrap-icons/icons/sign-intersection-t.svg"
    },
    {
      "hash": "sha256-8paV+sXZkdwDkJhPIhv3Jz+TxGMvgvf4acnI83z92RI=",
      "url": "bootstrap-icons/icons/sign-intersection-y-fill.svg"
    },
    {
      "hash": "sha256-11sxfT5hGSHKx9Ma4W40PoJUgfbaOPqZMe1aE6ZKoaA=",
      "url": "bootstrap-icons/icons/sign-intersection-y.svg"
    },
    {
      "hash": "sha256-Z/zutdvIhye7OzBXwUNkDP03+IA6+Q2x3y+qcSTpauU=",
      "url": "bootstrap-icons/icons/sign-intersection.svg"
    },
    {
      "hash": "sha256-z87PTZGAQOgtvm5BrK+Pv3clJCaCfGaP7grGRSHAi0I=",
      "url": "bootstrap-icons/icons/sign-merge-left-fill.svg"
    },
    {
      "hash": "sha256-0z+8IaZCBBAZ7ppzIAJi7NMXf49K2om9sCoooraPDEY=",
      "url": "bootstrap-icons/icons/sign-merge-left.svg"
    },
    {
      "hash": "sha256-zwcfvkgehRRERCkH6NEU6FmQ44Tw0Jphuzol+II6U9A=",
      "url": "bootstrap-icons/icons/sign-merge-right-fill.svg"
    },
    {
      "hash": "sha256-jtSGe1civzT/7BCiEUeG7AbjxFlAmgTvKAvyDZQ0MuM=",
      "url": "bootstrap-icons/icons/sign-merge-right.svg"
    },
    {
      "hash": "sha256-JmeEYfwDDdwjZWA8ap/yFIKy+fo90ELym4e9udZdTas=",
      "url": "bootstrap-icons/icons/sign-no-left-turn-fill.svg"
    },
    {
      "hash": "sha256-OgKzLOL777h/5KKgog4UkVv/E7ydO+sbz5zWfv65BgU=",
      "url": "bootstrap-icons/icons/sign-no-left-turn.svg"
    },
    {
      "hash": "sha256-TfX9AEzYINIMjvdQ1wePLpL1DfGtHSswTa2I9EdpIRw=",
      "url": "bootstrap-icons/icons/sign-no-parking-fill.svg"
    },
    {
      "hash": "sha256-RfUio1qY8OLVvNNPmlRH/DlnPWeRfWh6Ymn+brCP35k=",
      "url": "bootstrap-icons/icons/sign-no-parking.svg"
    },
    {
      "hash": "sha256-noFeI1LhlqOrqaRpxk6IzqIOf/hS0gy4TA6zSZu3+aA=",
      "url": "bootstrap-icons/icons/sign-no-right-turn-fill.svg"
    },
    {
      "hash": "sha256-soPLLqtwNgoIVzZkxhLCoPWwAx8DH0YP4LzF5rhQhps=",
      "url": "bootstrap-icons/icons/sign-no-right-turn.svg"
    },
    {
      "hash": "sha256-frlcSGYcZuqxRxop0w9IfQSYNDOU0gPhAC6Z7PfxCo8=",
      "url": "bootstrap-icons/icons/sign-railroad-fill.svg"
    },
    {
      "hash": "sha256-KIjcZN5v1g7ZAv+AgGTq2jUhCYpjEOfegLJABC5xKD4=",
      "url": "bootstrap-icons/icons/sign-railroad.svg"
    },
    {
      "hash": "sha256-2oQNs4VDq2FzoJQ/kddVABlKqf+JGzBPzI6EdNnZNP0=",
      "url": "bootstrap-icons/icons/sign-stop-fill.svg"
    },
    {
      "hash": "sha256-jhloIonqOq+bQT7dQ80MuLOHjGzC3rr+MQsNbp47MCU=",
      "url": "bootstrap-icons/icons/sign-stop-lights-fill.svg"
    },
    {
      "hash": "sha256-HbWffNBuiZSEYgkh0KMcwizKYt+z8UuVyk4opdSqva4=",
      "url": "bootstrap-icons/icons/sign-stop-lights.svg"
    },
    {
      "hash": "sha256-pLroJMQGhOjvPY+JrqBwM/LScPVQmeGThjWF1D1hyzY=",
      "url": "bootstrap-icons/icons/sign-stop.svg"
    },
    {
      "hash": "sha256-HdpufOs2pA9PTj3jvWYNRHYo4uji5E6N435D7hor2Bg=",
      "url": "bootstrap-icons/icons/sign-turn-left-fill.svg"
    },
    {
      "hash": "sha256-dbhENMBPbSjtJ85T9GBQKZ+lYha602f2Bxx/VK5EJ6w=",
      "url": "bootstrap-icons/icons/sign-turn-left.svg"
    },
    {
      "hash": "sha256-xjzDz3ODDMLhIUKuSJl0Dk4IvRDQo0ctIVn60HAnGyo=",
      "url": "bootstrap-icons/icons/sign-turn-right-fill.svg"
    },
    {
      "hash": "sha256-Wuo0gOQaQXKVVxbegdmdO+xOB34uZ9MVHFTX7fdB+yI=",
      "url": "bootstrap-icons/icons/sign-turn-right.svg"
    },
    {
      "hash": "sha256-NQqUeMrFLQ4/w4hlUHpRfL3HLwZm8VNYLHrnQR/USWs=",
      "url": "bootstrap-icons/icons/sign-turn-slight-left-fill.svg"
    },
    {
      "hash": "sha256-cd6OEtkzv9V6emWFWo7cZnFvw75QZYaFaK+UwPP7V6w=",
      "url": "bootstrap-icons/icons/sign-turn-slight-left.svg"
    },
    {
      "hash": "sha256-ngplPR7ZC2ofoRHqAwqEpSuDBwU7vaXEHNVYhk7OBfE=",
      "url": "bootstrap-icons/icons/sign-turn-slight-right-fill.svg"
    },
    {
      "hash": "sha256-QQo5uuclMHC0dkxVWpVDhw1PPVUTLxCQY+dF0zA3/bI=",
      "url": "bootstrap-icons/icons/sign-turn-slight-right.svg"
    },
    {
      "hash": "sha256-GvqkJ5BgiVSQNZ88cjwc1VYTnM4HTWs7NXDIWSazbr4=",
      "url": "bootstrap-icons/icons/sign-yield-fill.svg"
    },
    {
      "hash": "sha256-oCLO/c45wxmpTy1bGMchWATC51IwDyBWtMwSra5lqjo=",
      "url": "bootstrap-icons/icons/sign-yield.svg"
    },
    {
      "hash": "sha256-SAloqCxrZbn8JgqEYQX8h8pCuvI69FRYExhO7+3nKqc=",
      "url": "bootstrap-icons/icons/signal.svg"
    },
    {
      "hash": "sha256-CBgL45igLaBk7xRqHGoQ2Sp78e8LuKPy+exGvnAdvi8=",
      "url": "bootstrap-icons/icons/signpost-2-fill.svg"
    },
    {
      "hash": "sha256-iwbK2R44UMSE3TGbh0Iri+QQZSmy7p22J2kSFvTko5A=",
      "url": "bootstrap-icons/icons/signpost-2.svg"
    },
    {
      "hash": "sha256-vr+t3vssC8V4PY/MUsVOhKrdeUXea4/yMlmVv3oVdGM=",
      "url": "bootstrap-icons/icons/signpost-fill.svg"
    },
    {
      "hash": "sha256-kho5+8s9Or0abw9KNAAshGu+alv/C3uIs63nZ5+9rJw=",
      "url": "bootstrap-icons/icons/signpost-split-fill.svg"
    },
    {
      "hash": "sha256-ass2kaLCNy7ECsSTVFTwmI+AWpMEYwMK8/srTgkJFSc=",
      "url": "bootstrap-icons/icons/signpost-split.svg"
    },
    {
      "hash": "sha256-aKK/p72lTpPCNz8z98hHLC5o0W4O8Haz48nXMYJhEPw=",
      "url": "bootstrap-icons/icons/signpost.svg"
    },
    {
      "hash": "sha256-Q47esPy5oIwP+4m9McxRO3fGPaYfg4wXjkhDo/Wdvjw=",
      "url": "bootstrap-icons/icons/sim-fill.svg"
    },
    {
      "hash": "sha256-519GVuZZI+3FJPEVXTYTdJvP4Wdp+7nYika8vbVdWbg=",
      "url": "bootstrap-icons/icons/sim-slash-fill.svg"
    },
    {
      "hash": "sha256-JccDsT9iqDGhVFldWJULXQCUy4/iMkkHODI8aI3z3Ck=",
      "url": "bootstrap-icons/icons/sim-slash.svg"
    },
    {
      "hash": "sha256-taJFnsuIVdosmYNcGsl++56/OU2jdoQ+x8iifZWZCqU=",
      "url": "bootstrap-icons/icons/sim.svg"
    },
    {
      "hash": "sha256-LPDEHf+yF9od7RyFbtcgOZRN7pabJlgGf1nxrwyKRWA=",
      "url": "bootstrap-icons/icons/sina-weibo.svg"
    },
    {
      "hash": "sha256-EeznUPYbo7rZq6Isipb4ZbvHvchDKqeTXGWG/3BUkMw=",
      "url": "bootstrap-icons/icons/skip-backward-btn-fill.svg"
    },
    {
      "hash": "sha256-gu1eN8UqzwcYVIGJh1epfZQVdHSjJiMxdKjwanydLqw=",
      "url": "bootstrap-icons/icons/skip-backward-btn.svg"
    },
    {
      "hash": "sha256-CGxxTH7zbTVtopDeAz3BGzGlq7DM1XVmSmNTPmG0rGY=",
      "url": "bootstrap-icons/icons/skip-backward-circle-fill.svg"
    },
    {
      "hash": "sha256-COZn4i3CODp7NT9U4Bkmuivb/evyv/VksTDsp6y8RjQ=",
      "url": "bootstrap-icons/icons/skip-backward-circle.svg"
    },
    {
      "hash": "sha256-0nqImrRjm36XxGBDOCSYIg6NE0sFwXFnQcgX1c9onSI=",
      "url": "bootstrap-icons/icons/skip-backward-fill.svg"
    },
    {
      "hash": "sha256-XYcGkSj/DOjeSmSKfAdFDd2J+cuOi0W14kFxfwzWCnY=",
      "url": "bootstrap-icons/icons/skip-backward.svg"
    },
    {
      "hash": "sha256-t9nLWduR7v4j3Of0DzWzmIyyE8xv6Lgr/sJ6hYHd/NM=",
      "url": "bootstrap-icons/icons/skip-end-btn-fill.svg"
    },
    {
      "hash": "sha256-G7aitqo6CkiGP6d5IjU+shjN6d8MJ95cjwapiwwYTn0=",
      "url": "bootstrap-icons/icons/skip-end-btn.svg"
    },
    {
      "hash": "sha256-51mUeu2SxJYQtmEVTXWsGdQz7GAVHo8UnT8Af6C6tbM=",
      "url": "bootstrap-icons/icons/skip-end-circle-fill.svg"
    },
    {
      "hash": "sha256-HDc36FGMdS2F6ir69/pYxVAfPJg2g3knoQwkP2FWLNg=",
      "url": "bootstrap-icons/icons/skip-end-circle.svg"
    },
    {
      "hash": "sha256-7hAhtD8Eyu/khW2uzDZ8qdgk8ByPUD2+5Lw5B4Jt2ms=",
      "url": "bootstrap-icons/icons/skip-end-fill.svg"
    },
    {
      "hash": "sha256-io+ephi9UYw48bGNDuQR21RpDewPMV1NdnQ6BydbF78=",
      "url": "bootstrap-icons/icons/skip-end.svg"
    },
    {
      "hash": "sha256-UEhrh2LA5loMZiHYeOtaGC3hOBkY1AcfS/avKRk6NrA=",
      "url": "bootstrap-icons/icons/skip-forward-btn-fill.svg"
    },
    {
      "hash": "sha256-nlXAUYLAZ+gP8Neg/lH954GpZjSDkR11t7CAMhxngtk=",
      "url": "bootstrap-icons/icons/skip-forward-btn.svg"
    },
    {
      "hash": "sha256-cXPaYYp9cMhqHFDvuqiq9ydxNoIzlv9d3gGO88/C3Zw=",
      "url": "bootstrap-icons/icons/skip-forward-circle-fill.svg"
    },
    {
      "hash": "sha256-1bxm1J1JtYXe2ZTaqhJSmqAxVfIjtRMkOMylMW1BxI4=",
      "url": "bootstrap-icons/icons/skip-forward-circle.svg"
    },
    {
      "hash": "sha256-MujCtuFkgskbXNjmhNTDlcTYCl8oaYQkyQRJsTTJnHk=",
      "url": "bootstrap-icons/icons/skip-forward-fill.svg"
    },
    {
      "hash": "sha256-yUuTZaNd+6ynjY4GuWoqhJWQ8ysoJN1gj7CMhZJkQvQ=",
      "url": "bootstrap-icons/icons/skip-forward.svg"
    },
    {
      "hash": "sha256-vs7yzA1g982Q21JXw2kyqFVui6U3jUgXG3vRtbwQtbk=",
      "url": "bootstrap-icons/icons/skip-start-btn-fill.svg"
    },
    {
      "hash": "sha256-z65eBjIHXux02rJwCfQvhl0dvtXCOqCzfQN9SS0ru8o=",
      "url": "bootstrap-icons/icons/skip-start-btn.svg"
    },
    {
      "hash": "sha256-Al7bbuVWJhvF2kIa+DXF9VNNQf+Z2MYHjVgFk8yT0no=",
      "url": "bootstrap-icons/icons/skip-start-circle-fill.svg"
    },
    {
      "hash": "sha256-pFQWGYCOsuDajRjk1faIwGHdEKN9gtrfpGUorextnPE=",
      "url": "bootstrap-icons/icons/skip-start-circle.svg"
    },
    {
      "hash": "sha256-yb5lt04nyII7OyZXk+qSZOCdofTQfvggSPDymnyqvoo=",
      "url": "bootstrap-icons/icons/skip-start-fill.svg"
    },
    {
      "hash": "sha256-xm1DN3TloW57KY85OSui6CxU7q8lJLl8z6bmmrbxuxE=",
      "url": "bootstrap-icons/icons/skip-start.svg"
    },
    {
      "hash": "sha256-X3AEkGp3VrlDGQF1i5PPCy+qnTAgLLUkfqCU8t2dbWE=",
      "url": "bootstrap-icons/icons/skype.svg"
    },
    {
      "hash": "sha256-MrXk0WEpzMxDfZPlgKuStP6fYQWMmW3VIE+P4N2ZsVw=",
      "url": "bootstrap-icons/icons/slack.svg"
    },
    {
      "hash": "sha256-+AXhbMj0kcyJ2HrsfDwYobrYI9YAYy5WtO3DrD81HnE=",
      "url": "bootstrap-icons/icons/slash-circle-fill.svg"
    },
    {
      "hash": "sha256-MWEiVVm0r41VR5yC10Vr+MQHHt/FKAb5USKN8ONx9Sc=",
      "url": "bootstrap-icons/icons/slash-circle.svg"
    },
    {
      "hash": "sha256-nIxbuZOpsyHXZh2ciVhGjt8KkrsPuGRuiCGQUjlYGqE=",
      "url": "bootstrap-icons/icons/slash-lg.svg"
    },
    {
      "hash": "sha256-s7vrs88ZLlFrE4V5rhllPY3dGyaFS8Nf3uEq96sX6DU=",
      "url": "bootstrap-icons/icons/slash-square-fill.svg"
    },
    {
      "hash": "sha256-g2RFMmK2sCpdHJGpPBRYs98K6g+0bsu2oGFb7okZaS8=",
      "url": "bootstrap-icons/icons/slash-square.svg"
    },
    {
      "hash": "sha256-PIoV0UjAavU1aiDV0wHMOPxXEXN0EdAdNOSbJNTgR8A=",
      "url": "bootstrap-icons/icons/slash.svg"
    },
    {
      "hash": "sha256-OJhvCHS2Pjo05fSJo5sjV58xy9DEO3nRfpW1AxKsIfw=",
      "url": "bootstrap-icons/icons/sliders.svg"
    },
    {
      "hash": "sha256-w8u27f1G1Ixpp3xUrG172gSSbezTnfHae/dUeHLqi8g=",
      "url": "bootstrap-icons/icons/sliders2-vertical.svg"
    },
    {
      "hash": "sha256-OMafcJyM79N3WSusyAcci1AOnt/HdVKlonlOnZ8SV3U=",
      "url": "bootstrap-icons/icons/sliders2.svg"
    },
    {
      "hash": "sha256-acdgz+cLYA36j1aGWwW6b6TiVA8WUsyUK4KTQ+RCWgM=",
      "url": "bootstrap-icons/icons/smartwatch.svg"
    },
    {
      "hash": "sha256-1DW5q9fPQ0BnZrDDYJEwcg2s74CbD0bWaQLG/81mcs4=",
      "url": "bootstrap-icons/icons/snapchat.svg"
    },
    {
      "hash": "sha256-PyfmR1BZ9/FX28IaCMtxUDmXXTywm/O+0yQcQzTNk98=",
      "url": "bootstrap-icons/icons/snow.svg"
    },
    {
      "hash": "sha256-QI+8DA9YZdfaYiW6CAzreLklAJYchnKgOMQZK5wjH74=",
      "url": "bootstrap-icons/icons/snow2.svg"
    },
    {
      "hash": "sha256-1ie3JOWcME8iBLqLfe5a0whakpDZFg1bgHcki2YMTns=",
      "url": "bootstrap-icons/icons/snow3.svg"
    },
    {
      "hash": "sha256-pkPFv5sU7qGJOzJO2gdKU57ZYBw1SKBTBOXplQ6NFqQ=",
      "url": "bootstrap-icons/icons/sort-alpha-down-alt.svg"
    },
    {
      "hash": "sha256-GhknUfRjuEp3JJheOfhR33a6UwKSUG6vVnzOIxQu1Vo=",
      "url": "bootstrap-icons/icons/sort-alpha-down.svg"
    },
    {
      "hash": "sha256-qQ2QU0eCyB7VgRJT8imEIaJzkmfzk4Cd9o5TdFRIxU0=",
      "url": "bootstrap-icons/icons/sort-alpha-up-alt.svg"
    },
    {
      "hash": "sha256-uHxf2Nb2Z4h6M8y/7hPCv+a9LesobjTzn7+RceK3qSA=",
      "url": "bootstrap-icons/icons/sort-alpha-up.svg"
    },
    {
      "hash": "sha256-+8YYiR06RCdLf+0vqC+ugJQ2LV85ASv71rNZiZIBY2Y=",
      "url": "bootstrap-icons/icons/sort-down-alt.svg"
    },
    {
      "hash": "sha256-WS8Lojr3T61fnALtea9PqeT73KK1MVawUUUetKSJtFY=",
      "url": "bootstrap-icons/icons/sort-down.svg"
    },
    {
      "hash": "sha256-O+lxI2Wb1GZJ8YWSSaM4Sl4XqcBz1D6ws50JAUMCW/Y=",
      "url": "bootstrap-icons/icons/sort-numeric-down-alt.svg"
    },
    {
      "hash": "sha256-GiZExogbLTS9mhLvOaQQAku5QKq09Z1G/c0YqAMIxmE=",
      "url": "bootstrap-icons/icons/sort-numeric-down.svg"
    },
    {
      "hash": "sha256-NVtT2TgCWoQ710M70GoYf7fJ/cL6j65pp3Kk9uq8BTk=",
      "url": "bootstrap-icons/icons/sort-numeric-up-alt.svg"
    },
    {
      "hash": "sha256-VtdElLz50jkqhuiVs72sEGpanB1nFfalO5aV5nmmGCc=",
      "url": "bootstrap-icons/icons/sort-numeric-up.svg"
    },
    {
      "hash": "sha256-Hs+9HBi15KtKk6i0NFEBhokAlngNkk8++8aavbwka7M=",
      "url": "bootstrap-icons/icons/sort-up-alt.svg"
    },
    {
      "hash": "sha256-u6qYe+luRDE19RQdZBBJNKt1qLmeMk4TZSaLjMcvQys=",
      "url": "bootstrap-icons/icons/sort-up.svg"
    },
    {
      "hash": "sha256-W3XM8gqTavej+VQFip/mm382+Tr+B1Sr3LVar4OB3Og=",
      "url": "bootstrap-icons/icons/soundwave.svg"
    },
    {
      "hash": "sha256-WdiRPApJtOxe1hh0wQJyML2TKMl8I/7IlE5KSa8joN8=",
      "url": "bootstrap-icons/icons/sourceforge.svg"
    },
    {
      "hash": "sha256-+skVqsntBbyskbyIMGDfFuAH53kyfofhVyy5RmQ9N8A=",
      "url": "bootstrap-icons/icons/speaker-fill.svg"
    },
    {
      "hash": "sha256-u1372EtKfDjuYZizG7iXoSsSMX8VQFBg+4PV4X7QMfk=",
      "url": "bootstrap-icons/icons/speaker.svg"
    },
    {
      "hash": "sha256-RPoCBUjSsakKB1f+7Cw/Jfn/MCTpRkbYjiWwlgtUBa8=",
      "url": "bootstrap-icons/icons/speedometer.svg"
    },
    {
      "hash": "sha256-qkn5PVksWTi5OV6ouuelbTE/QzNjTaqdm0/GQoVG9zo=",
      "url": "bootstrap-icons/icons/speedometer2.svg"
    },
    {
      "hash": "sha256-Sia70IS3eywIS6CZh1krmD8Tp+cWOEWnt30zFiQwnRM=",
      "url": "bootstrap-icons/icons/spellcheck.svg"
    },
    {
      "hash": "sha256-ZqKNbDvE3OfqKDhGTR8h2DToEnKOcWIWCYyEmh2iIkY=",
      "url": "bootstrap-icons/icons/spotify.svg"
    },
    {
      "hash": "sha256-pBbGwvyk6P9VScxRT0Mdz/FjiG8wp6jcuzJvOUfBXRY=",
      "url": "bootstrap-icons/icons/square-fill.svg"
    },
    {
      "hash": "sha256-axTnVNv0tD/XN7u7sRMT5HQ/R6X8SBxvJlnOmAUwndY=",
      "url": "bootstrap-icons/icons/square-half.svg"
    },
    {
      "hash": "sha256-UPfpxZQNenEmOllyM7kvOWzup7h2WrdIBiXElQbRDJs=",
      "url": "bootstrap-icons/icons/square.svg"
    },
    {
      "hash": "sha256-pmJcSJkv7dwBYfNJf+4ipIf78EFAD266AiasOJQHD0U=",
      "url": "bootstrap-icons/icons/stack-overflow.svg"
    },
    {
      "hash": "sha256-tuqXCTZ9AU4hAw/KSmbt6LGGLfJlpwX7REWETwwvigk=",
      "url": "bootstrap-icons/icons/stack.svg"
    },
    {
      "hash": "sha256-0U+uP9N+5Z0EnTdCPmEOWM9RfmpUS13FL3pj+iilfn4=",
      "url": "bootstrap-icons/icons/star-fill.svg"
    },
    {
      "hash": "sha256-AtuEWZMEK63ZmsCC7gZ47ZcZUPZMndtIcQ7x/Wd5hmU=",
      "url": "bootstrap-icons/icons/star-half.svg"
    },
    {
      "hash": "sha256-LL+CUit8nk1ZbFAJABQkw7cy7CEKTA8LZXa3Hy0pnXM=",
      "url": "bootstrap-icons/icons/star.svg"
    },
    {
      "hash": "sha256-WSEEQ41FIV9fS1jHRca5Nb26Tw0mIrpcRHyACX8gug0=",
      "url": "bootstrap-icons/icons/stars.svg"
    },
    {
      "hash": "sha256-khf1WSLEE5MYbkWtCPeRLUR5u2tm4/ix5PFgwOaDkks=",
      "url": "bootstrap-icons/icons/steam.svg"
    },
    {
      "hash": "sha256-bBy86o1s5rfTEORfpY/jUni9J1cLORT+DzWdMWmQVw0=",
      "url": "bootstrap-icons/icons/stickies-fill.svg"
    },
    {
      "hash": "sha256-Bhe4zbgJoElC6FrmSj9tLRV8Lx01p8sN19I6H+7sEng=",
      "url": "bootstrap-icons/icons/stickies.svg"
    },
    {
      "hash": "sha256-igwVRjWNVuujSfsCeWPjpX0qj1LhJq+qlAztymPJDsw=",
      "url": "bootstrap-icons/icons/sticky-fill.svg"
    },
    {
      "hash": "sha256-FL801F/vIlSfk2sgRMpHKdos/wdXQACAICt4zdmxCZM=",
      "url": "bootstrap-icons/icons/sticky.svg"
    },
    {
      "hash": "sha256-ojbbP2rE3pxqkjhX3lT8/yoEWn/hXBck6JOMBBzw0uI=",
      "url": "bootstrap-icons/icons/stop-btn-fill.svg"
    },
    {
      "hash": "sha256-cQv6aqRY3Sw5uvciT9bK0kWrMFRygwd//7O4pfVa3ZM=",
      "url": "bootstrap-icons/icons/stop-btn.svg"
    },
    {
      "hash": "sha256-zfPf4tsbGTWlZqgbXevL9+l705u+gY1W8HE/EaUDXh8=",
      "url": "bootstrap-icons/icons/stop-circle-fill.svg"
    },
    {
      "hash": "sha256-gaucBVVNVXB8s+lrTz2gYvv7utFVABTVFWj5iCtNoDU=",
      "url": "bootstrap-icons/icons/stop-circle.svg"
    },
    {
      "hash": "sha256-twmbsoBGPEHJrdHhATuPWXERDNWvqc7eESoVP8alSCg=",
      "url": "bootstrap-icons/icons/stop-fill.svg"
    },
    {
      "hash": "sha256-yhnrurfQql3FUuiz2lRQRZpsEelVJS5XTZmclJrppEA=",
      "url": "bootstrap-icons/icons/stop.svg"
    },
    {
      "hash": "sha256-AfbAqzo1DIcHjtQdjoaMQwwzLNg9qz7aEROfF58Pzso=",
      "url": "bootstrap-icons/icons/stoplights-fill.svg"
    },
    {
      "hash": "sha256-oP/Wd/Tv8DtsTbmVFYChDIGqT1v13rSXV5C6vKBPw8A=",
      "url": "bootstrap-icons/icons/stoplights.svg"
    },
    {
      "hash": "sha256-xFwLag3n9QXiDAVHAIcXUMBh0vhC/z/NSo/ZMRkBcLU=",
      "url": "bootstrap-icons/icons/stopwatch-fill.svg"
    },
    {
      "hash": "sha256-pavE2CP6kDA/A8g9CXzJaQS4GfaNgdMhlaZVdSN1A/8=",
      "url": "bootstrap-icons/icons/stopwatch.svg"
    },
    {
      "hash": "sha256-Fej258aRQW7DqN28TIMzRdGxsnaTPR4O4mJMpavGvww=",
      "url": "bootstrap-icons/icons/strava.svg"
    },
    {
      "hash": "sha256-15+7XR7kcYJ668A/eIHcFcUDpsy8PUP/FYU706oG36E=",
      "url": "bootstrap-icons/icons/stripe.svg"
    },
    {
      "hash": "sha256-BpjP3ndoooKwBL5nADBkiFe0qZvZ/ezmBWcfLSis74A=",
      "url": "bootstrap-icons/icons/subscript.svg"
    },
    {
      "hash": "sha256-6exoEzNjAakGwwR9v18erYGZGwLR1au5aEnBFZaSzU0=",
      "url": "bootstrap-icons/icons/substack.svg"
    },
    {
      "hash": "sha256-VThVB88C3Y345PkaMn5QtMZzPQAFpKe9ZCJwZE1KKsQ=",
      "url": "bootstrap-icons/icons/subtract.svg"
    },
    {
      "hash": "sha256-rlQZkLq3xGKYYHXh66g7qjJAzsi1JKNtyitr4J39kNc=",
      "url": "bootstrap-icons/icons/suit-club-fill.svg"
    },
    {
      "hash": "sha256-b9GbfbADtokD9XjsaoYmEtSKbhBDvDLGEsLuir5f9KU=",
      "url": "bootstrap-icons/icons/suit-club.svg"
    },
    {
      "hash": "sha256-wJlnYjMdGgYMHGEKES9dUEQJMPN4tEo5QeZVDvY2Y8M=",
      "url": "bootstrap-icons/icons/suit-diamond-fill.svg"
    },
    {
      "hash": "sha256-S+OZGSOHG7yVL1KFAWJmpQXmC1Klfuu/6ruwrFj7To0=",
      "url": "bootstrap-icons/icons/suit-diamond.svg"
    },
    {
      "hash": "sha256-Bo9tlZoM0OwBnINEmh9cMiEqZ9WZ0D/RcI7ZzWezif0=",
      "url": "bootstrap-icons/icons/suit-heart-fill.svg"
    },
    {
      "hash": "sha256-D3CxUatVAfBwFiVVV5y5IRov4PGNubclMIHxahXJ/XY=",
      "url": "bootstrap-icons/icons/suit-heart.svg"
    },
    {
      "hash": "sha256-PC/qqqcO40g2gwpdgm7/564XC/OJmcQMBm0jkhDn01s=",
      "url": "bootstrap-icons/icons/suit-spade-fill.svg"
    },
    {
      "hash": "sha256-KkX4Ui3kpLUukxJjTTnie0g4BICI04Q3x6llt3EDxG0=",
      "url": "bootstrap-icons/icons/suit-spade.svg"
    },
    {
      "hash": "sha256-u2uyVBODE1hX9bYrut8YHxPmtUAAWiGoWBX40DLIQHs=",
      "url": "bootstrap-icons/icons/suitcase-fill.svg"
    },
    {
      "hash": "sha256-B3IST1cvvsoSOmnTFazPSdBlTnWDFzTdMPPHkUBP2rU=",
      "url": "bootstrap-icons/icons/suitcase-lg-fill.svg"
    },
    {
      "hash": "sha256-3wJexYLZ7FDSDSr/S5kT4jl0sYrSRUjxe4IjJGNKrik=",
      "url": "bootstrap-icons/icons/suitcase-lg.svg"
    },
    {
      "hash": "sha256-FCV9IjSaHlnDljiDuUIvDV3e3ZpNetD8Xv1LSZIOX/Y=",
      "url": "bootstrap-icons/icons/suitcase.svg"
    },
    {
      "hash": "sha256-bm98gwtecXoUBplAgRXDLVIxHE4Q7N1Rbf7+rtUObBE=",
      "url": "bootstrap-icons/icons/suitcase2-fill.svg"
    },
    {
      "hash": "sha256-yX5LtcY2dsfT8dIeoUDuD9DUGFcws4iGuSvEVFs75kQ=",
      "url": "bootstrap-icons/icons/suitcase2.svg"
    },
    {
      "hash": "sha256-BIkA0xD3x4inuVNu1svB2tmWvSUoTd56ahyiJiS1x34=",
      "url": "bootstrap-icons/icons/sun-fill.svg"
    },
    {
      "hash": "sha256-cr4f++3qWKXPaLE2YnQ5tCwmZDdl8jD8gHSWmY7SFB0=",
      "url": "bootstrap-icons/icons/sun.svg"
    },
    {
      "hash": "sha256-ezp/1JbVVCCK9xIsW3JHV2rbBVfLjf07wo7fSjkaE5A=",
      "url": "bootstrap-icons/icons/sunglasses.svg"
    },
    {
      "hash": "sha256-71IkjxWvyd6ywA5FEggDPOTdXGlrOA6R71CHM2AsHM8=",
      "url": "bootstrap-icons/icons/sunrise-fill.svg"
    },
    {
      "hash": "sha256-OHRYVUz6XCBPO6SWZK/pRvXDvmp6CjuMoNlRb5WMG+o=",
      "url": "bootstrap-icons/icons/sunrise.svg"
    },
    {
      "hash": "sha256-SmKCrZOxdQtrW1HWTC4S0dSgRDGGR2MaY8LnEKE/r2w=",
      "url": "bootstrap-icons/icons/sunset-fill.svg"
    },
    {
      "hash": "sha256-M1baEz10K6u+XuKVR68+tTXxccri1QrinFLrNo5UBFA=",
      "url": "bootstrap-icons/icons/sunset.svg"
    },
    {
      "hash": "sha256-1HesnUgiPpT5z4xedODksQ9YmTsOxMm0V631gWGzpRA=",
      "url": "bootstrap-icons/icons/superscript.svg"
    },
    {
      "hash": "sha256-SrPSvaoodLLBrhgdsxArxJu6SYvjMqxBsyE0BU1pl/I=",
      "url": "bootstrap-icons/icons/symmetry-horizontal.svg"
    },
    {
      "hash": "sha256-8sxzDTdHKDyK33wVfOotJc3PrIelvU71B37P5eMCSE8=",
      "url": "bootstrap-icons/icons/symmetry-vertical.svg"
    },
    {
      "hash": "sha256-FvSDlwf0ngHSB5RgtlGRhQN9tig7S81BtLJwtWlE0pk=",
      "url": "bootstrap-icons/icons/table.svg"
    },
    {
      "hash": "sha256-ojahTMmi4ntUGs+zvzzCZIOi+1d4pSFgXojX9ZA8oWA=",
      "url": "bootstrap-icons/icons/tablet-fill.svg"
    },
    {
      "hash": "sha256-gYx4iMFmo5psHoJ1UntVk3acyBotpeHmD2ZtQHS9hWs=",
      "url": "bootstrap-icons/icons/tablet-landscape-fill.svg"
    },
    {
      "hash": "sha256-tsbXXopQVmRFl5uhQdJxSGRICYOgD5YOcNaOcmsoA2c=",
      "url": "bootstrap-icons/icons/tablet-landscape.svg"
    },
    {
      "hash": "sha256-5vDCAF+gpbad39TboZqqPoACN0dAxGQ6FGjlcE1Abqo=",
      "url": "bootstrap-icons/icons/tablet.svg"
    },
    {
      "hash": "sha256-ehlnHSlofqEcvBe6MzF5i9TWDqc8boHYADgkvloHgVQ=",
      "url": "bootstrap-icons/icons/tag-fill.svg"
    },
    {
      "hash": "sha256-AhSE1UWYLvCapUnYCytmSsxx8tMiQ+rU4rgG8I1EnHk=",
      "url": "bootstrap-icons/icons/tag.svg"
    },
    {
      "hash": "sha256-Eu/X6xt7aA4Ydt1p7QKaEWxOT1G1iI6zHFhgP+RoFGM=",
      "url": "bootstrap-icons/icons/tags-fill.svg"
    },
    {
      "hash": "sha256-LQ7udsYjAWgFbyU6sbuwTPseHLYvfGCeq8kneGg6HMw=",
      "url": "bootstrap-icons/icons/tags.svg"
    },
    {
      "hash": "sha256-IG5D3fPoQIif0JuYVp27pmQ+OEQR6HQtuwJXBTtVnbg=",
      "url": "bootstrap-icons/icons/taxi-front-fill.svg"
    },
    {
      "hash": "sha256-aF0soW3WCDK7m805K0/EKHAVOYhxygZ3aEwhmco0AmU=",
      "url": "bootstrap-icons/icons/taxi-front.svg"
    },
    {
      "hash": "sha256-xW5pGdY+JWgerYYV+1DoDV3lvgRmysnSeQYRAwr5fM4=",
      "url": "bootstrap-icons/icons/telegram.svg"
    },
    {
      "hash": "sha256-PlWNxgLU0/qSrJn3AHK6J5Q2Zd7uq/c4BEDC+adB7kI=",
      "url": "bootstrap-icons/icons/telephone-fill.svg"
    },
    {
      "hash": "sha256-dCRS3w3kkbk9EFHkyToEeg/JP6ENXQLrm9L9h1l4qjk=",
      "url": "bootstrap-icons/icons/telephone-forward-fill.svg"
    },
    {
      "hash": "sha256-trRNUnHBVSI9GOpIDlBnMo5yzDOHZ4Gn9AqwQ5Fv00o=",
      "url": "bootstrap-icons/icons/telephone-forward.svg"
    },
    {
      "hash": "sha256-iuuaHk47B4AOVoAAr671Jccl4d7PpaxNPg0x+8Ik4EY=",
      "url": "bootstrap-icons/icons/telephone-inbound-fill.svg"
    },
    {
      "hash": "sha256-8Iq+P31rAQZEW/4jtUGe3yU95OwkDuvxoh7MsUNSFIo=",
      "url": "bootstrap-icons/icons/telephone-inbound.svg"
    },
    {
      "hash": "sha256-cVSc03WX0KWoLwH1W8B7rHNQxuudv38VrHhdI6Exs0c=",
      "url": "bootstrap-icons/icons/telephone-minus-fill.svg"
    },
    {
      "hash": "sha256-c8v6xf3k4Pbfihl3zdg1yY6tQeOUSqKd1MhbPZ62xxI=",
      "url": "bootstrap-icons/icons/telephone-minus.svg"
    },
    {
      "hash": "sha256-Vk8O9+9W4Lq9NmIAlbaGLO85ZlkCSJBGI/6+p9NhwO8=",
      "url": "bootstrap-icons/icons/telephone-outbound-fill.svg"
    },
    {
      "hash": "sha256-bmvuQ2dQcuumu08aAcqEBZs2XG0lCzviA/Z5eI4znTA=",
      "url": "bootstrap-icons/icons/telephone-outbound.svg"
    },
    {
      "hash": "sha256-CQIsByPrUsSLrPgPCY6eEh8mlUPO5Ku/2ycCBYezKU4=",
      "url": "bootstrap-icons/icons/telephone-plus-fill.svg"
    },
    {
      "hash": "sha256-0jzAisxAM57/2rxIZq9x0HbdyxmqqRzehDzGscDbKg0=",
      "url": "bootstrap-icons/icons/telephone-plus.svg"
    },
    {
      "hash": "sha256-dLBtPipkRntyq7EACCDmX8o+QGKRzkW1wxQN2ICQ8XE=",
      "url": "bootstrap-icons/icons/telephone-x-fill.svg"
    },
    {
      "hash": "sha256-vm1rwDdlCn2QEmZqqdbNPC/bwp4W52WTk2zX3oJpZ1A=",
      "url": "bootstrap-icons/icons/telephone-x.svg"
    },
    {
      "hash": "sha256-AOsvvkIdLFClzav6g3qODcRbZc+Rxp/llw/liFqlKqE=",
      "url": "bootstrap-icons/icons/telephone.svg"
    },
    {
      "hash": "sha256-2DNEB6SDz4y82JdMdAFSWgOBsrlSPS/J5Y/4u44VK0I=",
      "url": "bootstrap-icons/icons/tencent-qq.svg"
    },
    {
      "hash": "sha256-f//Y9rbbWTsWAHjLjV8TaQQKKhkhHHSJiGIeUrd853A=",
      "url": "bootstrap-icons/icons/terminal-dash.svg"
    },
    {
      "hash": "sha256-xMdXu6/gfAyptoaCA85Ll9h+dRiTs+BsEmqW+nrnG0U=",
      "url": "bootstrap-icons/icons/terminal-fill.svg"
    },
    {
      "hash": "sha256-t6cH+J5bLwdRJ42CRuJ5iYxSnvdFn17sI0Y0qByfHlM=",
      "url": "bootstrap-icons/icons/terminal-plus.svg"
    },
    {
      "hash": "sha256-ix/e4JwZ+F3Kx5/OJ+5mEg3LW0MLKB0B370IJH+KjtE=",
      "url": "bootstrap-icons/icons/terminal-split.svg"
    },
    {
      "hash": "sha256-P7lGI70u9jakuYxUqRN2MzZmu0969+SPQP5g/eDyc6U=",
      "url": "bootstrap-icons/icons/terminal-x.svg"
    },
    {
      "hash": "sha256-hul/BF/5DnMbFGPktrsmuVvo6zm/HJWzgH0YqU16I6Y=",
      "url": "bootstrap-icons/icons/terminal.svg"
    },
    {
      "hash": "sha256-RKLnXB5Ydn5nnAMy22o8/uDC+SRyvKRiK31GTHKN0xA=",
      "url": "bootstrap-icons/icons/text-center.svg"
    },
    {
      "hash": "sha256-XNdbbzzJa1wjM+g5wbwSQ/CUq6ycwu83sRq2TKAiHF8=",
      "url": "bootstrap-icons/icons/text-indent-left.svg"
    },
    {
      "hash": "sha256-BACQHb5yJqMeMRK08VMUjyhyPrCueS0m+S1EDJdkqBY=",
      "url": "bootstrap-icons/icons/text-indent-right.svg"
    },
    {
      "hash": "sha256-WMDjHVfF+Cz2FL0PC6H5ZDi29wINBv6r3rQnwOU6fQE=",
      "url": "bootstrap-icons/icons/text-left.svg"
    },
    {
      "hash": "sha256-YV+aNcrLb5z8HTgdLoDx4Ug/PRuiPbbXoNAldUBZjjk=",
      "url": "bootstrap-icons/icons/text-paragraph.svg"
    },
    {
      "hash": "sha256-TD8XZtTzakjwQg3vQ0bog76KmE3D8wF19IHYK+HSozg=",
      "url": "bootstrap-icons/icons/text-right.svg"
    },
    {
      "hash": "sha256-hwdc5g24I9G1vmw8z7gdTnlzDpgLoVeFx1ZTx2vEJuA=",
      "url": "bootstrap-icons/icons/text-wrap.svg"
    },
    {
      "hash": "sha256-5gA2F8eaeqKqZYnOjXfSSukTVd8McRywW8IfJHAFvzU=",
      "url": "bootstrap-icons/icons/textarea-resize.svg"
    },
    {
      "hash": "sha256-teYEWGmCT3EMTa4t5boj4hZOEj2zEE65q6mHM6aNSdM=",
      "url": "bootstrap-icons/icons/textarea-t.svg"
    },
    {
      "hash": "sha256-FzjaKDkk4YnBibWhyybmyfR8aPhw3CO0E2TWhTcRG3c=",
      "url": "bootstrap-icons/icons/textarea.svg"
    },
    {
      "hash": "sha256-MkKYVKlFYsfDjzvOlaiUNFuj/+izliMpEDTSP1B80jI=",
      "url": "bootstrap-icons/icons/thermometer-half.svg"
    },
    {
      "hash": "sha256-5MHo7Dukcip+z9l6QvCeXz/d2QaWoZzyAxJQTeGTWFo=",
      "url": "bootstrap-icons/icons/thermometer-high.svg"
    },
    {
      "hash": "sha256-KFABmVPIaMAwemWCwGCPN9WN/oh9R4WpWXvrtgiZgB8=",
      "url": "bootstrap-icons/icons/thermometer-low.svg"
    },
    {
      "hash": "sha256-/lNxGy/bP24u7oQ9+n8U/WLZeJKkb0o7Dtwldz0166M=",
      "url": "bootstrap-icons/icons/thermometer-snow.svg"
    },
    {
      "hash": "sha256-VgfhyR59sNBPaBOwzaHS9U13h9pZwwaJTqjeFzG5hm8=",
      "url": "bootstrap-icons/icons/thermometer-sun.svg"
    },
    {
      "hash": "sha256-4HfvyBjjDY9Q5oYr34ga//rIgg/3TffxxvO2EGb5TVk=",
      "url": "bootstrap-icons/icons/thermometer.svg"
    },
    {
      "hash": "sha256-IJAf/q3KPXPHVlJfh1b+5NVl7i9sUCHKrlzGiVv9MSg=",
      "url": "bootstrap-icons/icons/threads-fill.svg"
    },
    {
      "hash": "sha256-zR7a9ZDfOeGvVLUoPCYHOnyn+MWrBa71HIGArW3KXBk=",
      "url": "bootstrap-icons/icons/threads.svg"
    },
    {
      "hash": "sha256-72ZH0oMLl/zShdwIyVC3Bm/T4HnpnP5XIl9sH723KhE=",
      "url": "bootstrap-icons/icons/three-dots-vertical.svg"
    },
    {
      "hash": "sha256-DD9GgXVU8x+c84b2iDTRqdj+ogQWdlmaD3o+nJgK230=",
      "url": "bootstrap-icons/icons/three-dots.svg"
    },
    {
      "hash": "sha256-oLGk76B1N5axkl72gp1FpwJrGjePo1BwQNcHDWqhha4=",
      "url": "bootstrap-icons/icons/thunderbolt-fill.svg"
    },
    {
      "hash": "sha256-DcAAOmavRiBQP7uKj6lSVzUR54bNrm/tl3ERi6uTRLY=",
      "url": "bootstrap-icons/icons/thunderbolt.svg"
    },
    {
      "hash": "sha256-03p8nvlN3q/rsbjH9NEDI/e9htnPJSLQPxPb3HcgnAU=",
      "url": "bootstrap-icons/icons/ticket-detailed-fill.svg"
    },
    {
      "hash": "sha256-KASdlJBOGRbTKP5XDwWUSGfohOHIpdY3k/RBqO7puOY=",
      "url": "bootstrap-icons/icons/ticket-detailed.svg"
    },
    {
      "hash": "sha256-MbabfXqG9W2zI37IsZtcghWc1IALeNDGdhIWxa6f+XM=",
      "url": "bootstrap-icons/icons/ticket-fill.svg"
    },
    {
      "hash": "sha256-PdIba8mKczQPpq2n/LFFjwyGvYKiifUy7Tu4VSXJvlg=",
      "url": "bootstrap-icons/icons/ticket-perforated-fill.svg"
    },
    {
      "hash": "sha256-h/YUPi2sKJgfiadM7AGRp8C1xQsE/mg4hF0jUV9Azis=",
      "url": "bootstrap-icons/icons/ticket-perforated.svg"
    },
    {
      "hash": "sha256-oPmPzDwraA98KdS9JkECyLs2fNZgXdXN+f7x/e5q9mw=",
      "url": "bootstrap-icons/icons/ticket.svg"
    },
    {
      "hash": "sha256-Bkd2Tt9O4jW7Sf/Whg3CwL87PhvazklGmowMC8B/jKY=",
      "url": "bootstrap-icons/icons/tiktok.svg"
    },
    {
      "hash": "sha256-kx3BpDkEdC7LXJnddEsi0X9J67aNxGg4FwWR8GFTSNI=",
      "url": "bootstrap-icons/icons/toggle-off.svg"
    },
    {
      "hash": "sha256-dcceFGbEV74/ksSTPqic8AUSdVpbhljMPAZZ22BRfTU=",
      "url": "bootstrap-icons/icons/toggle-on.svg"
    },
    {
      "hash": "sha256-BpaYIaClmAD5GBZ1ntAzbCGkMoQIdzzqdE0a1+dZdzE=",
      "url": "bootstrap-icons/icons/toggle2-off.svg"
    },
    {
      "hash": "sha256-7EFJsJl1+LAnTUCwKwwFo71HgY5oB36NT++kM1bgBWo=",
      "url": "bootstrap-icons/icons/toggle2-on.svg"
    },
    {
      "hash": "sha256-MNzpPzg7mXDRckHIzEu4rPb4fsaZg99CZs0KVpwrVu0=",
      "url": "bootstrap-icons/icons/toggles.svg"
    },
    {
      "hash": "sha256-lnlNiaM5V1fhbQ5ngauPmCjTPXu7Wne0iEZUyIP/jN4=",
      "url": "bootstrap-icons/icons/toggles2.svg"
    },
    {
      "hash": "sha256-aTvkFfQpTGl7CvLNzWREIhgfm92mkp50KfDA7iToAC4=",
      "url": "bootstrap-icons/icons/tools.svg"
    },
    {
      "hash": "sha256-3v1bHBanC/mCZSPUYtWai60tTQyWScN95oRv6GAeSNo=",
      "url": "bootstrap-icons/icons/tornado.svg"
    },
    {
      "hash": "sha256-dBlLdeMXc1pQ1C/jSeg9jHLVnHIltQeF0XxS+fLwF3A=",
      "url": "bootstrap-icons/icons/train-freight-front-fill.svg"
    },
    {
      "hash": "sha256-qzqpP2Ug7cKSLoKmpcV3y2pJBu0KoQ93d49OmAC5jKs=",
      "url": "bootstrap-icons/icons/train-freight-front.svg"
    },
    {
      "hash": "sha256-a2tE2unmJxxAlAS6huyq0LUzCdBNX/cPn4/OnZwRofk=",
      "url": "bootstrap-icons/icons/train-front-fill.svg"
    },
    {
      "hash": "sha256-/GY/0cvN8gf9k3qbW9ZZTLbw8Op2aZhBhcYOqewgvJo=",
      "url": "bootstrap-icons/icons/train-front.svg"
    },
    {
      "hash": "sha256-tg5JCRiG5lIpeJB0zPYBqwZ5vt/2BEHP0yZwZMXKGh8=",
      "url": "bootstrap-icons/icons/train-lightrail-front-fill.svg"
    },
    {
      "hash": "sha256-DFSt+OfVCabKbc9kAIp5RT37vOfQJFpd2nLwr0qeUas=",
      "url": "bootstrap-icons/icons/train-lightrail-front.svg"
    },
    {
      "hash": "sha256-mobq5gZePbngv+qRgD1CWODdxQ/LaXl/E/s8+FaWcJc=",
      "url": "bootstrap-icons/icons/translate.svg"
    },
    {
      "hash": "sha256-D53KGIp2uyMKsp6CNYefsTarkJd99/6ChylybQeyw3E=",
      "url": "bootstrap-icons/icons/transparency.svg"
    },
    {
      "hash": "sha256-8OhZSJKo6/l0zMs4fpYuYG8/9GCP7BZV3h2KR8ZK2kQ=",
      "url": "bootstrap-icons/icons/trash-fill.svg"
    },
    {
      "hash": "sha256-+Yhzs3ABE+jL93XQyBLRJP33ywajVagt1CBsUUefNGI=",
      "url": "bootstrap-icons/icons/trash.svg"
    },
    {
      "hash": "sha256-5k1OPq4lhVkPW8sdaHM2KcNCri6odcMLZzK+VQfCOXc=",
      "url": "bootstrap-icons/icons/trash2-fill.svg"
    },
    {
      "hash": "sha256-pacLCniFPpn5n3DSZljr+1ZsLMmNo15tEvehzC6CXB0=",
      "url": "bootstrap-icons/icons/trash2.svg"
    },
    {
      "hash": "sha256-f12JsqIH7DUid+R6no8yAmQVOVWgD+KdjRHfUHwBagM=",
      "url": "bootstrap-icons/icons/trash3-fill.svg"
    },
    {
      "hash": "sha256-f9JyqEZPQhaX7J6vitP9Zw8D//4AmpJpeEYX7s/YO5k=",
      "url": "bootstrap-icons/icons/trash3.svg"
    },
    {
      "hash": "sha256-gVdsATSqEWMRBPmqi/cJji3i/cetgv7eOkw1y9u3jyw=",
      "url": "bootstrap-icons/icons/tree-fill.svg"
    },
    {
      "hash": "sha256-upS7f7FXh+5YtR1SD9d97vhBm1t1HxoktKci+1RD9Ns=",
      "url": "bootstrap-icons/icons/tree.svg"
    },
    {
      "hash": "sha256-mk3VfoZ7iHWWeTCkRvXzvjczsu4avSSGLSUi/dxgi+E=",
      "url": "bootstrap-icons/icons/trello.svg"
    },
    {
      "hash": "sha256-jzb2yWVr7uMM7i2ZanKhJhRgE3QepmzJFhpFWj5gscw=",
      "url": "bootstrap-icons/icons/triangle-fill.svg"
    },
    {
      "hash": "sha256-raWXSywc+RZnNkWGegNh3/r5EoeBEG/dHXAKAPPTjJc=",
      "url": "bootstrap-icons/icons/triangle-half.svg"
    },
    {
      "hash": "sha256-YXxidve1H5mkYHCzGCyjVvOXckCsGjnA/7oSXdRWkpw=",
      "url": "bootstrap-icons/icons/triangle.svg"
    },
    {
      "hash": "sha256-ZSFlpkM7YrZlx9A0eJhpx17iXq8onA8MmW+nXy7+A9s=",
      "url": "bootstrap-icons/icons/trophy-fill.svg"
    },
    {
      "hash": "sha256-WsH/3ZWaqiVqM9/4dinv1DUTequVwT/RN7Nfonmnu3U=",
      "url": "bootstrap-icons/icons/trophy.svg"
    },
    {
      "hash": "sha256-ozuwDke3AlCM1ySH9nPX9mKfGEuwIe60dYAEFvj+NmM=",
      "url": "bootstrap-icons/icons/tropical-storm.svg"
    },
    {
      "hash": "sha256-Z/d2KzJf6VyGnq7c00Y/AwQFbgy7++mVyNDnmB8D7H8=",
      "url": "bootstrap-icons/icons/truck-flatbed.svg"
    },
    {
      "hash": "sha256-FwABPj++6N+KD1MDkfVI6SU75Ep2teWbKYN3ZIw7xuE=",
      "url": "bootstrap-icons/icons/truck-front-fill.svg"
    },
    {
      "hash": "sha256-HXU3HwCBmUD66SrqMiTYvwdDvYwwaaAdzswWgl1ttmo=",
      "url": "bootstrap-icons/icons/truck-front.svg"
    },
    {
      "hash": "sha256-yRUAl+pdTaMRe5VXQqW6hnhyPAXdc6nacZwlmkBq7HY=",
      "url": "bootstrap-icons/icons/truck.svg"
    },
    {
      "hash": "sha256-RyRkpA2T3WnYILyKXi28DvKnFRu8ibwu72d3KOmjikw=",
      "url": "bootstrap-icons/icons/tsunami.svg"
    },
    {
      "hash": "sha256-xrolMa7zXLSZ861Cfi0WsOk8/c/ig+uBlgJVkxMnJCs=",
      "url": "bootstrap-icons/icons/tux.svg"
    },
    {
      "hash": "sha256-/q2vIUQRLT5Ul8IgWAeW+sbKbaymKkMYtTniwweXuu8=",
      "url": "bootstrap-icons/icons/tv-fill.svg"
    },
    {
      "hash": "sha256-gYdxgakN3J0hlzAW6mnIZzznwtOZdVCwyOESjkElF3o=",
      "url": "bootstrap-icons/icons/tv.svg"
    },
    {
      "hash": "sha256-ueYA3DqSx7J9Ig4JlosQuDchtE55BPdipNpcpb6qg4o=",
      "url": "bootstrap-icons/icons/twitch.svg"
    },
    {
      "hash": "sha256-Fz435YTMtJy4ckKi5URCAdotd5zuGxRkcyiTMCl1lQ0=",
      "url": "bootstrap-icons/icons/twitter-x.svg"
    },
    {
      "hash": "sha256-qIs5asrpyPnwP2DKsoLsGrOPZh7Beuyf8xPA8l7wwjM=",
      "url": "bootstrap-icons/icons/twitter.svg"
    },
    {
      "hash": "sha256-vIqK3/moO15I/yQzesErPUId0UMoZxr+qbYFPJQlqu0=",
      "url": "bootstrap-icons/icons/type-bold.svg"
    },
    {
      "hash": "sha256-iP1zXPn9lGu7D4Gg1iYFpqTZszD9J6QiGHFA2xpauMQ=",
      "url": "bootstrap-icons/icons/type-h1.svg"
    },
    {
      "hash": "sha256-5WB0LRorKL7oYIVwioBn8Hvq9gdsaz6ETuX0dcRSEts=",
      "url": "bootstrap-icons/icons/type-h2.svg"
    },
    {
      "hash": "sha256-mda561WOlrXrDPGWuqeTO+UOOAcvGtK2BHOp5K6coFw=",
      "url": "bootstrap-icons/icons/type-h3.svg"
    },
    {
      "hash": "sha256-lc4/ZEdxEQe0PXG8jnTgKYFDUok95wZrYIbJyIIPQu8=",
      "url": "bootstrap-icons/icons/type-h4.svg"
    },
    {
      "hash": "sha256-Nal7s9JJNSEWJc9kr3XfLnudBn+BDHjuko2089zKXXs=",
      "url": "bootstrap-icons/icons/type-h5.svg"
    },
    {
      "hash": "sha256-4DL5spEuV1SK2RRKfYlZ+txWRZzpOGhHGxASA/+jsCc=",
      "url": "bootstrap-icons/icons/type-h6.svg"
    },
    {
      "hash": "sha256-KXImhZKOoib4l+u3eEEy6BDpdv+2HiH2Jdh1Rn+FMVM=",
      "url": "bootstrap-icons/icons/type-italic.svg"
    },
    {
      "hash": "sha256-cJovYz63MZHiJ1NTLanKWZfCrN+bJq1yotM7ipHXceU=",
      "url": "bootstrap-icons/icons/type-strikethrough.svg"
    },
    {
      "hash": "sha256-yXOm78Y2G9tfCR22quujkjpkDemb/GKnfXKmPebwZ3s=",
      "url": "bootstrap-icons/icons/type-underline.svg"
    },
    {
      "hash": "sha256-hmFkqaMClus5i1LFzwwgcIuZtc9Zx0ICF2cx+GQyFYM=",
      "url": "bootstrap-icons/icons/type.svg"
    },
    {
      "hash": "sha256-eclzS4u1HuSPyAzLOay9UyuA5UQO374kQhJv6dzZUQA=",
      "url": "bootstrap-icons/icons/typescript.svg"
    },
    {
      "hash": "sha256-mA4k+tL7XLfoQ0xiYfFmPuY19EkjpaauaDHNtTT3Jlk=",
      "url": "bootstrap-icons/icons/ubuntu.svg"
    },
    {
      "hash": "sha256-UPNU9z3yc10+dsGRogikrZBvVtzX73IdF+9lYpg2BOg=",
      "url": "bootstrap-icons/icons/ui-checks-grid.svg"
    },
    {
      "hash": "sha256-lQGJZJI/BzhhFje7hcx1ps7Pz9ZyQgMJKoauVkt8DwA=",
      "url": "bootstrap-icons/icons/ui-checks.svg"
    },
    {
      "hash": "sha256-lZAKf9KHJxowk6TKvG29MUYGHZdubEcArIBqVsW8E/Q=",
      "url": "bootstrap-icons/icons/ui-radios-grid.svg"
    },
    {
      "hash": "sha256-7kDH3SboplBrwI/gHGZzEc1XMyYFwyKYdFLT81jZ3Rc=",
      "url": "bootstrap-icons/icons/ui-radios.svg"
    },
    {
      "hash": "sha256-/qxj9y6ELILnmLItFQQiDJBoMTRgQgnUqQOcAKGU3X4=",
      "url": "bootstrap-icons/icons/umbrella-fill.svg"
    },
    {
      "hash": "sha256-V+ZaRfCRFJk69Rk4frAr80AUQua5zfSkf+NjyJlSvI4=",
      "url": "bootstrap-icons/icons/umbrella.svg"
    },
    {
      "hash": "sha256-gj5uAvmIFVvZtYyljwmGwp36Hixuoin3/129rC0h/Wo=",
      "url": "bootstrap-icons/icons/unindent.svg"
    },
    {
      "hash": "sha256-WpTtdWDx+xftrhTvgXoh1fWyJ+3RFHEH5LfAr46t0kA=",
      "url": "bootstrap-icons/icons/union.svg"
    },
    {
      "hash": "sha256-rBkcUM/QMgvnZpNF0QOUlE7M95VTRk4s8z9FmHTqj9U=",
      "url": "bootstrap-icons/icons/unity.svg"
    },
    {
      "hash": "sha256-sa6uHylARaEcCOQdwrOLa+2JqfozVoc2EcddcbaxeWA=",
      "url": "bootstrap-icons/icons/universal-access-circle.svg"
    },
    {
      "hash": "sha256-cHUQPGk5gpXC5/PJ8SYkOj5xfPP4h3TOfgMzFX5LSiQ=",
      "url": "bootstrap-icons/icons/universal-access.svg"
    },
    {
      "hash": "sha256-6XXTxSDOUZITA9/3/ChUT+lEGH7nb/MChmiKEAxfi+s=",
      "url": "bootstrap-icons/icons/unlock-fill.svg"
    },
    {
      "hash": "sha256-84KeiQjv9PlxoY1MajCxmO+2aXSthPn/2CWW3KEsLeY=",
      "url": "bootstrap-icons/icons/unlock.svg"
    },
    {
      "hash": "sha256-hbGCMGqGy95z5z9WEo/k7NK/xO+Q/DKlQiVoBE60xDo=",
      "url": "bootstrap-icons/icons/unlock2-fill.svg"
    },
    {
      "hash": "sha256-VDWRzp49vn3x+kxLwj1Y48YXCbg8TWnBD73/2dPlk8k=",
      "url": "bootstrap-icons/icons/unlock2.svg"
    },
    {
      "hash": "sha256-ec4re1zoTsXykwJPtSpMf5vcobmYqWCL5YbkhS7VHYI=",
      "url": "bootstrap-icons/icons/upc-scan.svg"
    },
    {
      "hash": "sha256-80DfxLqP34VAYRd6CjqAlSuDC29PSxcW9H46Zxql3W0=",
      "url": "bootstrap-icons/icons/upc.svg"
    },
    {
      "hash": "sha256-fwTq0Gb1Z3SdPWei9p28yK72BR2uhsOGWeanTxyp/bo=",
      "url": "bootstrap-icons/icons/upload.svg"
    },
    {
      "hash": "sha256-onhEuh4ZHquObdxC9+LVt3q1DM6c/BTa0VsodZInanQ=",
      "url": "bootstrap-icons/icons/usb-c-fill.svg"
    },
    {
      "hash": "sha256-wKNw+mfjXnKhEKkS5f403P/hzMG7TVfoNB5WLxzpiYo=",
      "url": "bootstrap-icons/icons/usb-c.svg"
    },
    {
      "hash": "sha256-Dl7hpVxy/aj+IYx5LGCNp47Rfvtx8SmjqmeqNbTI0Aw=",
      "url": "bootstrap-icons/icons/usb-drive-fill.svg"
    },
    {
      "hash": "sha256-o5Z7/Uujz3rgat2zVc8zUSzh+iXBd+kqa0lmejQUIxo=",
      "url": "bootstrap-icons/icons/usb-drive.svg"
    },
    {
      "hash": "sha256-i3jFG7RlMhXkxgBsq2Fayq7su/fzyk7Te9E82X9lO7w=",
      "url": "bootstrap-icons/icons/usb-fill.svg"
    },
    {
      "hash": "sha256-jqq+SlLVEDPdJAdb+mZQZvgNpqC4wf89Kfv5t/i0rCk=",
      "url": "bootstrap-icons/icons/usb-micro-fill.svg"
    },
    {
      "hash": "sha256-GauOaLefRiyLxe8F5v3SFAX5Yah7KZZIIsB6Wj9QEDI=",
      "url": "bootstrap-icons/icons/usb-micro.svg"
    },
    {
      "hash": "sha256-+oiB3vuuo8SEI7h5b9i5mNmEgD4tPeCibg3/1w50MTg=",
      "url": "bootstrap-icons/icons/usb-mini-fill.svg"
    },
    {
      "hash": "sha256-uuZRfw977OozrkCK3JCRXESVYuk4Hg2uCsyffW8hnV0=",
      "url": "bootstrap-icons/icons/usb-mini.svg"
    },
    {
      "hash": "sha256-Vg6esXFli97zB68jFqb00RWEzrWid45TgtYsJHGtH5c=",
      "url": "bootstrap-icons/icons/usb-plug-fill.svg"
    },
    {
      "hash": "sha256-wxjzVLMde6BSTSt0Mev5EhBgq06Aw37DGr4UdKAT8m0=",
      "url": "bootstrap-icons/icons/usb-plug.svg"
    },
    {
      "hash": "sha256-PLe5zp2i9KiDnYED4UYIWbw8Ro4oTiT7wtw0to8KjB4=",
      "url": "bootstrap-icons/icons/usb-symbol.svg"
    },
    {
      "hash": "sha256-kSbaiGB51MhSHMYUTAhXZuoivso0tWRxfIxySZvr8gw=",
      "url": "bootstrap-icons/icons/usb.svg"
    },
    {
      "hash": "sha256-lMHiYCK4hNkc1iadUU6CFJxJIXBAnubd44qMjJ2vFvU=",
      "url": "bootstrap-icons/icons/valentine.svg"
    },
    {
      "hash": "sha256-RU72tvnrpVqmMru5OzVKEnHhUxJNyll0KFgQZmyZjEM=",
      "url": "bootstrap-icons/icons/valentine2.svg"
    },
    {
      "hash": "sha256-Kl6fBWk5vfxd5hNEBFnyc8vn0YsFTXZIjtADXCttzIQ=",
      "url": "bootstrap-icons/icons/vector-pen.svg"
    },
    {
      "hash": "sha256-XHTfsYxy2ayzMGYEcIM1vnonnXn9P/9cumXkK5ddHqY=",
      "url": "bootstrap-icons/icons/view-list.svg"
    },
    {
      "hash": "sha256-CGuzaZbkWcARdbNlQEVX/JCG5CvWe/K3zN2ht0BdrFw=",
      "url": "bootstrap-icons/icons/view-stacked.svg"
    },
    {
      "hash": "sha256-8tvzsJ9nNj4ctNT0qZzmE6QYTB4Er1j0vK6tPMVwSW8=",
      "url": "bootstrap-icons/icons/vignette.svg"
    },
    {
      "hash": "sha256-XkEj8QEVrgWSBm8mxD9ebmL54pe5HGVfVDNBEIGfeiA=",
      "url": "bootstrap-icons/icons/vimeo.svg"
    },
    {
      "hash": "sha256-qs5WHUTgYOCcGAd9JfVu9su1P06D8pZ+lrv94+Q582I=",
      "url": "bootstrap-icons/icons/vinyl-fill.svg"
    },
    {
      "hash": "sha256-CikAztPZ6LfXb3nxCFjuxZZvVTD5Nzvp8I2AjVo9p4w=",
      "url": "bootstrap-icons/icons/vinyl.svg"
    },
    {
      "hash": "sha256-JtgpxmpcucECDuECAcsu5EZzW4DnlvDh2M0rx+or7f4=",
      "url": "bootstrap-icons/icons/virus.svg"
    },
    {
      "hash": "sha256-72VHWFZ9Suv29h/EGDGl5GUomdl8A3TsdaySgR//AJg=",
      "url": "bootstrap-icons/icons/virus2.svg"
    },
    {
      "hash": "sha256-BcSEMCDjYuqIxGGTUYp6O+P9gsbOBd2MYbz1UFvfJ6w=",
      "url": "bootstrap-icons/icons/voicemail.svg"
    },
    {
      "hash": "sha256-Q3FGUP8hpVtvlqXR1cyLw8HJMTPYaLONmPS6gfoTOkQ=",
      "url": "bootstrap-icons/icons/volume-down-fill.svg"
    },
    {
      "hash": "sha256-2bMcDvEflVxSLBlwrtzGRjvBSTQUtZPb1WamI30h0xA=",
      "url": "bootstrap-icons/icons/volume-down.svg"
    },
    {
      "hash": "sha256-otSbeyeMSfP1/hGJibMhKl0o0sx1h4+4fZ2wi8Ga9Qs=",
      "url": "bootstrap-icons/icons/volume-mute-fill.svg"
    },
    {
      "hash": "sha256-h5leoH4DV50Q7ot7GjWfcHmG/du2fUuzR5JV2q9oGJk=",
      "url": "bootstrap-icons/icons/volume-mute.svg"
    },
    {
      "hash": "sha256-wzWv0C7AOFPCqwTcVaYBk+e4jfHi5cxdryaIl+LxjJE=",
      "url": "bootstrap-icons/icons/volume-off-fill.svg"
    },
    {
      "hash": "sha256-eWFwLNKmqfnhnplhvmswkw1AANY0ybt+Ht7zHTAIb4Y=",
      "url": "bootstrap-icons/icons/volume-off.svg"
    },
    {
      "hash": "sha256-cm5ZiNapSrBfHjzmUF023yjeV94J3o+AyMEl5l8tKyc=",
      "url": "bootstrap-icons/icons/volume-up-fill.svg"
    },
    {
      "hash": "sha256-SgfXQxCTgr5zMCkQaMUPZL2rOXHkc6w0N4zgjGvwoqU=",
      "url": "bootstrap-icons/icons/volume-up.svg"
    },
    {
      "hash": "sha256-Bp+8HCxcd8QWUeDo9hptOpDMEy53xnC/kDn/WBAj878=",
      "url": "bootstrap-icons/icons/vr.svg"
    },
    {
      "hash": "sha256-9JYgZZTmoMzNmQfzACfHKdJGe/ztIW6IXdhj2LbjvKI=",
      "url": "bootstrap-icons/icons/wallet-fill.svg"
    },
    {
      "hash": "sha256-aDH7fMojR//bZBWiGGuWiENehSFyuHMBu4og1DBPFKQ=",
      "url": "bootstrap-icons/icons/wallet.svg"
    },
    {
      "hash": "sha256-NfFAxjsFzVS+KecN8Ag2AC6uGuru5aZHXivOShKY6O0=",
      "url": "bootstrap-icons/icons/wallet2.svg"
    },
    {
      "hash": "sha256-TNJzPL3dSzIPhvKqVS59X4Dxwyv2Q6vVi4Giyxf3LJo=",
      "url": "bootstrap-icons/icons/watch.svg"
    },
    {
      "hash": "sha256-XsL0Ce/hkMd1O2chnERLnWDmFpl25qEqyjx4k2wmlE8=",
      "url": "bootstrap-icons/icons/water.svg"
    },
    {
      "hash": "sha256-RRvm03CKvisMeYsRXxWY09f29gASO2IbU6b/Dxd1Sag=",
      "url": "bootstrap-icons/icons/webcam-fill.svg"
    },
    {
      "hash": "sha256-a5KulwBxABkU3jRNEvy8iuECTJX+zp6XKtYoOrPukok=",
      "url": "bootstrap-icons/icons/webcam.svg"
    },
    {
      "hash": "sha256-cHyKw3Ir6WK6mBvL3zKwp37ro+jsMKntJ/fcHuA4RFE=",
      "url": "bootstrap-icons/icons/wechat.svg"
    },
    {
      "hash": "sha256-3B3oDGn4f5H/RXDkC6+P+CSm+4HmF6ngVMJpB81ghkc=",
      "url": "bootstrap-icons/icons/whatsapp.svg"
    },
    {
      "hash": "sha256-IWz3j6WtaSYYa0OndDyx/Jr0zWdi6myWTE9lJTDVfl8=",
      "url": "bootstrap-icons/icons/wifi-1.svg"
    },
    {
      "hash": "sha256-pvfLtQBLTQCe06LWX/lSTwP67c09idXjAg8cz7DEP2U=",
      "url": "bootstrap-icons/icons/wifi-2.svg"
    },
    {
      "hash": "sha256-HDmQuARRDEkBlOBmbSMllrzbsdGL286wMXOt+uJM9AY=",
      "url": "bootstrap-icons/icons/wifi-off.svg"
    },
    {
      "hash": "sha256-1pfpFnCgFXPVsBYAunbKjxciH7ASZMeWrWGxCegHbA8=",
      "url": "bootstrap-icons/icons/wifi.svg"
    },
    {
      "hash": "sha256-wkAPU/YzFDY8dCbrpNOhXpxFtSrU5K/E2omTcv+z1E4=",
      "url": "bootstrap-icons/icons/wikipedia.svg"
    },
    {
      "hash": "sha256-Lwrj/kZUJAbq3pqqUKOkoYLctfg9VIwZ3tCVzJOLeCQ=",
      "url": "bootstrap-icons/icons/wind.svg"
    },
    {
      "hash": "sha256-IvFOtqGVBrmKyLtbejRN0pjoSKB6y5xWWirVy1LzlyM=",
      "url": "bootstrap-icons/icons/window-dash.svg"
    },
    {
      "hash": "sha256-edbCcCBm+VYmTDsQ8gbSFcy8cYqvzuyN2JRCMWJohAo=",
      "url": "bootstrap-icons/icons/window-desktop.svg"
    },
    {
      "hash": "sha256-v7vJvgI6XmP4VUiA2pRgB1EnRfahHs43TxfoKkoPTWI=",
      "url": "bootstrap-icons/icons/window-dock.svg"
    },
    {
      "hash": "sha256-9ZZwipiCl+VFl+EVjy1Iwed3448OqgGXZurxD/2Vph0=",
      "url": "bootstrap-icons/icons/window-fullscreen.svg"
    },
    {
      "hash": "sha256-fi4jRFlN5ki7XbIac39KmAQrjJgp39kVITMNMPi3CB4=",
      "url": "bootstrap-icons/icons/window-plus.svg"
    },
    {
      "hash": "sha256-TW98zfSpb2nOQVIlMGe4BpaxZgF7JT/Kju3KiLI/5zU=",
      "url": "bootstrap-icons/icons/window-sidebar.svg"
    },
    {
      "hash": "sha256-buBvNnRJQod1BKXwtGnJJFpunOxDwgd+3uSpRSzhXU4=",
      "url": "bootstrap-icons/icons/window-split.svg"
    },
    {
      "hash": "sha256-RWhYRD7DGrOEh+HLVzlasPb47NMYLRD1Uw5H84Hyu2I=",
      "url": "bootstrap-icons/icons/window-stack.svg"
    },
    {
      "hash": "sha256-CVtdX9NSM2KcehimgYRParB3IH+E7T8vWmNXJeJW8Zk=",
      "url": "bootstrap-icons/icons/window-x.svg"
    },
    {
      "hash": "sha256-5HBRYN8cFfCQoY1rLY/+gSkSf52H/otoWV9J9oHC8Ro=",
      "url": "bootstrap-icons/icons/window.svg"
    },
    {
      "hash": "sha256-xM8mA81tpq7CR6e+hIxLugTnhvqKb3/4gScUlnnoYSs=",
      "url": "bootstrap-icons/icons/windows.svg"
    },
    {
      "hash": "sha256-9RV5ZH7fp2zA+9HLli1ePjjcNSgHuktZmqBByOlfGSo=",
      "url": "bootstrap-icons/icons/wordpress.svg"
    },
    {
      "hash": "sha256-un+7tVm0p4OwZxS/eeDSifoTXaSlW+JA6zbVB0yJaSk=",
      "url": "bootstrap-icons/icons/wrench-adjustable-circle-fill.svg"
    },
    {
      "hash": "sha256-hbDJAl5wktGUnpyefbx6Q8LFlHbJltZE5OvJQIuqRaQ=",
      "url": "bootstrap-icons/icons/wrench-adjustable-circle.svg"
    },
    {
      "hash": "sha256-je7Ac897GL4JcSTXp8Sa4UXXk2v3N8crIsOXo9ZeDEk=",
      "url": "bootstrap-icons/icons/wrench-adjustable.svg"
    },
    {
      "hash": "sha256-y9Zy2NoQVzsNijIcRbCAQe4vYiCP4pfcAqlxRrTy6FA=",
      "url": "bootstrap-icons/icons/wrench.svg"
    },
    {
      "hash": "sha256-09x0HxhTHQlz7HNGqFXjaYnT+QjJOL+wT0zw0hK+HnI=",
      "url": "bootstrap-icons/icons/x-circle-fill.svg"
    },
    {
      "hash": "sha256-OdNPCfZDPJA6Z17F5Pw09pO/uoMzVPBSFSqglYNU9vU=",
      "url": "bootstrap-icons/icons/x-circle.svg"
    },
    {
      "hash": "sha256-UxF9iFs5Zdhtxb3Z6lSq4+a8AiHNVZapO93TigX8OZ0=",
      "url": "bootstrap-icons/icons/x-diamond-fill.svg"
    },
    {
      "hash": "sha256-Zvrm3rLCQ6yZlYGDvpeYYGQqwRUg8nEnVgzLDl6S4kI=",
      "url": "bootstrap-icons/icons/x-diamond.svg"
    },
    {
      "hash": "sha256-WsaWXJmJr6rRldwP5zm9dEOn6U5S+FMLm31mTSDF2eU=",
      "url": "bootstrap-icons/icons/x-lg.svg"
    },
    {
      "hash": "sha256-apnW6/izUaUUPVDpCU/gA0HT6NuoZ/aDaHKOsQCjp2I=",
      "url": "bootstrap-icons/icons/x-octagon-fill.svg"
    },
    {
      "hash": "sha256-BCZ8JMzHikyAgIfDUPsWMa3UvuZyvlWupZN29MZixng=",
      "url": "bootstrap-icons/icons/x-octagon.svg"
    },
    {
      "hash": "sha256-xyOSK8Liw65jqsBb4ot/Zz6jQOkFzjXfcLpnTeRViCs=",
      "url": "bootstrap-icons/icons/x-square-fill.svg"
    },
    {
      "hash": "sha256-v4TQ7QgzYCZVbeTc/A2H+bD01SSpnBJjG5ZnkeP/ZS4=",
      "url": "bootstrap-icons/icons/x-square.svg"
    },
    {
      "hash": "sha256-QAzPq+V3vgRsG4jTLSVfM+zaOgN5oznRSPUA9ObaOOo=",
      "url": "bootstrap-icons/icons/x.svg"
    },
    {
      "hash": "sha256-5zxd95l8/sD23u1EyKFgu2Sa+GV4nK/WiNub7ar0Lho=",
      "url": "bootstrap-icons/icons/xbox.svg"
    },
    {
      "hash": "sha256-6xpe3QlMB8g961GYgrRD/MuXiv0zyGXSd1+BznHJCfg=",
      "url": "bootstrap-icons/icons/yelp.svg"
    },
    {
      "hash": "sha256-2jQN2bId6QZb5bRiCtwDVufbgXn5awUhmSFZeKiUK6s=",
      "url": "bootstrap-icons/icons/yin-yang.svg"
    },
    {
      "hash": "sha256-wLFi3k17R6kKZ7UY14kKlLZdju+rEaBcuNaKx1BdiR8=",
      "url": "bootstrap-icons/icons/youtube.svg"
    },
    {
      "hash": "sha256-CLxeOps+A/aiiFpeNx88kVSdD6GIRJW/O0OdoWAyDlU=",
      "url": "bootstrap-icons/icons/zoom-in.svg"
    },
    {
      "hash": "sha256-v+rMSLl/fF3U7ShNPZsHwRhkPFbwPyOFmpkUfAnVIvQ=",
      "url": "bootstrap-icons/icons/zoom-out.svg"
    },
    {
      "hash": "sha256-3r7yYHvBjakpIb2VWeyVSjl7pUOdKV5PrOPnb5jaufM=",
      "url": "bootstrap/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-6CVX9VkrjDClDFrewC9SDrWydwrCHUxDUS2ii2QyqJA=",
      "url": "bootstrap/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-jQnGKfAZjFOKH0aQjnQrJH0rE5jpVmnEqCCrPWXJL/w=",
      "url": "bootstrap/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-LE4GfAuQ7Z9HjmjSrZUWNgqNH7LEHpF5FhBwTF6tQ8Y=",
      "url": "bootstrap/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-dqih1AExtbJZZOqRxpHLhvJyxSjpm0lyAcfOC/hBLZk=",
      "url": "bootstrap/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-WigUBkSLUFS8WA8+vWmcnlC4O4yt4orParrLyGb7v3I=",
      "url": "bootstrap/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-DPBRAwVmMA2+XDcxblF0HePxBwyZ1ptqtFFFTIh0D9E=",
      "url": "bootstrap/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-ByomLFObkHUhIoqpDISb1NVbG3WL7Zf/SrwcGTqAFSU=",
      "url": "bootstrap/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-qrOQB8Fa5xZYgGU+aalw5I1WEEn4YzrDG7ohrqRsQS4=",
      "url": "bootstrap/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-NlnpM3kqxa8C/TdKASd7iESh8XC6r3c/+5NNQfuYAcU=",
      "url": "bootstrap/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-C1bN5QfPpNXSGfcd8uLQqbFL1vWJWDgYuHT7Am8PR/c=",
      "url": "bootstrap/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-mlUoqg0oz0DOtK5OQyQMEEUmhDHv4XsSKWuPtdTh3Tw=",
      "url": "bootstrap/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-f8B4pW+yM+mgzfaBy9Dvq1FMEh75WIGK/Ck7b16SBJI=",
      "url": "bootstrap/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-JW5Hq3enF/nYNwOFJCWjOK0mOtvygSJC0X+d913YqDE=",
      "url": "bootstrap/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-NN1WJsceF6y4orGRLZm4PU0qG46L/6s1lCx69D1KBrQ=",
      "url": "bootstrap/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-2HOIYFK3ORZVMmw/F7Luv1qrh5MfbARIsIsgpm9bx5g=",
      "url": "bootstrap/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-OQ+d56/vTDpoNo+WiZ+g72oIw6+xWZx+oojZesiaI/8=",
      "url": "bootstrap/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-pKp/Qs/QuvssOVjyirYsAYEAws8IlYLFPLTAUz5wtSg=",
      "url": "bootstrap/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-7Uy8dRadthLDxzJ5aYiQ3NrcUUCUeYaGyuHK3aU2vO0=",
      "url": "bootstrap/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-slalFe6DRrCkZlveKXlZvVacYmcSFMKtO8WqM0MDpkM=",
      "url": "bootstrap/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-LqZ6LUnIKAFe9fXwmI4vmBViWhPbMStFnqTAdgLI4to=",
      "url": "bootstrap/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-V/GfPatCNrjrORTMl4lxGJRTrLNm4y1gRX5v7w4agjk=",
      "url": "bootstrap/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-G8jbfoYdHram7UYd0aTggfMKVxS5gBKdHVRYnyG8gio=",
      "url": "bootstrap/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-AUCP1y6FQUOJTo7cRm8rooWDPeXNI+Mng+3pWDRm71E=",
      "url": "bootstrap/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-SlAge5VqSrlDZA7pkxGLVUo06WojJhz+WLmqGAenhJs=",
      "url": "bootstrap/css/bootstrap.css"
    },
    {
      "hash": "sha256-sZ3QRO8el+S7RZdy5/yrNpUjoXCcrVbaoyoZ+qpVmW8=",
      "url": "bootstrap/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-2FMn2Zx6PuH5tdBQDRNwrOo60ts5wWPC9R8jK67b3t4=",
      "url": "bootstrap/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-SBRPr2qg+zzSznSNlzAjj4iPSrcV8F2r0cmvLFZxmIo=",
      "url": "bootstrap/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-OZEUEslXxgUSpLI6DqGQPtXzoPn3u3RGxVqZuy5fdGM=",
      "url": "bootstrap/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-lJgbgd5NuVX8zJhcSYkZFA1KCzWZaCxDp4r55ODgJ4o=",
      "url": "bootstrap/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-uQSMg1catz2lQ5W2swchn565xUR/T47bF6Bp6w8ZRlo=",
      "url": "bootstrap/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-coESESWwechQ6Fv468CnMeNsRn2auF9wxqd1iLiDgVs=",
      "url": "bootstrap/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-aVZjRM9XIr5RrLyQ/bJsJOsBzBwVP3OLFrL6h8zTtRA=",
      "url": "bootstrap/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-hp+1aQ4GXdlOcFxoy4q9WpWn43QK+yTZwQ0RYylN9mg=",
      "url": "bootstrap/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-5P1JGBOIxI7FBAvT/mb1fCnI5n/NhQKzNUuW7Hq0fMc=",
      "url": "bootstrap/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-xhEj5YzApLZdc3ugcMSFkRs9vsbXuAK99mKDlavZwIs=",
      "url": "bootstrap/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-PDbhjr4lOVee335EDz4CvMRsKtnvvFWyGbcyrzVdCqs=",
      "url": "bootstrap/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-mf9b4x0qgrow/rzu1ohF5NID49QRtncPmH8Xw0p9H3c=",
      "url": "bootstrap/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-+SgIQa4A/4w2uqnoKYM92fyJPHDWe2PFUvYBqI/fvIE=",
      "url": "bootstrap/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-RZ9nL6a1RK3+kwGy770ixEe8SpTIc0DmYUPOI+wm6wM=",
      "url": "bootstrap/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-G26Fbopja83eRYjmOhBhztlu27RoEnslJDYpY01AIHk=",
      "url": "bootstrap/js/bootstrap.js"
    },
    {
      "hash": "sha256-3k/sleEaQPgv1lzCQgVHuBrlJkFHQT0GCpKmcUL/W4w=",
      "url": "bootstrap/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-ew8UiV1pJH/YjpOEBInP1HxVvT/SfrCmwSoUzF9JIgc=",
      "url": "bootstrap/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-UrA9jZWcpT1pwfNME+YkIIDJrMu+AjfIKTSfd3ODwMs=",
      "url": "bootstrap/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-NlS+4S0/GXx+DDgFS259LZrCGjUZFZxBjLYY6Md/ZVE=",
      "url": "bootstrap/scss/_accordion.scss"
    },
    {
      "hash": "sha256-3Cl/x0tBd+YWCTzPJnjhzzzxWBUTdj8yq5WV80VLD94=",
      "url": "bootstrap/scss/_alert.scss"
    },
    {
      "hash": "sha256-+fClyOlOMCKM7ZUQAygqZbvXoFgJxOmwcNciL1Zq07c=",
      "url": "bootstrap/scss/_badge.scss"
    },
    {
      "hash": "sha256-RSC8VVhn6mgSv2Qd9cFI4lEVVf38fYKn9wQmv9a9VZ4=",
      "url": "bootstrap/scss/_breadcrumb.scss"
    },
    {
      "hash": "sha256-bEJoDOB9olKPinb68ss8+xOxnsHJuMOZeztizQZX5LE=",
      "url": "bootstrap/scss/_button-group.scss"
    },
    {
      "hash": "sha256-GzsF1Dc6pmRznXha7QfNbtxuXrPo3pkZWiyUtK1IUf8=",
      "url": "bootstrap/scss/_buttons.scss"
    },
    {
      "hash": "sha256-irzA+PGFpgRWTmbQBQmbIueyJyye8c7eeCbtOJH1f4s=",
      "url": "bootstrap/scss/_card.scss"
    },
    {
      "hash": "sha256-n9a9OLjuY/K5UQDFtZgbfmC9KzfDGUg+MLitTytXdMo=",
      "url": "bootstrap/scss/_carousel.scss"
    },
    {
      "hash": "sha256-7C6if7AQUEFz9jZalAYpz72byYCzU/OCtQ1KZLpEcBM=",
      "url": "bootstrap/scss/_close.scss"
    },
    {
      "hash": "sha256-78i6mg5dW9hm3TGKHnH9Bo1nzft/Cx7+oEdBxO1tVGc=",
      "url": "bootstrap/scss/_containers.scss"
    },
    {
      "hash": "sha256-DewCij4OoIVM9pUytwIIcYfAMj8NGblzha0McN0kSB4=",
      "url": "bootstrap/scss/_dropdown.scss"
    },
    {
      "hash": "sha256-JRuJTT5voTi7uiha0l+fhV61TQBsUEPO5HYx+l18zKY=",
      "url": "bootstrap/scss/_forms.scss"
    },
    {
      "hash": "sha256-P/nZquIA6uEEQEuH9qL7onXYPtdgp5toX0szun6l/rQ=",
      "url": "bootstrap/scss/_functions.scss"
    },
    {
      "hash": "sha256-E2YlOC9y6TWuRw0F74zI8/TrEJSdKjdqBKO8hqFMaV0=",
      "url": "bootstrap/scss/_grid.scss"
    },
    {
      "hash": "sha256-H96+hj9rtgMRHNnaxu7NynFmgzeIxQuKnC3iHhU+0Ik=",
      "url": "bootstrap/scss/_helpers.scss"
    },
    {
      "hash": "sha256-lKPZa/cC+owcR0tmr9gddy1LAZiK1IQ5Z1CYqZnVdwA=",
      "url": "bootstrap/scss/_images.scss"
    },
    {
      "hash": "sha256-Og4eQt6jAF6e10Gn4005Rz5gt3NwWX/OZss14Q9Rttc=",
      "url": "bootstrap/scss/_list-group.scss"
    },
    {
      "hash": "sha256-mxqqgFhZaf7Y49807q3Rx7X0CtkvR94J1Syc8a4QRWI=",
      "url": "bootstrap/scss/_maps.scss"
    },
    {
      "hash": "sha256-OLz1wDZvC1uBzgCUHy3JTLQqYq+HWQH8vdcJiBZ7hOQ=",
      "url": "bootstrap/scss/_mixins.scss"
    },
    {
      "hash": "sha256-ZT+h9uX0n6mUviIsn8bTCBQC9zcmP2ieqqYEAjQJJVQ=",
      "url": "bootstrap/scss/_modal.scss"
    },
    {
      "hash": "sha256-CMCWGuVUml9Wb3c9iFps8csLee/Z1XNWILLFMlmV8wo=",
      "url": "bootstrap/scss/_nav.scss"
    },
    {
      "hash": "sha256-S6hNtjwhfyHJESATqNdW9oFrX1oq0RTHEH3t6DKu5qY=",
      "url": "bootstrap/scss/_navbar.scss"
    },
    {
      "hash": "sha256-wggMKISLVMovsU3EhczfMHoFYcWDDPcwuYdl8tj14Ao=",
      "url": "bootstrap/scss/_offcanvas.scss"
    },
    {
      "hash": "sha256-izDtATRxZzUudXMhMvxfu9/46zxILlvKxdCPkcrj81k=",
      "url": "bootstrap/scss/_pagination.scss"
    },
    {
      "hash": "sha256-upa3cEwxdLcp+O3vamjunsQ2QWeeOwE0FQnFtviENI0=",
      "url": "bootstrap/scss/_placeholders.scss"
    },
    {
      "hash": "sha256-nOZ+GPauTKmqT5qPXaXQNd6tz4/hZaxRzRZijb4H+qM=",
      "url": "bootstrap/scss/_popover.scss"
    },
    {
      "hash": "sha256-zZicvLHBAlNFEeYzvNx4NTHx9p0Zs6qbwV6C5vvP2a4=",
      "url": "bootstrap/scss/_progress.scss"
    },
    {
      "hash": "sha256-RnSVG2wXJVQ1szgcwX48AGYnH8Gzbk9+YvYsDFykhTQ=",
      "url": "bootstrap/scss/_reboot.scss"
    },
    {
      "hash": "sha256-kcMMve1I+T1fnRXjG4gM79r/4RXUkBplk09DRd29axI=",
      "url": "bootstrap/scss/_root.scss"
    },
    {
      "hash": "sha256-ytiPEHSNaM1upT3ldveW1Ubh/FcLfYuLQ+x79HijBXs=",
      "url": "bootstrap/scss/_spinners.scss"
    },
    {
      "hash": "sha256-IxJWt3SSvJcFG780NfIfVS9GxTR3kUgKjS7KFoTPDnE=",
      "url": "bootstrap/scss/_tables.scss"
    },
    {
      "hash": "sha256-sKYERISpkZtSzUWRKVTvvtXG48EoMAy+rQeogoP3saI=",
      "url": "bootstrap/scss/_toasts.scss"
    },
    {
      "hash": "sha256-XvcKWw0kuLCwAotXeRGkzk/5csqoLAdmJMQu6sWHWtY=",
      "url": "bootstrap/scss/_tooltip.scss"
    },
    {
      "hash": "sha256-5WYb4Udq9gyeRTdQeA+GhBxonc8inegCIwB8PK2hSMk=",
      "url": "bootstrap/scss/_transitions.scss"
    },
    {
      "hash": "sha256-oAEJrZE7WzfE/pQyhxFtIbT9kCvjS76AS2jO7WOVPyA=",
      "url": "bootstrap/scss/_type.scss"
    },
    {
      "hash": "sha256-Wuv1svtJhQV5bFofvDCQVey4GqdnB5fmqvyXxvtEPls=",
      "url": "bootstrap/scss/_utilities.scss"
    },
    {
      "hash": "sha256-8AKr+LPojbPC3TtKUAwaDzYlPI8Hz7AOOJOLZy9KWAM=",
      "url": "bootstrap/scss/_variables-dark.scss"
    },
    {
      "hash": "sha256-t0e6pR8j5KuSroZQhOUvC4jeZYeqMP/X7DVkKR3J3O4=",
      "url": "bootstrap/scss/_variables.scss"
    },
    {
      "hash": "sha256-biY6CG4V38ED7IR7PL02nLLZVywRhLBlO0/3vSt8CY4=",
      "url": "bootstrap/scss/bootstrap-grid.scss"
    },
    {
      "hash": "sha256-wrA2i86TcmmfIsLQ5zbhjlhJ8CjeaJ6I34GNhxUHWr4=",
      "url": "bootstrap/scss/bootstrap-reboot.scss"
    },
    {
      "hash": "sha256-JC73V+mfcKh7xBm6/1ITL4JMirwR2k7cenqyxoKpebA=",
      "url": "bootstrap/scss/bootstrap-utilities.scss"
    },
    {
      "hash": "sha256-HQzgAuTMaY1xJYn7+erwKgaQKEUm1xyk14r+QXIEqw0=",
      "url": "bootstrap/scss/bootstrap.scss"
    },
    {
      "hash": "sha256-XPICsxZUm7S5RxfCZzk3jTnwEPI9YyxytCG3oxZ9KtY=",
      "url": "bootstrap/scss/forms/_floating-labels.scss"
    },
    {
      "hash": "sha256-ROwvTv8nBp8ZpsGtpdEjEMe7NmjpltLAHt1AGN/mWgE=",
      "url": "bootstrap/scss/forms/_form-check.scss"
    },
    {
      "hash": "sha256-RHvoUat+ATpTEOGCEp4UsDjuOrR6v/Fpe9i1+p/8X+4=",
      "url": "bootstrap/scss/forms/_form-control.scss"
    },
    {
      "hash": "sha256-Q7hjmhgGmNsxncbqnOaHFVEFnrkOiWL8s5zqZlikP8s=",
      "url": "bootstrap/scss/forms/_form-range.scss"
    },
    {
      "hash": "sha256-5FsWjrGcvg+Eqkka5UDweE5PKq2FV7scRRBzD+kDH50=",
      "url": "bootstrap/scss/forms/_form-select.scss"
    },
    {
      "hash": "sha256-grSlvamURdoncKgbvVOCeI+27my4sLfej3sTVe/wLUs=",
      "url": "bootstrap/scss/forms/_form-text.scss"
    },
    {
      "hash": "sha256-Ck3wfA2stH0GsGA6Vnfxjjdj2pFhnknRHgiKtAIRQ6k=",
      "url": "bootstrap/scss/forms/_input-group.scss"
    },
    {
      "hash": "sha256-gkwf1yD1SHOY/gerBRhhPw5HyJdNoyD5wNhmx/KEBlU=",
      "url": "bootstrap/scss/forms/_labels.scss"
    },
    {
      "hash": "sha256-VhAdCAL4nORgaJoeKDuAczcRXMClilvsDOuMBj0XoGI=",
      "url": "bootstrap/scss/forms/_validation.scss"
    },
    {
      "hash": "sha256-f9rnpdiJnEdEGfcsb4RS/uSQ2AlTZ4t7NK240OTnkKk=",
      "url": "bootstrap/scss/helpers/_clearfix.scss"
    },
    {
      "hash": "sha256-wokfJy/atVdM257f3k5CdH5bL3FP2SgPpwnVp03dtS0=",
      "url": "bootstrap/scss/helpers/_color-bg.scss"
    },
    {
      "hash": "sha256-f89Q7CMMA/AkL2iXGB+5ylytdJVZjaD1RbqIkYzQq0o=",
      "url": "bootstrap/scss/helpers/_colored-links.scss"
    },
    {
      "hash": "sha256-AvgERS982r2QVWNxoNz3ZmJNkpi3s9GswXjPZHNOfGk=",
      "url": "bootstrap/scss/helpers/_focus-ring.scss"
    },
    {
      "hash": "sha256-TmKGFSaK7c2D96fx3djUaLt/4D1tVO7+1OL3BaJuTiI=",
      "url": "bootstrap/scss/helpers/_icon-link.scss"
    },
    {
      "hash": "sha256-MnpbRRIzcFqhWsFQnqj0/5YJHc6auQc5tvyQLKw++yY=",
      "url": "bootstrap/scss/helpers/_position.scss"
    },
    {
      "hash": "sha256-T1RpNjKZenlL1oB6PM/mqwHtPHbcDSFbEGwSdXwPp+A=",
      "url": "bootstrap/scss/helpers/_ratio.scss"
    },
    {
      "hash": "sha256-LqLdiqjbxWIkyOanP1yauyenILg054keckWIejPobUA=",
      "url": "bootstrap/scss/helpers/_stacks.scss"
    },
    {
      "hash": "sha256-vjSz6SCVaLcbC4MEYZnvO1WoEnfDX5k1Uq0jwGG2zyI=",
      "url": "bootstrap/scss/helpers/_stretched-link.scss"
    },
    {
      "hash": "sha256-RskEeZ2bOGH7q42kJ5/5chXn1tVIBymwqTw23Q47Vzg=",
      "url": "bootstrap/scss/helpers/_text-truncation.scss"
    },
    {
      "hash": "sha256-sib1VerR40KbmgTXBBZeIN3R8sg8DJWN4DaHZOZ/2Pg=",
      "url": "bootstrap/scss/helpers/_visually-hidden.scss"
    },
    {
      "hash": "sha256-ws813teUzTHRlqnLe3j1PPcP9HbDHdVNK9QbYmUbFHU=",
      "url": "bootstrap/scss/helpers/_vr.scss"
    },
    {
      "hash": "sha256-uKLKCJw8XxfPXgIJoL+US783ANrP9dYDBISfyfLV/Vg=",
      "url": "bootstrap/scss/mixins/_alert.scss"
    },
    {
      "hash": "sha256-77SLrz+104PWUYDOLG/InVR8UJIomx75Emh1m1gs8/c=",
      "url": "bootstrap/scss/mixins/_backdrop.scss"
    },
    {
      "hash": "sha256-sS/ElkD1J1kFYdfotrPlGKEgvNjYdnZS5CazuKWvwMA=",
      "url": "bootstrap/scss/mixins/_banner.scss"
    },
    {
      "hash": "sha256-XUHARliU19oMYbWdYoYl9U9Cjgih5cWIw+ry3wWporg=",
      "url": "bootstrap/scss/mixins/_border-radius.scss"
    },
    {
      "hash": "sha256-KmcV63pTbordWo/w3RZbVuWNJu3HscfLTbxX4UL9Aho=",
      "url": "bootstrap/scss/mixins/_box-shadow.scss"
    },
    {
      "hash": "sha256-pyELD81f9WhEsV8D9s5tDeOUCDwxhonoZ6Z05vGRRPo=",
      "url": "bootstrap/scss/mixins/_breakpoints.scss"
    },
    {
      "hash": "sha256-AdW1FULQcfszUz4Dl+wYGICVYE5zPNdRtKKid/WIUzs=",
      "url": "bootstrap/scss/mixins/_buttons.scss"
    },
    {
      "hash": "sha256-M3Dio/W9LbK5d80PbPqYBLfaFsuE+OQuzD2uLzykk94=",
      "url": "bootstrap/scss/mixins/_caret.scss"
    },
    {
      "hash": "sha256-G8IJ6Hf6AjicAyIXhNvJI7f4RHRDw4ao88I1w31NPtw=",
      "url": "bootstrap/scss/mixins/_clearfix.scss"
    },
    {
      "hash": "sha256-moCKPj9BIh9jJ67Eilh3VAvrtYgkewaPQOAriXaMPIU=",
      "url": "bootstrap/scss/mixins/_color-mode.scss"
    },
    {
      "hash": "sha256-PUQkIqq/GAkEs5pOBHwJmzks8Z5D8WY0g6wo6RUC1aU=",
      "url": "bootstrap/scss/mixins/_color-scheme.scss"
    },
    {
      "hash": "sha256-RM48ulNATfViASqcQ3pEeR9oKOacCG/wSM8eQ+1X+Pg=",
      "url": "bootstrap/scss/mixins/_container.scss"
    },
    {
      "hash": "sha256-aQeApfVoImu3VfXmAa3RIK9lR0yPLgd2TW8QvbWG6xE=",
      "url": "bootstrap/scss/mixins/_deprecate.scss"
    },
    {
      "hash": "sha256-mLqzael7iGuYVnqeY2/hIYKN96tZw5Uchvuqjt35KMY=",
      "url": "bootstrap/scss/mixins/_forms.scss"
    },
    {
      "hash": "sha256-gHO/n935S5yHsaWl7oagVj7LDGd/C+Wxd8syi9XbpbI=",
      "url": "bootstrap/scss/mixins/_gradients.scss"
    },
    {
      "hash": "sha256-Oa8ubeDjXC4IvKhMF2CeNroVssb5uNRGQ+FHmszJxkU=",
      "url": "bootstrap/scss/mixins/_grid.scss"
    },
    {
      "hash": "sha256-khNvFnacIswOP5nSbayUEDUkCaMdTkonQGKiV0UoDkk=",
      "url": "bootstrap/scss/mixins/_image.scss"
    },
    {
      "hash": "sha256-GT8xPVtDXQXWl0Ay7TOouMjfmjWBC9a7O1i9Ytbcik0=",
      "url": "bootstrap/scss/mixins/_list-group.scss"
    },
    {
      "hash": "sha256-hHF/vH/EHOK6Bst1Qu+/XOymICLzLN1Izqg5wVjjFiQ=",
      "url": "bootstrap/scss/mixins/_lists.scss"
    },
    {
      "hash": "sha256-IsBtAalMexyn7lgbhrdQimkESEQcnDGxvC3T8LNRo4M=",
      "url": "bootstrap/scss/mixins/_pagination.scss"
    },
    {
      "hash": "sha256-VJy5tTUgw0pwe/xU8wv4UIwKm8uX9j++t6EjqvtuRQQ=",
      "url": "bootstrap/scss/mixins/_reset-text.scss"
    },
    {
      "hash": "sha256-p/Cn0vmQTkm3CWm2LYIAdC+FQlKZ77NOLnUdNaQTKs4=",
      "url": "bootstrap/scss/mixins/_resize.scss"
    },
    {
      "hash": "sha256-QVAlE/XT4p82zJ0JBvIcMM2N1bugrUPEKmE/+MrfrdQ=",
      "url": "bootstrap/scss/mixins/_table-variants.scss"
    },
    {
      "hash": "sha256-6F6n5gJaigYf5lsncGvhsf12/DFkxMkdZyf5GgBVrhw=",
      "url": "bootstrap/scss/mixins/_text-truncate.scss"
    },
    {
      "hash": "sha256-jUUxBldKvwI0TPCdrBzA8QIsfafCZ9Q+Sh2o19sYqkQ=",
      "url": "bootstrap/scss/mixins/_transition.scss"
    },
    {
      "hash": "sha256-Uel5DJcTMjIOzRc2ZOr5dn3x1FhaX64lCIXLxKOhn48=",
      "url": "bootstrap/scss/mixins/_utilities.scss"
    },
    {
      "hash": "sha256-jzVJFX4aDExcCKp5by1+FiW1usjt4M1I/QkLDbDNAbU=",
      "url": "bootstrap/scss/mixins/_visually-hidden.scss"
    },
    {
      "hash": "sha256-J1u2wMqzSJbTzd0+7iuJfJaklC1YIWRtuZssLZJSpJw=",
      "url": "bootstrap/scss/utilities/_api.scss"
    },
    {
      "hash": "sha256-JsQPrGMGFQNZ+LCv25Rv/rWHI/fX1koYbas4W9dW2DQ=",
      "url": "bootstrap/scss/vendor/_rfs.scss"
    },
    {
      "hash": "sha256-IuvKcW4OSsvagiI09UVC7Spltfh1MEtLo8bbr+nWkyc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-hLXWRj2SYTlcx7lV0WyfuiecuXwKoGxYxhgBCGP6FyA=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-EIS4FhZfQrSadwTTDlRZVt7V4n1JiKGGTAiFkl79gN8=",
      "url": "images/Profile/DefaultProfileImg.png"
    },
    {
      "hash": "sha256-BQBskKd3npWw3bEufI8w3PvtE13HElQNLehnuUz7VSw=",
      "url": "images/Profile/DefaultProfileImg_sm.png"
    },
    {
      "hash": "sha256-b6/BDWv0dIxA1OJibyGSLu9Jsr6mK0kvVI6kUN0toj0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-7WFGYLFn2IXEDy15tEHkh0bRYeaJNbfD+M9PawfNuKU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-qKvdgilfNPbUhwBXxr/oY6FuS7gjMnObSkNc+bcE/yc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-SG6s85RbHwfdeb/uLw/AnnEzETbPh3GPGjAtCSQtGFw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-nFAlZp5iPYk6ES9zliJc8YEev1DE9RCpMCYpsia2U8U=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-j7NULzuHnXespD6BxEzEyRFAs+H4wSp7cSfMnJtT3JU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-WgHd4tERuVMO8d9FFFvBjvI6HtTEk3vyBzVpcA+USpw=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-NMaQZvrPqwDkHHpVfqSQ3qDOpNtNrl/afan4QUqN+wc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-gB7DbqbyJAJSTuC6nmrSzN5y7WKr+omATtKUmOFAu7g=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-kcJsX2531fAsuJojY11YCqe8Ivtyi5ptWcCMp9c011E=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-vkYP/rBdLQXbyyRs1QGV/5j13m8nZgYROjrMTWxF+Nc=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "old_favicon.png"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
